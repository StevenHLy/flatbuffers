#include "ConfigParameters.h"
#include "DscException.h"
#include "DscFramework.h"
#include "ProgramArguments.h"
#include <exception>
#include <iostream>
#include <memory>

int main(int argc, char** argv)
{
   std::unique_ptr<DscFramework> m_dsc_framework;

   try
   {
      ProgramArguments::getInstance().setArgs(argc, argv);

      m_dsc_framework.reset(new DscFramework());
      m_dsc_framework->initialize();
      m_dsc_framework->run();
      m_dsc_framework->shutdown();
   }
   catch(DscException const& e_dsc)
   {
      std::cout << "main() - caught DscException exception ("
                << e_dsc.what()
                << ") from framework code, exiting application..."
                << std::endl;
   }
   catch(std::exception const& e_std)
   {
      std::cout << "main() - caught std::exception ("
                << e_std.what()
                << ") from framework code, exiting application..."
                << std::endl;
   }
   catch(...)
   {
      std::cout << "main() - caught an unspecified exception from framework code, exiting application..."
                << std::endl;
   }

   return 0;
}
