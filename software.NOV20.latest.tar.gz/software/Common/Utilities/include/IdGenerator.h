#ifndef IdGenerator_h
#define IdGenerator_h

#include <limits>

template<typename IdType>
class IdGenerator
{
   public:

      IdGenerator(IdType p_min = IdType(1),
                  IdType p_max = IdType(std::numeric_limits<IdType>::max()))
      : MIN_VALUE(p_min)
      , MAX_VALUE(p_max)
      , m_current_id(MIN_VALUE)
      {
      }
      ~IdGenerator() = default;

      IdType minId();
      IdType maxId();
      IdType nextId();
      void reset();

   private:

      const IdType MIN_VALUE;
      const IdType MAX_VALUE;

      IdType m_current_id;
};

template<typename IdType>
IdType IdGenerator<IdType>::minId()
{
   return MIN_VALUE;
}

template<typename IdType>
IdType IdGenerator<IdType>::maxId()
{
   return MAX_VALUE;
}

template<typename IdType>
IdType IdGenerator<IdType>::nextId()
{
   IdType next_id = m_current_id;

   m_current_id++;

   if (m_current_id > maxId())
   {
      m_current_id = minId();
   }

   return next_id;
}

template<typename IdType>
void IdGenerator<IdType>::reset()
{
   m_current_id = MIN_VALUE;
}

#endif
