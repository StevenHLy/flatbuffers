#ifndef ConfigParameters_h
#define ConfigParameters_h

#include <boost/property_tree/ptree.hpp>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

class ConfigParameters
{
   public:

      typedef boost::property_tree::ptree::const_iterator iterator;

      static ConfigParameters& getInstance();

      template<typename ParamType> std::vector<ParamType> getArrayParam(const std::string& p_key);
      template<typename ParamType> ParamType getParam(const std::string& p_key,
                                                      ParamType p_default_value = ParamType());
      boost::property_tree::ptree& getPropertyTree();
      template<typename ParamType> ParamType getRequiredParam(const std::string& p_key);

   private:

      ConfigParameters();
      ~ConfigParameters() = default;
      ConfigParameters(const ConfigParameters&) = delete;
      ConfigParameters& operator=(const ConfigParameters&) = delete;

      void mergeFileTreeIntoMasterTree(const boost::property_tree::ptree& p_file_ptree);
      template <typename ParamType> std::vector<ParamType> parseArray(const std::string& p_array_string);
      void readConfigFile(boost::property_tree::ptree& p_file_ptree,
                          const std::string& p_config_file);
      void recursiveMergePropertyTree(const boost::property_tree::ptree& p_source_ptree,
                                      boost::property_tree::ptree& p_dest_ptree,
                                      boost::property_tree::ptree::path_type p_path);

      boost::property_tree::ptree m_combined_property_tree;
      boost::property_tree::ptree m_config_file_property_tree;
};

template<typename ParamType>
std::vector<ParamType> ConfigParameters::getArrayParam(const std::string& p_key)
{
  std::string value_str = getParam<std::string>(p_key);

  return parseArray<ParamType>(value_str);
}

template<typename ParamType>
ParamType ConfigParameters::getParam(const std::string& p_key,
                                     ParamType p_default_value)
{
   ParamType return_val = p_default_value;

  try
  {
     return_val = m_combined_property_tree.get<ParamType>(p_key);
  }
  catch(...)
  {
  }

  return return_val;
}

template<typename ParamType>
ParamType ConfigParameters::getRequiredParam(const std::string& p_key)
{
   ParamType return_val;

  try
  {
     return_val = m_combined_property_tree.get<ParamType>(p_key);
  }
  catch(boost::property_tree::ptree_bad_data &x)
  {
    throw std::runtime_error("config parameter " + p_key + " does not exist");
  }
  catch(...)
  {
    throw std::runtime_error("config parameter " + p_key + " contains bad/mismatched data");
  }

  return return_val;
}

template <typename ParamType>
std::vector<ParamType> ConfigParameters::parseArray(const std::string& p_array_string)
{
  std::istringstream buf(p_array_string);
  std::istream_iterator<ParamType> beg(buf), end;
  std::vector<ParamType> vec(beg, end);

  return vec;
}

#endif
