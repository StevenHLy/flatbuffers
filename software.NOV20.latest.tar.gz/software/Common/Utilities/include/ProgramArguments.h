#ifndef ProgramArguments_h
#define ProgramArguments_h

#include "ProgramArgumentType.h"
#include <boost/lexical_cast.hpp>
#include <map>
#include <stdexcept>
#include <string>

class ProgramArguments
{
   public:

      static ProgramArguments& getInstance();

      template<typename ArgType> ArgType getArg(ProgramArgumentType::ProgramArgumentTypeEnum p_program_argument);
      int numArgs();
      void setArgs(int p_num_args,
                   char** p_args);

   private:

      ProgramArguments();
      ~ProgramArguments();
      ProgramArguments(const ProgramArguments&) = delete;
      ProgramArguments& operator=(const ProgramArguments&) = delete;

      std::map<ProgramArgumentType::ProgramArgumentTypeEnum, std::string> m_program_arguments;
};

template<typename ArgType> ArgType ProgramArguments::getArg(ProgramArgumentType::ProgramArgumentTypeEnum p_program_argument)
{
   try
   {
      return boost::lexical_cast<ArgType>(m_program_arguments.at(p_program_argument));
   }
   catch (std::out_of_range const& e)
   {
      throw std::runtime_error("program argument key (" + std::to_string((int)p_program_argument) + ") not in map");
   }
}

#endif
