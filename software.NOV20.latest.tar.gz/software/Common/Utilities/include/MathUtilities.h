#ifndef MathUtilities_h
#define MathUtilities_h

class MathUtilities
{
   public:

      static bool equal(double p_d1,
                        double p_d2,
                        double p_epsilon = MathUtilities::TOLERANCE);
      static bool notEqual(double p_d1,
                           double p_d2,
                           double p_epsilon = MathUtilities::TOLERANCE);

   private:

      static const double TOLERANCE;

      MathUtilities() = delete;
      ~MathUtilities() = delete;
};

#endif
