#ifndef EndianUtilities_h
#define EndianUtilities_h

#include "EndianType.h"
#include <algorithm>
#include <array>

class EndianUtilities
{
   public:

      static EndianType::EndianTypeEnum getEndian();
      static bool isBigEndian();
      static bool isLittleEndian();

      template<typename DataType> static DataType swapOnLittle(DataType& p_data);

   private:

      EndianUtilities() = delete;
      ~EndianUtilities() = delete;

      static EndianType::EndianTypeEnum determineEndian();

      static EndianType::EndianTypeEnum m_endian;
};

template<typename DataType>
DataType EndianUtilities::swapOnLittle(DataType& p_data)
{
   if (isLittleEndian())
   {
      union SwapDataType
      {
         DataType val;
         std::array<std::uint8_t, sizeof(DataType)> byte_array;
      } src, dest;

      src.val = p_data;
      std::reverse_copy(src.byte_array.begin(), src.byte_array.end(), dest.byte_array.begin());
      p_data = dest.val;
   }

   return p_data;
}

#endif
