#include "ConfigParameters.h"
#include "InvalidFileExtensionException.h"
#include <boost/filesystem.hpp>
#include <boost/property_tree/info_parser.hpp>
#include <boost/property_tree/ini_parser.hpp>
#include <boost/property_tree/json_parser.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/property_tree/detail/file_parser_error.hpp>
#include <iostream>
#include <stdlib.h>

ConfigParameters::ConfigParameters()
{
   std::string config_directory = boost::filesystem::current_path().string() + "/ConfigFiles";

   char *config_directory_env_var = std::getenv("CONFIG_FILES_DIR");
   if (config_directory_env_var != nullptr)
   {
     config_directory = std::string(config_directory_env_var);
   }

   boost::filesystem::path p(config_directory);
   boost::filesystem::directory_iterator it{p};

   while (it != boost::filesystem::directory_iterator{})
   {
     if (boost::filesystem::is_regular_file(*it))
     {
       std::string current_filename(it->path().filename().c_str());
       if (current_filename.find("ConfigParameters") == 0)
       {
          std::string current_config_file = config_directory + "/" + current_filename;

          readConfigFile(m_config_file_property_tree, current_config_file);
          mergeFileTreeIntoMasterTree(m_config_file_property_tree);
       }
     }

     ++it;
   }
}

ConfigParameters& ConfigParameters::getInstance()
{
   static ConfigParameters instance;

   return instance;
}

boost::property_tree::ptree& ConfigParameters::getPropertyTree()
{
   return m_combined_property_tree;
}

void ConfigParameters::mergeFileTreeIntoMasterTree(const boost::property_tree::ptree& p_file_ptree)
{
   recursiveMergePropertyTree(p_file_ptree, m_combined_property_tree, "");
}

void ConfigParameters::recursiveMergePropertyTree(const boost::property_tree::ptree& p_source_ptree,
                                                  boost::property_tree::ptree& p_dest_ptree,
                                                  boost::property_tree::ptree::path_type p_path)
{
   using boost::property_tree::ptree;

   p_dest_ptree.put(p_path, p_source_ptree.data());

   for (ptree::const_iterator it = p_source_ptree.begin(); it != p_source_ptree.end(); ++it)
   {
     ptree::path_type cur_path = p_path / ptree::path_type(it->first);
     recursiveMergePropertyTree(it->second, p_dest_ptree, cur_path);
   }
}

void ConfigParameters::readConfigFile(boost::property_tree::ptree& p_file_ptree,
                                      const std::string& p_config_file)
{
   std::string extension = boost::filesystem::extension(p_config_file);

   if (extension == ".info" || extension == ".INFO")
   {
      read_info(p_config_file, p_file_ptree);
   }
   else if (extension == ".ini" || extension == ".INI")
   {
      read_ini(p_config_file, p_file_ptree);
   }
   else if (extension == ".json" || extension == ".JSON")
   {
      read_json(p_config_file, p_file_ptree);
   }
   else if (extension == ".xml" || extension == ".XML")
   {
      read_xml(p_config_file, p_file_ptree);
   }
   else
   {
      throw InvalidFileExtensionException(__FILE__,
                                          __LINE__,
                                          extension);
   }
}
