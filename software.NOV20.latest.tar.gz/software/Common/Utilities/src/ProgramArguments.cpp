#include "ProgramArguments.h"

ProgramArguments::ProgramArguments()
: m_program_arguments()
{
}

ProgramArguments::~ProgramArguments()
{
   m_program_arguments.clear();
}

ProgramArguments& ProgramArguments::getInstance()
{
   static ProgramArguments instance;

   return instance;
}

int ProgramArguments::numArgs()
{
   return m_program_arguments.size();
}

void ProgramArguments::setArgs(int p_num_args,
                               char** p_args)
{
   for (int i = 0; i < p_num_args; i++)
   {
      m_program_arguments.emplace((ProgramArgumentType::ProgramArgumentTypeEnum)i, p_args[i]);
   }
}
