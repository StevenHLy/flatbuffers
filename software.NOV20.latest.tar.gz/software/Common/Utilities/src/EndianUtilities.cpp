#include "EndianUtilities.h"

EndianType::EndianTypeEnum EndianUtilities::m_endian = determineEndian();

EndianType::EndianTypeEnum EndianUtilities::determineEndian()
{
   const unsigned int test_word = 0x01020304;
   char test_string[4] = {'\01', '\02', '\03', '\04'};
   unsigned int* swap_test_word = (unsigned int*)test_string;

   return (((*swap_test_word) == test_word) ? EndianType::EndianTypeEnum::BIG : EndianType::EndianTypeEnum::LITTLE);
}

EndianType::EndianTypeEnum EndianUtilities::getEndian()
{
   return m_endian;
}

bool EndianUtilities::isBigEndian()
{
   return (getEndian() == EndianType::EndianTypeEnum::BIG);
}

bool EndianUtilities::isLittleEndian()
{
   return (getEndian() == EndianType::EndianTypeEnum::LITTLE);
}
