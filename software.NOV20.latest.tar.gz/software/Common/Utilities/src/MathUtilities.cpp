#include "MathUtilities.h"
#include <cmath>
#include <float.h>

const double MathUtilities::TOLERANCE = FLT_EPSILON * 10.0;

bool MathUtilities::equal(double p_d1,
                          double p_d2,
                          double p_epsilon)
{
  return (fabs(p_d1 - p_d2) < p_epsilon);
}

bool MathUtilities::notEqual(double p_d1,
                             double p_d2,
                             double p_epsilon)
{
  return (not equal(p_d1, p_d2, p_epsilon));
}
