#ifndef DscContants_h
#define DscContants_h

#include <cmath>
#include <string>

namespace Constants
{
   const double PI = M_PI;

   const double SECS_IN_MINUTE = 60.0;
   const double SECS_IN_HALF_HOUR = 1800.0;
   const double SECS_IN_HOUR = 3600.0;
   const double SECS_IN_DAY = 86400.0;

   const double TO_DEGREES_FROM_RADIANS = 180.0 / PI;
   const double TO_RADIANS_FROM_DEGREES = 1.0 / TO_DEGREES_FROM_RADIANS;

   const double TO_NSECS_FROM_SECS = 1.0e+9;
   const double TO_SECS_FROM_NSECS = 1.0 / TO_NSECS_FROM_SECS;

   const double TO_USECS_FROM_SECS = 1.0e6;
   const double TO_SECS_FROM_USECS = 1.0 / TO_USECS_FROM_SECS;

   const double TO_MSECS_FROM_SECS = 1.0e3;
   const double TO_SECS_FROM_MSECS = 1.0 / TO_MSECS_FROM_SECS;

   const double TO_SECS_FROM_MINUTES = SECS_IN_MINUTE;
   const double TO_MINUTES_FROM_SECS = 1.0 / TO_SECS_FROM_MINUTES;

   const double TO_SECS_FROM_HOURS = SECS_IN_HOUR;
   const double TO_HOURS_FROM_SECS = 1.0 / TO_SECS_FROM_HOURS;

   const double TO_SECS_FROM_DAYS = SECS_IN_DAY;
   const double TO_DAYS_FROM_SECS = 1.0 / TO_SECS_FROM_DAYS;

   const double TO_METERS_FROM_KILOMETERS = 1.0e+3;
   const double TO_KILOMETERS_FROM_METERS = 1.0 / TO_METERS_FROM_KILOMETERS;
}

#endif
