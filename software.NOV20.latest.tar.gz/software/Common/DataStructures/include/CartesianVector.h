#ifndef CartesianVector_h
#define CartesianVector_h

template<typename DataType>
class CartesianVector
{
   public:

      CartesianVector();
      virtual ~CartesianVector() = default;

      void init();
      DataType& x();
      DataType& y();
      DataType& z();

   protected:

      DataType m_x;
      DataType m_y;
      DataType m_z;
};

template<typename DataType>
CartesianVector<DataType>::CartesianVector()
{
   init();
}

template<typename DataType>
void CartesianVector<DataType>::init()
{
   m_x = DataType(0);
   m_y = DataType(0);
   m_z = DataType(0);
}

template<typename DataType>
DataType& CartesianVector<DataType>::x()
{
   return m_x;
}


template<typename DataType>
DataType& CartesianVector<DataType>::y()
{
   return m_y;
}


template<typename DataType>
DataType& CartesianVector<DataType>::z()
{
   return m_z;
}

#endif
