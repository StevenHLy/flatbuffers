#ifndef GenericBuffer_h
#define GenericBuffer_h

#include <algorithm>
#include <vector>

template <typename BufferType>
class GenericBuffer
{
   public:

      GenericBuffer(const unsigned int p_buffer_size);
      virtual ~GenericBuffer() = default;

      BufferType* buffer();
      unsigned int bufferSize();
      void init();

   protected:

      std::vector<BufferType> m_buffer;
};

template <typename BufferType>
GenericBuffer<BufferType>::GenericBuffer(const unsigned int p_buffer_size)
: m_buffer()
{
   m_buffer.resize(p_buffer_size);

   init();
}

template <typename BufferType>
BufferType* GenericBuffer<BufferType>::buffer()
{
   return m_buffer.data();
}

template <typename BufferType>
unsigned int GenericBuffer<BufferType>::bufferSize()
{
   return m_buffer.size();
}

template <typename BufferType>
void GenericBuffer<BufferType>::init()
{
   std::fill(m_buffer.begin(), m_buffer.end(), 0);
}

#endif
