#ifndef ModuleType_h
#define ModuleType_h

#include <string>

namespace ModuleType
{
   enum class ModuleTypeEnum : unsigned int
   {
      UNKNOWN               = 0,
      FRAMEWORK             = 1,
      FRAMEWORK_SERVICE     = 2,
      APPLICATION_COMPONENT = 3,
      SIMULATOR             = 4
   };

   std::string enumToString(ModuleType::ModuleTypeEnum p_enum);
   ModuleType::ModuleTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
