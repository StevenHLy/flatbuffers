#ifndef EndianType_h
#define EndianType_h

#include <string>

namespace EndianType
{
   enum class EndianTypeEnum : unsigned int
   {
      LITTLE = 0,
      BIG    = 1
   };

   std::string enumToString(EndianType::EndianTypeEnum p_enum);
   EndianType::EndianTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
