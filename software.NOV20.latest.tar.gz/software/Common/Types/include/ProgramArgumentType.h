#ifndef ProgramArgumentType_h
#define ProgramArgumentType_h

#include <string>

namespace ProgramArgumentType
{
   enum class ProgramArgumentTypeEnum : unsigned int
   {
      EXECUTABLE_NAME = 0
   };

   std::string enumToString(ProgramArgumentType::ProgramArgumentTypeEnum p_enum);
   ProgramArgumentType::ProgramArgumentTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
