#include "ModuleType.h"
#include <map>
#include <stdexcept>

namespace ModuleType
{
   std::string enumToString(ModuleType::ModuleTypeEnum p_enum)
   {
      static std::map<ModuleTypeEnum, std::string> enum_to_string_map =
      {
         {ModuleTypeEnum::UNKNOWN, "UNKNOWN"},
         {ModuleTypeEnum::FRAMEWORK, "FRAMEWORK"},
         {ModuleTypeEnum::FRAMEWORK_SERVICE, "FRAMEWORK_SERVICE"},
         {ModuleTypeEnum::APPLICATION_COMPONENT, "APPLICATION_COMPONENT"},
         {ModuleTypeEnum::SIMULATOR, "SIMULATOR"}
      };

      try
      {
         return enum_to_string_map.at(p_enum);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("ModuleType::enumToString() - invalid enum (" + std::to_string(static_cast<unsigned int>(p_enum)) + ")");
      }
   }

   ModuleType::ModuleTypeEnum stringToEnum(const std::string& p_enum_string)
   {
      static std::map<std::string, ModuleTypeEnum> string_to_enum_map =
      {
         {"UNKNOWN", ModuleTypeEnum::UNKNOWN},
         {"FRAMEWORK", ModuleTypeEnum::FRAMEWORK},
         {"FRAMEWORK_SERVICE", ModuleTypeEnum::FRAMEWORK_SERVICE},
         {"APPLICATION_COMPONENT", ModuleTypeEnum::APPLICATION_COMPONENT},
         {"SIMULATOR", ModuleTypeEnum::SIMULATOR}
      };

      try
      {
         return string_to_enum_map.at(p_enum_string);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("ModuleType::stringToEnum() - invalid enum string (" + p_enum_string + ")");
      }
   }
}
