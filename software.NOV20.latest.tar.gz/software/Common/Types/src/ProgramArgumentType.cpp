#include "ProgramArgumentType.h"
#include <map>
#include <stdexcept>

namespace ProgramArgumentType
{
   std::string enumToString(ProgramArgumentType::ProgramArgumentTypeEnum p_enum)
   {
      static std::map<ProgramArgumentTypeEnum, std::string> enum_to_string_map =
      {
         {ProgramArgumentTypeEnum::EXECUTABLE_NAME, "EXECUTABLE_NAME"}
      };

      try
      {
         return enum_to_string_map.at(p_enum);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("ProgramArgumentType::enumToString() - invalid enum (" + std::to_string(static_cast<unsigned int>(p_enum)) + ")");
      }
   }

   ProgramArgumentType::ProgramArgumentTypeEnum stringToEnum(const std::string& p_enum_string)
   {
      static std::map<std::string, ProgramArgumentTypeEnum> string_to_enum_map =
      {
         {"EXECUTABLE_NAME", ProgramArgumentTypeEnum::EXECUTABLE_NAME}
      };

      try
      {
         return string_to_enum_map.at(p_enum_string);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("ProgramArgumentType::stringToEnum() - invalid enum string (" + p_enum_string + ")");
      }
   }
}
