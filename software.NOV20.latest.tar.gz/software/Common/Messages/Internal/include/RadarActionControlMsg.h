#ifndef RadarActionControlMsg_h
#define RadarActionControlMsg_h

#include "InternalMsg.h"
#include "RadarActionControlMsgBody.h"

class RadarActionControlMsg : public InternalMsg
{
   public:

      RadarActionControlMsg();
      ~RadarActionControlMsg() = default;

      RadarActionControlMsgBody m_body;
};

#endif
