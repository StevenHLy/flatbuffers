#ifndef SensorSchedulingRequestMsg_h
#define SensorSchedulingRequestMsg_h

#include "InternalMsg.h"
#include "SensorSchedulingRequestMsgBody.h"

class SensorSchedulingRequestMsg : public InternalMsg
{
   public:

      SensorSchedulingRequestMsg();
      ~SensorSchedulingRequestMsg() = default;

      SensorSchedulingRequestMsgBody m_body;
};

#endif
