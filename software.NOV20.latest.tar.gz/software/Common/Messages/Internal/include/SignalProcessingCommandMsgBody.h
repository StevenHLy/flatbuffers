#ifndef SignalProcessingCommandMsgBody_h
#define SignalProcessingCommandMsgBody_h

class SignalProcessingCommandMsgBody
{
   public:

      SignalProcessingCommandMsgBody();
      ~SignalProcessingCommandMsgBody() = default;

      char m_sending_node_name[128];
};

#endif
