#ifndef TrackerBoundaryMeasurementReportMsg_h
#define TrackerBoundaryMeasurementReportMsg_h

#include "InternalMsg.h"
#include "TrackerBoundaryMeasurementReportMsgBody.h"

class TrackerBoundaryMeasurementReportMsg : public InternalMsg
{
   public:

      TrackerBoundaryMeasurementReportMsg();
      ~TrackerBoundaryMeasurementReportMsg() = default;

      TrackerBoundaryMeasurementReportMsgBody m_body;
};

#endif
