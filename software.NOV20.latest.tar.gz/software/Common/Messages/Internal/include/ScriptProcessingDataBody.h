#ifndef ScriptProcessingDataBody_h
#define ScriptProcessingDataBody_h
#include <string>

class ScriptProcessingDataBody
{
   public:

      ScriptProcessingDataBody();
      ~ScriptProcessingDataBody() = default;

      struct Waveform
      {
         Waveform()
           : Pulsewidth_usec(0.0)
           , Amplitude(0.0)
           , Bandwidth_MHz(0)
           , Phase_Offsec_psec(0.0)
           , Offset_MHz(0)
           , Samples_Per_Chip(0)
           , Gold_Code_Index(0)
         {}

         double Pulsewidth_usec;
         double Amplitude;
         int Bandwidth_MHz;
         double Phase_Offsec_psec;
         int Offset_MHz;
         int Samples_Per_Chip;
         int Gold_Code_Index;
      };

      struct Slew
      {
         Slew()
           : Dish(0)
           , Azimuth_Degrees(0.0)
           , Elevation_Degrees(0.0)
         {
         }

         void setDish(const std::string &p_dish)
         {
            if ("Dickie" == p_dish)
            {
               Dish = 1;
            }
            else if ("Penzias" == p_dish)
            {
               Dish = 2;
            }
            else if ("Wilson" == p_dish)
            {
               Dish = 3;
            }
         }

         int Dish;
         double Azimuth_Degrees;
         double Elevation_Degrees;
      };

      struct Transmit
      {
         Transmit()
           : Dish(0)
           , waveform()
           , Num_Pulses(0)
           , Repetition_Count(0)
         {
         }

         void setDish(const std::string &p_dish)
         {
            if ("Dickie" == p_dish)
            {
               Dish = 1;
            }
            else if ("Penzias" == p_dish)
            {
               Dish = 2;
            }
            else if ("Wilson" == p_dish)
            {
               Dish = 3;
            }
         }

         int Dish;
         Waveform waveform;
         int Num_Pulses;
         int Repetition_Count;
      };

      void setCommandType(const std::string &p_command_type);

      int Command_Type;
      int Number_Of_Commands;
      Slew Slew_Commands[3];
      Transmit Transmit_Commands[3];
      double Execution_Time;
      std::string Step_Name;
};

#endif
