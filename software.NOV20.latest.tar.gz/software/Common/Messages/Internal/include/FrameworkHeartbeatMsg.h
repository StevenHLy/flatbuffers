#ifndef FrameworkHeartbeatMsg_h
#define FrameworkHeartbeatMsg_h

#include "InternalMsg.h"
#include "FrameworkHeartbeatMsgBody.h"

class FrameworkHeartbeatMsg : public InternalMsg
{
   public:

      FrameworkHeartbeatMsg();
      ~FrameworkHeartbeatMsg() = default;

      FrameworkHeartbeatMsgBody m_body;
};

#endif
