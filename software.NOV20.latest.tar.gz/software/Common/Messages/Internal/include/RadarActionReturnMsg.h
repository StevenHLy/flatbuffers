#ifndef RadarActionReturnMsg_h
#define RadarActionReturnMsg_h

#include "InternalMsg.h"
#include "RadarActionReturnMsgBody.h"

class RadarActionReturnMsg : public InternalMsg
{
   public:

      RadarActionReturnMsg();
      ~RadarActionReturnMsg() = default;

      RadarActionReturnMsgBody m_body;
};

#endif
