#ifndef DiscoGuiBoundaryMeasurementReportMsg_h
#define DiscoGuiBoundaryMeasurementReportMsg_h

#include "DiscoGuiBoundaryMeasurementReportMsgBody.h"
#include "InternalMsg.h"

class DiscoGuiBoundaryMeasurementReportMsg : public InternalMsg
{
   public:

      DiscoGuiBoundaryMeasurementReportMsg();
      ~DiscoGuiBoundaryMeasurementReportMsg() = default;

      DiscoGuiBoundaryMeasurementReportMsgBody m_body;
};

#endif
