#ifndef SignalProcessingCommandMsg_h
#define SignalProcessingCommandMsg_h

#include "InternalMsg.h"
#include "SignalProcessingCommandMsgBody.h"

class SignalProcessingCommandMsg : public InternalMsg
{
   public:

      SignalProcessingCommandMsg();
      ~SignalProcessingCommandMsg() = default;

      SignalProcessingCommandMsgBody m_body;
};

#endif
