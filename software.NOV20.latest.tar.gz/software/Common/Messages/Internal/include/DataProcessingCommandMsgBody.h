#ifndef DataProcessingCommandMsgBody_h
#define DataProcessingCommandMsgBody_h

class DataProcessingCommandMsgBody
{
   public:

      DataProcessingCommandMsgBody();
      ~DataProcessingCommandMsgBody() = default;
};

#endif
