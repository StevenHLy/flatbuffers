#ifndef InternalMsgIdType_h
#define InternalMsgIdType_h

#include <string>

namespace InternalMsgIdType
{
   enum class InternalMsgIdTypeEnum : unsigned int
   {
      UNKNOWN                                  = 0,
      MT_FRAMEWORK_HEARTBEAT                   = 1,
      MT_SENSOR_SCHEDULING_REQUEST             = 1000,
      MT_RADAR_ACTION_CONTROL                  = 1001,
      MT_SIGNAL_PROCESSING_COMMAND             = 1002,
      MT_DATA_PROCESSING_COMMAND               = 1003,
      MT_RADAR_ACTION_RETURN                   = 1004,
      MT_SENSOR_SCHEDULING_REQUEST_STATUS      = 1005,
      MT_PLATFORM_MEASUREMENT_DATA             = 1006,
      MT_DISCO_GUI_BOUNDARY_MEASUREMENT_REPORT = 1007,
      MT_TRACKER_BOUNDARY_MEASUREMENT_REPORT   = 1008,
      MT_SCRIPT_PROCESSING_DATA                = 1009
   };

   std::string enumToString(InternalMsgIdType::InternalMsgIdTypeEnum p_enum);
   InternalMsgIdType::InternalMsgIdTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
