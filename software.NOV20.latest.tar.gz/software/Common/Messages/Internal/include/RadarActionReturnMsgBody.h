#ifndef RadarActionReturnMsgBody_h
#define RadarActionReturnMsgBody_h

class RadarActionReturnMsgBody
{
   public:

      RadarActionReturnMsgBody();
     ~RadarActionReturnMsgBody() = default;

      //@SL
      struct Slew
      {
      Slew()
	   : Dish(0)
           , Azimuth_Degrees(0.0)
	   , Elevation_Degrees(0.0)
         {
         }

         int Dish;
         double Azimuth_Degrees;
         double Elevation_Degrees;
      };
      int Command_Type;
      char Dish[128]; 
      Slew Slew_Command;

};

#endif
