#ifndef SensorSchedulingRequestStatusMsg_h
#define SensorSchedulingRequestStatusMsg_h

#include "InternalMsg.h"
#include "SensorSchedulingRequestStatusMsgBody.h"

class SensorSchedulingRequestStatusMsg : public InternalMsg
{
   public:

      SensorSchedulingRequestStatusMsg();
      ~SensorSchedulingRequestStatusMsg() = default;

      SensorSchedulingRequestStatusMsgBody m_body;
};

#endif
