#ifndef PlatformMeasurementDataMsg_h
#define PlatformMeasurementDataMsg_h

#include "InternalMsg.h"
#include "PlatformMeasurementDataMsgBody.h"

class PlatformMeasurementDataMsg : public InternalMsg
{
   public:

      PlatformMeasurementDataMsg();
      ~PlatformMeasurementDataMsg() = default;

      PlatformMeasurementDataMsgBody m_body;
};

#endif
