#ifndef SensorSchedulingRequestStatusMsgBody_h
#define SensorSchedulingRequestStatusMsgBody_h

class SensorSchedulingRequestStatusMsgBody
{
   public:

      SensorSchedulingRequestStatusMsgBody();
      ~SensorSchedulingRequestStatusMsgBody() = default;
};

#endif
