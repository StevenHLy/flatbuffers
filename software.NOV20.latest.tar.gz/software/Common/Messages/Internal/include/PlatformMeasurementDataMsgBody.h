#ifndef PlatformMeasurementDataMsgBody_h
#define PlatformMeasurementDataMsgBody_h

class PlatformMeasurementDataMsgBody
{
   public:

      PlatformMeasurementDataMsgBody();
     ~PlatformMeasurementDataMsgBody() = default;
      
      //@SL Same info Blding142PlatformMeasurementDataMsg.h

      struct Transmit
      {
         Transmit()
	   : Dish(0)
           , Pulsewidth_usec(0.0)
           , Amplitude(0.0)
           , Bandwidth_MHz(0)
           , Phase_Offsec_psec(0.0)
           , Offset_MHz(0)
           , Samples_Per_Chip(0)
           , Gold_Code_Index(0)
           , Num_Pulses(0)
           , Repetition_Count(0)
         {
         }

         int Dish;
         //waveform start
         double Pulsewidth_usec;
         double Amplitude;
         int Bandwidth_MHz;
         double Phase_Offsec_psec;
         int Offset_MHz;
         int Samples_Per_Chip;
         int Gold_Code_Index;
         //waveform end
         int Num_Pulses;
         int Repetition_Count;
      };

      char Dish[128]; 
      Transmit Transmit_Command;
      int Command_Type;

};

#endif
