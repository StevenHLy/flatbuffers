#ifndef InternalMsg_h
#define InternalMsg_h

#include "InternalMsgHeader.h"

class InternalMsg
{
   public:

      InternalMsg();
      ~InternalMsg() = default;

      InternalMsgHeader m_header;
};

#endif
