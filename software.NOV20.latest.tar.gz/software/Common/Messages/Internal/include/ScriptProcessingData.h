#ifndef ScriptProcessingData_h
#define ScriptProcessingData_h

#include "InternalMsg.h"
#include "ScriptProcessingDataBody.h"

class ScriptProcessingData : public InternalMsg
{
   public:

      ScriptProcessingData();
      ~ScriptProcessingData() = default;

      ScriptProcessingDataBody m_body;

      bool operator<(const ScriptProcessingData &rhs) const
      {
         return (m_body.Execution_Time < rhs.m_body.Execution_Time);
      }
};

#endif
