#ifndef InternalMsgHeader_h
#define InternalMsgHeader_h

#include "InternalMsgIdType.h"

class InternalMsgHeader
{
   public:

      InternalMsgHeader();
      ~InternalMsgHeader() = default;

      InternalMsgIdType::InternalMsgIdTypeEnum m_msg_id;
      unsigned int m_msg_size;
      double m_send_time;
      double m_receive_time;
      unsigned int m_sender_id;
      unsigned int m_receiver_id;
};

#endif
