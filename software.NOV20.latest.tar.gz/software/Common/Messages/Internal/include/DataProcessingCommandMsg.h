#ifndef DataProcessingCommandMsg_h
#define DataProcessingCommandMsg_h

#include "DataProcessingCommandMsgBody.h"
#include "InternalMsg.h"

class DataProcessingCommandMsg : public InternalMsg
{
   public:

      DataProcessingCommandMsg();
      ~DataProcessingCommandMsg() = default;

      DataProcessingCommandMsgBody m_body;
};

#endif
