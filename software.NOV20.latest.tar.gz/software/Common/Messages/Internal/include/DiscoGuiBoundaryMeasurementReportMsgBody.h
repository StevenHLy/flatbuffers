#ifndef DiscoGuiBoundaryMeasurementReportMsgBody_h
#define DiscoGuiBoundaryMeasurementReportMsgBody_h

class DiscoGuiBoundaryMeasurementReportMsgBody
{
   public:

      DiscoGuiBoundaryMeasurementReportMsgBody();
      ~DiscoGuiBoundaryMeasurementReportMsgBody() = default;
};

#endif
