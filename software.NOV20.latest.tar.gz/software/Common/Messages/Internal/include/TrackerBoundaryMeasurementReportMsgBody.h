#ifndef TrackerBoundaryMeasurementReportMsgBody_h
#define TrackerBoundaryMeasurementReportMsgBody_h

class TrackerBoundaryMeasurementReportMsgBody
{
   public:

      TrackerBoundaryMeasurementReportMsgBody();
      ~TrackerBoundaryMeasurementReportMsgBody() = default;
};

#endif
