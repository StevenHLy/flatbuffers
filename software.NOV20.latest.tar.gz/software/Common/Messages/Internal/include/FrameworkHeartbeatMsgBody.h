#ifndef FrameworkHeartbeatMsgBody_h
#define FrameworkHeartbeatMsgBody_h

class FrameworkHeartbeatMsgBody
{
   public:

      FrameworkHeartbeatMsgBody();
      ~FrameworkHeartbeatMsgBody() = default;

      char m_sending_node_name[128];
};

#endif
