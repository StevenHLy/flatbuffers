#include "SensorSchedulingRequestMsg.h"
#include "InternalMsgIdType.h"

SensorSchedulingRequestMsg::SensorSchedulingRequestMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_SENSOR_SCHEDULING_REQUEST;
   m_header.m_msg_size = sizeof(SensorSchedulingRequestMsg);
}
