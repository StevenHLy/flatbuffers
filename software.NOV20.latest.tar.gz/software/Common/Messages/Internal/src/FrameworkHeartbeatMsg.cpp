#include "FrameworkHeartbeatMsg.h"
#include "InternalMsgIdType.h"

FrameworkHeartbeatMsg::FrameworkHeartbeatMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_FRAMEWORK_HEARTBEAT;
   m_header.m_msg_size = sizeof(FrameworkHeartbeatMsg);
}
