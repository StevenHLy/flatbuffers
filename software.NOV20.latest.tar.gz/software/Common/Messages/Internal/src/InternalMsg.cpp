#include "InternalMsg.h"

InternalMsg::InternalMsg()
: m_header()
{
}
