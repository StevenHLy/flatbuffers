#include "DiscoGuiBoundaryMeasurementReportMsgBody.h"

DiscoGuiBoundaryMeasurementReportMsgBody::DiscoGuiBoundaryMeasurementReportMsgBody()
{
}
