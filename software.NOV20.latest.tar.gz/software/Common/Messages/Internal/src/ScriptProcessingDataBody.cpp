#include "ScriptProcessingDataBody.h"

ScriptProcessingDataBody::ScriptProcessingDataBody()
  : Command_Type(0)
  , Number_Of_Commands(0)
  , Slew_Commands()
  , Transmit_Commands()
  , Execution_Time(0.0)
  , Step_Name("")
{
}

void ScriptProcessingDataBody::setCommandType(const std::string &p_command_type)
{
   if ("SlewCommand" == p_command_type)
   {
      Command_Type = 1;
   }
   else if ("TransmitCommand" == p_command_type)
   {
      Command_Type = 2;
   }
}
