#include "DiscoGuiBoundaryMeasurementReportMsg.h"
#include "InternalMsgIdType.h"

DiscoGuiBoundaryMeasurementReportMsg::DiscoGuiBoundaryMeasurementReportMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_DISCO_GUI_BOUNDARY_MEASUREMENT_REPORT;
   m_header.m_msg_size = sizeof(DiscoGuiBoundaryMeasurementReportMsg);
}
