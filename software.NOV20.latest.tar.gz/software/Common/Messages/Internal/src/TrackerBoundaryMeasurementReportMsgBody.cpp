#include "TrackerBoundaryMeasurementReportMsgBody.h"

TrackerBoundaryMeasurementReportMsgBody::TrackerBoundaryMeasurementReportMsgBody()
{
}
