#include "RadarActionControlMsg.h"
#include "InternalMsgIdType.h"
#include <iostream>

RadarActionControlMsg::RadarActionControlMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_RADAR_ACTION_CONTROL;
   m_header.m_msg_size = sizeof(RadarActionControlMsg);

    
}
