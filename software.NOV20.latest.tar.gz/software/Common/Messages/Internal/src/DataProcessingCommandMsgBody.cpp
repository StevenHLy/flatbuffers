#include "DataProcessingCommandMsgBody.h"

DataProcessingCommandMsgBody::DataProcessingCommandMsgBody()
{
}
