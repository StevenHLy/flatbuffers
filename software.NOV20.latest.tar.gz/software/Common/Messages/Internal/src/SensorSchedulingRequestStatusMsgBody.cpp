#include "SensorSchedulingRequestStatusMsgBody.h"

SensorSchedulingRequestStatusMsgBody::SensorSchedulingRequestStatusMsgBody()
{
}
