#include "InternalMsgHeader.h"

InternalMsgHeader::InternalMsgHeader()
: m_msg_id(InternalMsgIdType::InternalMsgIdTypeEnum::UNKNOWN)
, m_msg_size(0)
, m_send_time(0.0)
, m_receive_time(0.0)
, m_sender_id(0)
, m_receiver_id(0)
{
}
