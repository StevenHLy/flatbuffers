#include "SensorSchedulingRequestMsgBody.h"

SensorSchedulingRequestMsgBody::SensorSchedulingRequestMsgBody()
  : Command_Type(0)
  , Number_Of_Commands(0)
  , Slew_Commands()
  , Transmit_Commands()
{
}
