#include "SensorSchedulingRequestStatusMsg.h"
#include "InternalMsgIdType.h"

SensorSchedulingRequestStatusMsg::SensorSchedulingRequestStatusMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_SENSOR_SCHEDULING_REQUEST_STATUS;
   m_header.m_msg_size = sizeof(SensorSchedulingRequestStatusMsg);
}
