#include "DataProcessingCommandMsg.h"
#include "InternalMsgIdType.h"

DataProcessingCommandMsg::DataProcessingCommandMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_DATA_PROCESSING_COMMAND;
   m_header.m_msg_size = sizeof(DataProcessingCommandMsg);
}
