#include "PlatformMeasurementDataMsgBody.h"

PlatformMeasurementDataMsgBody::PlatformMeasurementDataMsgBody()         
{
}
