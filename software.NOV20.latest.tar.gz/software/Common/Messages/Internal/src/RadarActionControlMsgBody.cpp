#include "RadarActionControlMsgBody.h"
#include <iostream>

RadarActionControlMsgBody::RadarActionControlMsgBody()
  : Command_Type()
  , Number_Of_Commands(0)
  , Slew_Commands()
  , Transmit_Commands()
{

    //@SL Testing fetching data  RAC --> SENSOR 
     //dish = RAC::Platform::Dickie;
     //command = RAC::CommandType::TransmitCommand;

    // dish = RAC::Platform::Penzias;
     //command = RAC::CommandType::TransmitCommand;
     //NumPulses = 1;
     //Count = 250; 

    //Test 1 : Passed
    //dish = RAC::Platform::Dickie; // Only works for Dickie now ? Penzias/ Wilson would crash 
    //command = RAC::CommandType::SlewCommand;
    //Azimuth = 205.0;
    //Elevation = 1.5;

    //Test 2 : Passed
    //dish = RAC::Platform::Dickie; // Only works for Dickie now ? Penzias/ Wilson would crash 
    //command = RAC::CommandType::TransmitCommand;
    //NumPulses = 1;
   // Count = 250; 
   
   //Testing
   //Command_Type = 2; 
   // Number_Of_Commands = 3;
}
