#include "RadarActionReturnMsgBody.h"

RadarActionReturnMsgBody::RadarActionReturnMsgBody()
{
}
