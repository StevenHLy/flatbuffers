#include "InternalMsgIdType.h"
#include <map>
#include <stdexcept>

namespace InternalMsgIdType
{
   std::string enumToString(InternalMsgIdType::InternalMsgIdTypeEnum p_enum)
   {
      static std::map<InternalMsgIdTypeEnum, std::string> enum_to_string_map =
      {
         {InternalMsgIdTypeEnum::UNKNOWN, "UNKNOWN"},
         {InternalMsgIdTypeEnum::MT_FRAMEWORK_HEARTBEAT, "MT_FRAMEWORK_HEARTBEAT"},
         {InternalMsgIdTypeEnum::MT_SENSOR_SCHEDULING_REQUEST, "MT_SENSOR_SCHEDULING_REQUEST"},
         {InternalMsgIdTypeEnum::MT_RADAR_ACTION_CONTROL, "MT_RADAR_ACTION_CONTROL"},
         {InternalMsgIdTypeEnum::MT_SIGNAL_PROCESSING_COMMAND, "MT_SIGNAL_PROCESSING_COMMAND"},
         {InternalMsgIdTypeEnum::MT_DATA_PROCESSING_COMMAND, "MT_DATA_PROCESSING_COMMAND"},
         {InternalMsgIdTypeEnum::MT_RADAR_ACTION_RETURN, "MT_RADAR_ACTION_RETURN"},
         {InternalMsgIdTypeEnum::MT_SENSOR_SCHEDULING_REQUEST_STATUS, "MT_SENSOR_SCHEDULING_REQUEST_STATUS"},
         {InternalMsgIdTypeEnum::MT_PLATFORM_MEASUREMENT_DATA, "MT_PLATFORM_MEASUREMENT_DATA"},
         {InternalMsgIdTypeEnum::MT_DISCO_GUI_BOUNDARY_MEASUREMENT_REPORT, "MT_DISCO_GUI_BOUNDARY_MEASUREMENT_REPORT"},
         {InternalMsgIdTypeEnum::MT_TRACKER_BOUNDARY_MEASUREMENT_REPORT, "MT_TRACKER_BOUNDARY_MEASUREMENT_REPORT"},
         {InternalMsgIdTypeEnum::MT_SCRIPT_PROCESSING_DATA,"MT_SCRIPT_PROCESSING_DATA"}
      };

      try
      {
         return enum_to_string_map.at(p_enum);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("InternalMsgIdType::enumToString() - invalid enum (" + std::to_string(static_cast<unsigned int>(p_enum)) + ")");
      }
   }

   InternalMsgIdType::InternalMsgIdTypeEnum stringToEnum(const std::string& p_enum_string)
   {
      static std::map<std::string, InternalMsgIdTypeEnum> string_to_enum_map =
      {
         {"UNKNOWN", InternalMsgIdTypeEnum::UNKNOWN},
         {"MT_FRAMEWORK_HEARTBEAT", InternalMsgIdTypeEnum::MT_FRAMEWORK_HEARTBEAT},
         {"MT_SENSOR_SCHEDULING_REQUEST", InternalMsgIdTypeEnum::MT_SENSOR_SCHEDULING_REQUEST},
         {"MT_RADAR_ACTION_CONTROL", InternalMsgIdTypeEnum::MT_RADAR_ACTION_CONTROL},
         {"MT_SIGNAL_PROCESSING_COMMAND", InternalMsgIdTypeEnum::MT_SIGNAL_PROCESSING_COMMAND},
         {"MT_DATA_PROCESSING_COMMAND", InternalMsgIdTypeEnum::MT_DATA_PROCESSING_COMMAND},
         {"MT_RADAR_ACTION_RETURN", InternalMsgIdTypeEnum::MT_RADAR_ACTION_RETURN},
         {"MT_SENSOR_SCHEDULING_REQUEST_STATUS", InternalMsgIdTypeEnum::MT_SENSOR_SCHEDULING_REQUEST_STATUS},
         {"MT_PLATFORM_MEASUREMENT_DATA", InternalMsgIdTypeEnum::MT_PLATFORM_MEASUREMENT_DATA},
         {"MT_DISCO_GUI_BOUNDARY_MEASUREMENT_REPORT", InternalMsgIdTypeEnum::MT_DISCO_GUI_BOUNDARY_MEASUREMENT_REPORT},
         {"MT_TRACKER_BOUNDARY_MEASUREMENT_REPORT", InternalMsgIdTypeEnum::MT_TRACKER_BOUNDARY_MEASUREMENT_REPORT},
         {"MT_SCRIPT_PROCESSING_DATA", InternalMsgIdTypeEnum::MT_SCRIPT_PROCESSING_DATA}
      };

      try
      {
         return string_to_enum_map.at(p_enum_string);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("InternalMsgIdType::stringToEnum() - invalid enum string (" + p_enum_string + ")");
      }
   }
}
