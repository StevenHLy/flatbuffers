#include "RadarActionReturnMsg.h"
#include "InternalMsgIdType.h"

RadarActionReturnMsg::RadarActionReturnMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_RADAR_ACTION_RETURN;
   m_header.m_msg_size = sizeof(RadarActionReturnMsg);
}
