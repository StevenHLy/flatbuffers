#include "TrackerBoundaryMeasurementReportMsg.h"
#include "InternalMsgIdType.h"

TrackerBoundaryMeasurementReportMsg::TrackerBoundaryMeasurementReportMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_TRACKER_BOUNDARY_MEASUREMENT_REPORT;
   m_header.m_msg_size = sizeof(TrackerBoundaryMeasurementReportMsg);
}
