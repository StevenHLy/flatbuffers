#include "PlatformMeasurementDataMsg.h"
#include "InternalMsgIdType.h"

PlatformMeasurementDataMsg::PlatformMeasurementDataMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_PLATFORM_MEASUREMENT_DATA;
   m_header.m_msg_size = sizeof(PlatformMeasurementDataMsg);
}
