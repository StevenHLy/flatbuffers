#include "SignalProcessingCommandMsg.h"
#include "InternalMsgIdType.h"

SignalProcessingCommandMsg::SignalProcessingCommandMsg()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_SIGNAL_PROCESSING_COMMAND;
   m_header.m_msg_size = sizeof(SignalProcessingCommandMsg);
}
