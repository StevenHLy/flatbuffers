#include "FrameworkHeartbeatMsgBody.h"

FrameworkHeartbeatMsgBody::FrameworkHeartbeatMsgBody()
: m_sending_node_name{0}
{
}
