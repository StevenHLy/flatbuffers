#include "ScriptProcessingData.h"
#include "InternalMsgIdType.h"

ScriptProcessingData::ScriptProcessingData()
: InternalMsg()
{
   m_header.m_msg_id = InternalMsgIdType::InternalMsgIdTypeEnum::MT_SCRIPT_PROCESSING_DATA;
   m_header.m_msg_size = sizeof(ScriptProcessingData);
}
