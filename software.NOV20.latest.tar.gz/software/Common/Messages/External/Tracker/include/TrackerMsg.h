#ifndef TrackerMsg_h
#define TrackerMsg_h

#include "TrackerMsgHeader.h"

class TrackerMsg
{
   public:

      TrackerMsg();
      ~TrackerMsg() = default;

      TrackerMsgHeader m_header;
};

#endif
