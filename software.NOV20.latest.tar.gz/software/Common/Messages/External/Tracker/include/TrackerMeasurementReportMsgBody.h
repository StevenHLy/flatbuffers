#ifndef TrackerMeasurementReportMsgBody_h
#define TrackerMeasurementReportMsgBody_h

class TrackerMeasurementReportMsgBody
{
   public:

      TrackerMeasurementReportMsgBody();
      ~TrackerMeasurementReportMsgBody() = default;
};

#endif
