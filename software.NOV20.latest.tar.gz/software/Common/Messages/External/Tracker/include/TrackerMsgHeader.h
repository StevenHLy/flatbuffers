#ifndef TrackerMsgHeader_h
#define TrackerMsgHeader_h

#include "TrackerMsgIdType.h"

class TrackerMsgHeader
{
   public:

      TrackerMsgHeader();
      ~TrackerMsgHeader() = default;

      TrackerMsgIdType::TrackerMsgIdTypeEnum m_msg_id;
      unsigned int m_msg_size;
      double m_send_time;
      double m_receive_time;
};

#endif
