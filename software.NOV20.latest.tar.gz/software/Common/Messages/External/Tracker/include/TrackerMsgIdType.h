#ifndef TrackerMsgIdType_h
#define TrackerMsgIdType_h

#include <string>

namespace TrackerMsgIdType
{
   enum class TrackerMsgIdTypeEnum : unsigned int
   {
      TRACKER_MT_UNKNOWN            = 0,
      TRACKER_MT_MEASUREMENT_REPORT = 3000
   };

   std::string enumToString(TrackerMsgIdType::TrackerMsgIdTypeEnum p_enum);
   TrackerMsgIdType::TrackerMsgIdTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
