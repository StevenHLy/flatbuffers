#ifndef TrackerMeasurementReportMsg_h
#define TrackerMeasurementReportMsg_h

#include "TrackerMsg.h"
#include "TrackerMeasurementReportMsgBody.h"

class TrackerMeasurementReportMsg : public TrackerMsg
{
   public:

      TrackerMeasurementReportMsg();
      ~TrackerMeasurementReportMsg() = default;

      TrackerMeasurementReportMsgBody m_body;
};

#endif
