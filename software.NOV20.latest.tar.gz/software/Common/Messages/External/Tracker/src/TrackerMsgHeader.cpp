#include "TrackerMsgHeader.h"

TrackerMsgHeader::TrackerMsgHeader()
: m_msg_id(TrackerMsgIdType::TrackerMsgIdTypeEnum::TRACKER_MT_UNKNOWN)
, m_msg_size(0)
, m_send_time(0.0)
, m_receive_time(0.0)
{
}
