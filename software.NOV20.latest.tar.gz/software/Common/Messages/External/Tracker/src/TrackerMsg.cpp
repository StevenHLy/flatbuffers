#include "TrackerMsg.h"

TrackerMsg::TrackerMsg()
: m_header()
{
}
