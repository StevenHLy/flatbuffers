#include "TrackerMeasurementReportMsgBody.h"

TrackerMeasurementReportMsgBody::TrackerMeasurementReportMsgBody()
{
}
