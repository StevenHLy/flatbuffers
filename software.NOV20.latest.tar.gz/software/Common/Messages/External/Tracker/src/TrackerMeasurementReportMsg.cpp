#include "TrackerMeasurementReportMsg.h"
#include "TrackerMsgIdType.h"

TrackerMeasurementReportMsg::TrackerMeasurementReportMsg()
: TrackerMsg()
{
   m_header.m_msg_id = TrackerMsgIdType::TrackerMsgIdTypeEnum::TRACKER_MT_MEASUREMENT_REPORT;
   m_header.m_msg_size = sizeof(TrackerMeasurementReportMsg);
}
