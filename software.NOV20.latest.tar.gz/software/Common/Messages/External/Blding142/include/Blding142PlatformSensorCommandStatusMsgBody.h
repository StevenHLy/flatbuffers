#ifndef Blding142PlatformSensorCommandStatusMsgBody_h
#define Blding142PlatformSensorCommandStatusMsgBody_h
#include <string>
//@SL

class Blding142PlatformSensorCommandStatusMsgBody
{
   public:

      Blding142PlatformSensorCommandStatusMsgBody();
     ~Blding142PlatformSensorCommandStatusMsgBody() = default;
   

      struct Slew
      {
         Slew()
           : Azimuth_Degrees(0.0)
	        , Elevation_Degrees(0.0)
         {
         }
         int Dish;
         double Azimuth_Degrees;
         double Elevation_Degrees;
      }; 

      char Dish[128];
      int Command_Type;
      Slew Slew_Command;


};

#endif
