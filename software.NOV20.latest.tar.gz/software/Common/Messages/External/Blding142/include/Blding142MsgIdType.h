#ifndef Blding142MsgIdType_h
#define Blding142MsgIdType_h

#include <string>

namespace Blding142MsgIdType
{
   enum class Blding142MsgIdTypeEnum : unsigned int
   {
      BLDING142_MT_UNKNOWN                        = 0,
      BLDING142_MT_PLATFORM_SENSOR_COMMAND        = 2000,
      BLDING142_MT_PLATFORM_SENSOR_COMMAND_STATUS = 2001,
      BLDING142_MT_PLATFORM_MEASUREMENT_DATA      = 2002
   };

   std::string enumToString(Blding142MsgIdType::Blding142MsgIdTypeEnum p_enum);
   Blding142MsgIdType::Blding142MsgIdTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
