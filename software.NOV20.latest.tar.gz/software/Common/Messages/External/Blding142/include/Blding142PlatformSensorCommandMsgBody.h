#ifndef Blding142PlatformSensorCommandMsgBody_h
#define Blding142PlatformSensorCommandMsgBody_h
#include <string>

class Blding142PlatformSensorCommandMsgBody
{
   public:

      Blding142PlatformSensorCommandMsgBody();
     ~Blding142PlatformSensorCommandMsgBody() = default;

      struct Slew
      {
         Slew()
           : Azimuth_Degrees(0.0)
	   , Elevation_Degrees(0.0)
         {
         }
         int Dish;
         double Azimuth_Degrees;
         double Elevation_Degrees;
      };

      struct Transmit
      {
         Transmit()
           : Pulsewidth_usec(0.0)
           , Amplitude(0.0)
           , Bandwidth_MHz(0)
           , Phase_Offsec_psec(0.0)
           , Offset_MHz(0)
           , Samples_Per_Chip(0)
           , Gold_Code_Index(0)
           , Num_Pulses(0)
           , Repetition_Count(0)
         {
         }


         //waveform start
         double Pulsewidth_usec;
         double Amplitude;
         int Bandwidth_MHz;
         double Phase_Offsec_psec;
         int Offset_MHz;
         int Samples_Per_Chip;
         int Gold_Code_Index;
         //waveform end
         int Num_Pulses;
         int Repetition_Count;
      };

      char Dish[128];
      int Command_Type;
      Slew Slew_Command;
      Transmit Transmit_Command;

};

#endif
