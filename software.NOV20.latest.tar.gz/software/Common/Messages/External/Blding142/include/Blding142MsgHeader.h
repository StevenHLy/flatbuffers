#ifndef Blding142MsgHeader_h
#define Blding142MsgHeader_h

#include "Blding142MsgIdType.h"

class Blding142MsgHeader
{
   public:

      Blding142MsgHeader();
      ~Blding142MsgHeader() = default;

      Blding142MsgIdType::Blding142MsgIdTypeEnum m_msg_id;
      unsigned int m_msg_size;
      unsigned int m_platform_id;
      unsigned int m_connection_id;
      double m_send_time;
      double m_receive_time;
};

#endif
