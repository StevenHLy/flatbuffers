#ifndef Blding142PlatformMeasurementDataMsg_h
#define Blding142PlatformMeasurementDataMsg_h

#include "Blding142Msg.h"
#include "Blding142PlatformMeasurementDataMsgBody.h"

class Blding142PlatformMeasurementDataMsg : public Blding142Msg
{
   public:

      Blding142PlatformMeasurementDataMsg();
      ~Blding142PlatformMeasurementDataMsg() = default;

      Blding142PlatformMeasurementDataMsgBody m_body;
};

#endif
