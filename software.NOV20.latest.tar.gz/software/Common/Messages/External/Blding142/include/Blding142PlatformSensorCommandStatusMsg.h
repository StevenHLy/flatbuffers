#ifndef Blding142PlatformSensorCommandStatusMsg_h
#define Blding142PlatformSensorCommandStatusMsg_h

#include "Blding142Msg.h"
#include "Blding142PlatformSensorCommandStatusMsgBody.h"

class Blding142PlatformSensorCommandStatusMsg : public Blding142Msg
{
   public:

      Blding142PlatformSensorCommandStatusMsg();
      ~Blding142PlatformSensorCommandStatusMsg() = default;

      Blding142PlatformSensorCommandStatusMsgBody m_body;
};

#endif
