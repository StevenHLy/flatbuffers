#ifndef Blding142PlatformMeasurementDataMsgBody_h
#define Blding142PlatformMeasurementDataMsgBody_h

#include<iostream>
#include<vector>
#include<thread>
#include<chrono>
#include<iomanip>
#include<random>

#include <string>

class Blding142PlatformMeasurementDataMsgBody
{
   public:

      Blding142PlatformMeasurementDataMsgBody();
     ~Blding142PlatformMeasurementDataMsgBody() = default;

      //12 fields and WF data    
      //@@SL
      struct Data
      {
         double snr;
         double rng;
         double time_stamp;   
         double truth_rng;               
      };


      struct Transmit
      {
         Transmit()
	   : Dish(0)
           , Pulsewidth_usec(0.0)
           , Amplitude(0.0)
           , Bandwidth_MHz(0)
           , Phase_Offsec_psec(0.0)
           , Offset_MHz(0)
           , Samples_Per_Chip(0)
           , Gold_Code_Index(0)
           , Num_Pulses(0)
           , Repetition_Count(0)
         {
         }

         int Dish;
         //waveform start
         double Pulsewidth_usec;
         double Amplitude;
         int Bandwidth_MHz;
         double Phase_Offsec_psec;
         int Offset_MHz;
         int Samples_Per_Chip;
         int Gold_Code_Index;
         //waveform end
         int Num_Pulses;
         int Repetition_Count;
      };
      


      static std::string getCurrentTime()
      {
         auto now = std::chrono::system_clock::now();
         std::time_t current_time = std::chrono::system_clock::to_time_t(now);
         std::tm* local_time = std::localtime(&current_time);

         std::ostringstream time_stream;
         time_stream << std::put_time(local_time, "%H:%M:%S");
         return time_stream.str();
      }

   
      void executeSensorCommands(int count , std::string dish);

      bool activeDish(int dish);

      void generateData(int count);

      std::string serialize() const;

      std::string vectorToString(const std::vector<double>& vec) const;

      void printSampleData() const; 

      const std::vector<double>& getC1() const;
      const std::vector<double>& getC2() const;
      const std::vector<double>& getC3() const;

      double generateRandomDouble (double min, double max ) const;

      //@@JZ
      Data m_penzias;
      Data m_wilson;
      Data m_dickie;

      char Dish[128];
      int Command_Type;
      Transmit Transmit_Command;


      private:

      std::vector<double> c1; //dish1
      std::vector<double> c2; //dish2
      std::vector<double> c3; //dish3


};

#endif
