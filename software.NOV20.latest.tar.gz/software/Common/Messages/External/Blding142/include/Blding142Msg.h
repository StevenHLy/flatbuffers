#ifndef Blding142Msg_h
#define Blding142Msg_h

#include "Blding142MsgHeader.h"

class Blding142Msg
{
   public:

      Blding142Msg();
      ~Blding142Msg() = default;

      Blding142MsgHeader m_header;
};

#endif
