#ifndef Blding142PlatformSensorCommandMsg_h
#define Blding142PlatformSensorCommandMsg_h

#include "Blding142Msg.h"
#include "Blding142PlatformSensorCommandMsgBody.h"




class Blding142PlatformSensorCommandMsg : public Blding142Msg
{
   public:

      Blding142PlatformSensorCommandMsg();
      ~Blding142PlatformSensorCommandMsg() = default;

      Blding142PlatformSensorCommandMsgBody m_body;

   

      
};

#endif
