#include "Blding142PlatformMeasurementDataMsg.h"
#include "Blding142MsgIdType.h"

Blding142PlatformMeasurementDataMsg::Blding142PlatformMeasurementDataMsg()
: Blding142Msg()
{
   m_header.m_msg_id = Blding142MsgIdType::Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_MEASUREMENT_DATA;
   m_header.m_msg_size = sizeof(Blding142PlatformMeasurementDataMsg);


   
}
