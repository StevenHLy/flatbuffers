#include "Blding142Msg.h"

Blding142Msg::Blding142Msg()
: m_header()
{
}
