#include "Blding142PlatformSensorCommandStatusMsgBody.h"

Blding142PlatformSensorCommandStatusMsgBody::Blding142PlatformSensorCommandStatusMsgBody()
{
}
