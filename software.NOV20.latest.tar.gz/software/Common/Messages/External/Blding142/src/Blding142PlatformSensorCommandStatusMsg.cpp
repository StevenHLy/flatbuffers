#include "Blding142PlatformSensorCommandStatusMsg.h"
#include "Blding142MsgIdType.h"

Blding142PlatformSensorCommandStatusMsg::Blding142PlatformSensorCommandStatusMsg()
: Blding142Msg()
{
   m_header.m_msg_id = Blding142MsgIdType::Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_SENSOR_COMMAND_STATUS;
   m_header.m_msg_size = sizeof(Blding142PlatformSensorCommandStatusMsg);
}
