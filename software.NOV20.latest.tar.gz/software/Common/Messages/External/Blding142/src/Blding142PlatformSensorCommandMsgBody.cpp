#include "Blding142PlatformSensorCommandMsgBody.h"

Blding142PlatformSensorCommandMsgBody::Blding142PlatformSensorCommandMsgBody()
{

}



