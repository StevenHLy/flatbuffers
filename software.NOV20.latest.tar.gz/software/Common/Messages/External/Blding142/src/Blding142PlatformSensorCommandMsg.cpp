#include "Blding142PlatformSensorCommandMsg.h"
#include "Blding142MsgIdType.h"

Blding142PlatformSensorCommandMsg::Blding142PlatformSensorCommandMsg()
: Blding142Msg()
{
   m_header.m_msg_id = Blding142MsgIdType::Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_SENSOR_COMMAND;
   m_header.m_msg_size = sizeof(Blding142PlatformSensorCommandMsg);

}


