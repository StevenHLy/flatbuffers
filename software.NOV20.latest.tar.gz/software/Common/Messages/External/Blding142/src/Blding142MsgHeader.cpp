#include "Blding142MsgHeader.h"

Blding142MsgHeader::Blding142MsgHeader()
: m_msg_id(Blding142MsgIdType::Blding142MsgIdTypeEnum::BLDING142_MT_UNKNOWN)
, m_msg_size(0)
, m_platform_id(0)
, m_connection_id(0)
, m_send_time(0.0)
, m_receive_time(0.0)
{
}
