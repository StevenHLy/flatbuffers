#include "Blding142PlatformMeasurementDataMsgBody.h"


//@SL
Blding142PlatformMeasurementDataMsgBody::Blding142PlatformMeasurementDataMsgBody() 
{
    c1 = std::vector<double>(4,0.0);
    c2 = std::vector<double>(4,0.0);
    c3 = std::vector<double>(4,0.0);
}

void Blding142PlatformMeasurementDataMsgBody::generateData(int count) 
{

    c1 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(count), 6950.0};
    c2 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(count), 6950.0};
    c3 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(count), 6950.0};
}


 double Blding142PlatformMeasurementDataMsgBody::generateRandomDouble (double min, double max ) const
{
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis (min,max);
    return dis(gen);
}

std::string Blding142PlatformMeasurementDataMsgBody::serialize() const 
{
    std::ostringstream oss;
    // oss << std::fixed << std::setprecision(4) << azimuth << " " << elevation << " ";
    for (double val : c1) oss << val << " ";
    //for (double val : c2) oss << val << " ";
    //for (double val : c3) oss << val << " ";
    return oss.str();

}

std::string Blding142PlatformMeasurementDataMsgBody::vectorToString(const std::vector<double>& vec) const {
    std::ostringstream oss;
    for (const auto& val : vec) {
        oss << val << " ";
    }
    return oss.str();
}


void Blding142PlatformMeasurementDataMsgBody::printSampleData() const 
{
    std::string serializedData = serialize();
    std::cout << "Sample Data: " << serializedData << std::endl;
}

const std::vector<double>& Blding142PlatformMeasurementDataMsgBody::getC1() const 
{
    return c1;
}

const std::vector<double>& Blding142PlatformMeasurementDataMsgBody::getC2() const 
{
    return c2;
}
const std::vector<double>& Blding142PlatformMeasurementDataMsgBody::getC3() const 
{
    return c3;
}

bool Blding142PlatformMeasurementDataMsgBody::activeDish(int dish)
{
   bool active = false; 
   if (dish ==1) //Dickie
   {
    m_penzias.snr = -1.0;
    m_penzias.rng = -1.0;
    m_penzias.time_stamp = -1.0;
    m_penzias.truth_rng = -1.0;
    m_wilson.snr = -1.0;
    m_wilson.rng = -1.0;
    m_wilson.time_stamp = -1.0;
    m_wilson.truth_rng = -1.0;
    active = true; 
   }
   else if (dish ==2) //Penzias
   {
    m_dickie.snr = -1.0;
    m_dickie.rng = -1.0;
    m_dickie.time_stamp = -1.0;
    m_dickie.truth_rng = -1.0;
    m_wilson.snr = -1.0;
    m_wilson.rng = -1.0;
    m_wilson.time_stamp = -1.0;
    m_wilson.truth_rng = -1.0;
    active = true; 
   }
   else if (dish ==3)// Wilson
   {
    m_dickie.snr = -1.0;
    m_dickie.rng = -1.0;
    m_dickie.time_stamp = -1.0;
    m_dickie.truth_rng = -1.0;
    m_penzias.snr = -1.0;
    m_penzias.rng = -1.0;
    m_penzias.time_stamp = -1.0;
    m_penzias.truth_rng = -1.0;

    active = true; 
   }

   return active;
}

void Blding142PlatformMeasurementDataMsgBody::executeSensorCommands(int count, std::string dish ) 
{

        // Print current time before executing the command
        std::string current_time = getCurrentTime();
        std::cout << "[" << current_time << "] ";

        // Simulate the transmission being repeated according to repetition_count
        for (int i = 0; i < count; ++i)
        {
            std::cout << "  Transmission " << (i + 1) << "/" << count << std::endl;

            std::cout << "Executing Transmit Command - Iteration " << (i + 1) << ":\n";
            generateData(i+1);

           // std::cout << "c1: " << vectorToString(getC1()) << std::endl;

        
            //@@JZ
            if (dish == "Dickie" && activeDish(1))
            {
                m_dickie.snr =  c1[0]; //@SL
                m_dickie.rng =  c1[1];
                m_dickie.time_stamp = c1[2];
                m_dickie.truth_rng =  c1[3];

                std::cout <<"Dickie: " << m_dickie.snr<<"||"<<m_dickie.rng<<"||"<<m_dickie.time_stamp<<"||"<< m_dickie.truth_rng<<std::endl;
                std::cout <<"Penzias: " << m_penzias.snr<<"||"<<m_penzias.rng<<"||"<<m_penzias.time_stamp<<"||"<< m_penzias.truth_rng<<std::endl;
                std::cout <<"Wilson: " << m_wilson.snr<<"||"<<m_wilson.rng<<"||"<<m_wilson.time_stamp<<"||"<< m_wilson.truth_rng<<std::endl;

            }
            else if (dish == "Penzias" && activeDish(2))
            {
                m_penzias.snr = c2[0];
                m_penzias.rng = c2[1];
                m_penzias.time_stamp = c2[2];
                m_penzias.truth_rng = c2[3];
                std::cout << "Penzias:  "<< m_penzias.snr<<"||"<<m_penzias.rng<<"||"<<m_penzias.time_stamp<<"||"<< m_penzias.truth_rng<<std::endl;
                std::cout <<"Dickie: " << m_dickie.snr<<"||"<<m_dickie.rng<<"||"<<m_dickie.time_stamp<<"||"<< m_dickie.truth_rng<<std::endl;
                std::cout <<"Wilson: " << m_wilson.snr<<"||"<<m_wilson.rng<<"||"<<m_wilson.time_stamp<<"||"<< m_wilson.truth_rng<<std::endl;

            }
            else if ( (dish == "Wilson" && activeDish(3)))
            {
                m_wilson.snr = c3[0];
                m_wilson.rng = c3[1];
                m_wilson.time_stamp = c3[2];
                m_wilson.truth_rng =c1[3];
                std::cout << "Wilson:  "<< m_wilson.snr<<"||"<<m_wilson.rng<<"||"<<m_wilson.time_stamp<<"||"<< m_wilson.truth_rng<<std::endl;
                std::cout << "Penzias:  "<< m_penzias.snr<<"||"<<m_penzias.rng<<"||"<<m_penzias.time_stamp<<"||"<< m_penzias.truth_rng<<std::endl;
                std::cout <<"Dickie: " << m_dickie.snr<<"||"<<m_dickie.rng<<"||"<<m_dickie.time_stamp<<"||"<< m_dickie.truth_rng<<std::endl;
            }
            std::cout << "\n----------------------------------------\n";


        }
}






