#include "Blding142MsgIdType.h"
#include <map>
#include <stdexcept>

namespace Blding142MsgIdType
{
   std::string enumToString(Blding142MsgIdType::Blding142MsgIdTypeEnum p_enum)
   {
      static std::map<Blding142MsgIdTypeEnum, std::string> enum_to_string_map =
      {
         {Blding142MsgIdTypeEnum::BLDING142_MT_UNKNOWN, "BLDING142_MT_UNKNOWN"},
         {Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_SENSOR_COMMAND, "BLDING142_MT_PLATFORM_SENSOR_COMMAND"},
         {Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_SENSOR_COMMAND_STATUS, "BLDING142_MT_PLATFORM_SENSOR_COMMAND_STATUS"},
         {Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_MEASUREMENT_DATA, "BLDING142_MT_PLATFORM_MEASUREMENT_DATA"}
      };

      try
      {
         return enum_to_string_map.at(p_enum);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("Blding142MsgIdType::enumToString() - invalid enum (" + std::to_string(static_cast<unsigned int>(p_enum)) + ")");
      }
   }

   Blding142MsgIdType::Blding142MsgIdTypeEnum stringToEnum(const std::string& p_enum_string)
   {
      static std::map<std::string, Blding142MsgIdTypeEnum> string_to_enum_map =
      {
         {"BLDING142_MT_UNKNOWN", Blding142MsgIdTypeEnum::BLDING142_MT_UNKNOWN},
         {"BLDING142_MT_PLATFORM_SENSOR_COMMAND", Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_SENSOR_COMMAND},
         {"BLDING142_MT_PLATFORM_SENSOR_COMMAND_STATUS", Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_SENSOR_COMMAND_STATUS},
         {"BLDING142_MT_PLATFORM_MEASUREMENT_DATA", Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_MEASUREMENT_DATA}
      };

      try
      {
         return string_to_enum_map.at(p_enum_string);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("Blding142MsgIdType::stringToEnum() - invalid enum string (" + p_enum_string + ")");
      }
   }
}
