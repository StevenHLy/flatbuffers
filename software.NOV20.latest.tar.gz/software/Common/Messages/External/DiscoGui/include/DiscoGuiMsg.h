#ifndef DiscoGuiMsg_h
#define DiscoGuiMsg_h

class DiscoGuiMsg
{
   public:

      DiscoGuiMsg();
      ~DiscoGuiMsg() = default;
};

#endif
