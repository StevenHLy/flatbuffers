#ifndef DiscoGuiMeasurementReportMsg_h
#define DiscoGuiMeasurementReportMsg_h

#include "DiscoGuiMsg.h"

class DiscoGuiMeasurementReportMsg : public DiscoGuiMsg
{
   public:

      DiscoGuiMeasurementReportMsg();
      ~DiscoGuiMeasurementReportMsg() = default;
};

#endif
