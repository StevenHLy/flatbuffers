#include "DiscoGuiMeasurementReportMsg.h"

DiscoGuiMeasurementReportMsg::DiscoGuiMeasurementReportMsg()
: DiscoGuiMsg()
{
}
