#include "DiscoGuiMsg.h"

DiscoGuiMsg::DiscoGuiMsg()
{
}
