#include "SigTermException.h"

SigTermException::SigTermException(const char* p_filename,
                                   int p_line_number)
: DscException(p_filename, p_line_number)
{
   setMessage("SIGTERM signal received");
}
