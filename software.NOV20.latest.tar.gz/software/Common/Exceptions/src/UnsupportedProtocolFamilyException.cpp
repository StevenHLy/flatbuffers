#include "UnsupportedProtocolFamilyException.h"

UnsupportedProtocolFamilyException::UnsupportedProtocolFamilyException(const char* p_filename,
                                                                       int p_line_number)
: DscException(p_filename, p_line_number)
{
   setMessage("Unsupported protocol family (must use IPV4)");
}
