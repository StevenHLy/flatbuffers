#include "FailedToConnectException.h"
#include <cstring>
#include <string>

FailedToConnectException::FailedToConnectException(const char* p_filename,
                                                   int p_line_number,
                                                   int p_errno)
: DscException(p_filename, p_line_number)
{
   setMessage("failed to connect to peer - " + std::string(strerror(p_errno)));
}
