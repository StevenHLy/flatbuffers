#include "SystemCallException.h"
#include <cstring>

SystemCallException::SystemCallException(const char* p_filename,
                                         int p_line_number,
                                         const std::string& p_system_call,
                                         int p_errno)
: DscException(p_filename, p_line_number)
{
   setMessage(p_system_call + " error (" + std::string(strerror(p_errno)) + ")");
}
