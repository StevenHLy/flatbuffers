#include "PollingIdNotRegisteredException.h"

PollingIdNotRegisteredException::PollingIdNotRegisteredException(const char* p_filename,
                                                                 int p_line_number,
                                                                 unsigned int p_id)
: DscException(p_filename, p_line_number)
{
   setMessage("polling id (" + std::to_string(p_id) + ") not registered");
}
