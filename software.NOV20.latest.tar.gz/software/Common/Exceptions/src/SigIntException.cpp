#include "SigIntException.h"

SigIntException::SigIntException(const char* p_filename,
                                 int p_line_number)
: DscException(p_filename, p_line_number)
{
   setMessage("SIGINT signal received");
}
