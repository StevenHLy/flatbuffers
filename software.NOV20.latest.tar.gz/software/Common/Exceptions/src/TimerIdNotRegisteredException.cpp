#include "TimerIdNotRegisteredException.h"

TimerIdNotRegisteredException::TimerIdNotRegisteredException(const char* p_filename,
                                                             int p_line_number,
                                                             unsigned int p_id)
: DscException(p_filename, p_line_number)
{
   setMessage("timer (" + std::to_string(p_id) + ") not registered");
}
