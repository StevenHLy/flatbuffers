#include "InvalidFileExtensionException.h"

InvalidFileExtensionException::InvalidFileExtensionException(const char* p_filename,
                                                             int p_line_number,
                                                             const std::string& p_file_extension)
: DscException(p_filename, p_line_number)
{
   setMessage("invalid file extension " + p_file_extension);
}
