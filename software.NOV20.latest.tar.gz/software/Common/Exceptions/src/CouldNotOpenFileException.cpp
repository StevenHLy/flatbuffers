#include "CouldNotOpenFileException.h"

CouldNotOpenFileException::CouldNotOpenFileException(const char* p_filename,
                                                     int p_line_number,
                                                     const std::string& p_filename_to_open)
: DscException(p_filename, p_line_number)
{
   setMessage("could not open file " + p_filename_to_open);
}
