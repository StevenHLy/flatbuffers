#include "DscException.h"

DscException::DscException(const char* p_filename,
                           int p_line_number)
: m_line_number(p_line_number)
, m_filename(p_filename)
{
}

void DscException::setMessage(const std::string& p_message)
{
   m_message = p_message + " [" + m_filename + ":" + std::to_string(m_line_number) + "]";
}

const char* DscException::what() const noexcept
{
   return (m_message.c_str());
}
