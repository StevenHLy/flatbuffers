#include "PeerDisconnectException.h"

PeerDisconnectException::PeerDisconnectException(const char* p_filename,
                                                 int p_line_number)
: DscException(p_filename, p_line_number)
{
   setMessage("peer disconnected");
}
