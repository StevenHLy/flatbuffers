#include "AbortProcessException.h"

AbortProcessException::AbortProcessException(const char* p_filename,
                                             int p_line_number)
: DscException(p_filename, p_line_number)
{
   setMessage("abortProcess() called");
}
