#ifndef SystemCallException_h
#define SystemCallException_h

#include "DscException.h"
#include <string>

class SystemCallException : public DscException
{
   public:

      SystemCallException(const char* p_filename,
                          int p_line_number,
                          const std::string& p_system_call,
                          int p_errno = 0);
      virtual ~SystemCallException() = default;
};

#endif
