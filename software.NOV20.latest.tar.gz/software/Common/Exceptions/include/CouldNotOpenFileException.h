#ifndef CouldNotOpenFileException_h
#define CouldNotOpenFileException_h

#include "DscException.h"
#include <string>

class CouldNotOpenFileException : public DscException
{
   public:

      CouldNotOpenFileException(const char* p_filename,
                                int p_line_number,
                                const std::string& p_filename_to_open);
      virtual ~CouldNotOpenFileException() = default;
};

#endif
