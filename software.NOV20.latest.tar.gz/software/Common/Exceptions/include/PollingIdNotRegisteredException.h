#ifndef PollingIdNotRegisteredException_h
#define PollingIdNotRegisteredException_h

#include "DscException.h"

class PollingIdNotRegisteredException : public DscException
{
   public:

      PollingIdNotRegisteredException(const char* p_filename,
                                      int p_line_number,
                                      unsigned int p_id);
      virtual ~PollingIdNotRegisteredException() = default;
};

#endif
