#ifndef DscException_h
#define DscException_h

#include <exception>
#include <string>

class DscException : public std::exception
{
   public:

      virtual ~DscException() = default;

      virtual const char* what() const noexcept override;

   protected:

      DscException(const char* p_filename,
                   int p_line_number);

      void setMessage(const std::string& p_message);

      int m_line_number;
      std::string m_filename;
      std::string m_message;
};

#endif
