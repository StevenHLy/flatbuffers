#ifndef AbortProcessException_h
#define AbortProcessException_h

#include "DscException.h"

class AbortProcessException : public DscException
{
   public:

      AbortProcessException(const char* p_filename,
                            int p_line_number);
      virtual ~AbortProcessException() = default;
};

#endif
