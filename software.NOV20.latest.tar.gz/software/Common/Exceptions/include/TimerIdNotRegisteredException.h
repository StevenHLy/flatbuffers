#ifndef TimerIdNotRegisteredException_h
#define TimerIdNotRegisteredException_h

#include "DscException.h"

class TimerIdNotRegisteredException : public DscException
{
   public:

      TimerIdNotRegisteredException(const char* p_filename,
                                    int p_line_number,
                                    unsigned int p_id);
      virtual ~TimerIdNotRegisteredException() = default;
};

#endif
