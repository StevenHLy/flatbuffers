#ifndef PeerDisconnectException_h
#define PeerDisconnectException_h

#include "DscException.h"

class PeerDisconnectException : public DscException
{
   public:

      PeerDisconnectException(const char* p_filename,
                              int p_line_number);
      virtual ~PeerDisconnectException() = default;
};

#endif
