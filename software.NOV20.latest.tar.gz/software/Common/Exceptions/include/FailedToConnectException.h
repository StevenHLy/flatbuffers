#ifndef FailedToConnectException_h
#define FailedToConnectException_h

#include "DscException.h"

class FailedToConnectException : public DscException
{
   public:

      FailedToConnectException(const char* p_filename,
                               int p_line_number,
                               int p_errno);
      virtual ~FailedToConnectException() = default;
};

#endif
