#ifndef SelectTimeoutException_h
#define SelectTimeoutException_h

#include "DscException.h"

class SelectTimeoutException : public DscException
{
   public:

      SelectTimeoutException(const char* p_filename,
                             int p_line_number);
      virtual ~SelectTimeoutException() = default;
};

#endif
