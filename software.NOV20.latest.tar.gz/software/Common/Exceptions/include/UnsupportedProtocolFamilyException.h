#ifndef UnsupportedProtocolFamilyException_h
#define UnsupportedProtocolFamilyException_h

#include "DscException.h"

class UnsupportedProtocolFamilyException : public DscException
{
   public:

      UnsupportedProtocolFamilyException(const char* p_filename,
                                         int p_line_number);
      virtual ~UnsupportedProtocolFamilyException() = default;
};

#endif
