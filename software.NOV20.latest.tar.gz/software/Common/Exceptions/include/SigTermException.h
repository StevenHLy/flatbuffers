#ifndef SigTermException_h
#define SigTermException_h

#include "DscException.h"

class SigTermException : public DscException
{
   public:

      SigTermException(const char* p_filename,
                       int p_line_number);
      virtual ~SigTermException() = default;
};

#endif
