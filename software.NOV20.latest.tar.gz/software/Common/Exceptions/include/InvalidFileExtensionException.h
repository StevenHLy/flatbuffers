#ifndef InvalidFileExtensionExcepsion_h
#define InvalidFileExtensionExcepsion_h

#include "DscException.h"
#include <string>

class InvalidFileExtensionException : public DscException
{
   public:

      InvalidFileExtensionException(const char* p_filename,
                                    int p_line_number,
                                    const std::string& p_file_extension);
      virtual ~InvalidFileExtensionException() = default;
};

#endif
