#ifndef SigIntException_h
#define SigIntException_h

#include "DscException.h"

class SigIntException : public DscException
{
   public:

      SigIntException(const char* p_filename,
                      int p_line_number);
      virtual ~SigIntException() = default;
};

#endif
