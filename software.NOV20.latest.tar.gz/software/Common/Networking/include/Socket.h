#ifndef Socket_h
#define Socket_h

#include "ProtocolFamilyType.h"
#include "SocketType.h"
#include <string>

class Socket
{
   public:

      virtual ~Socket();

      virtual int recvMessage(void* p_data_buffer,
                              unsigned int p_byte_count) = 0;
      virtual int sendMessage(void* p_data_buffer,
                              unsigned int p_byte_count) = 0;

      virtual void closeSocket();
      virtual void createSocket();
      virtual int getSocketOptError();
      virtual int getSocketOptRcvBuf();
      virtual struct timeval getSocketOptRcvTimeout();
      virtual int getSocketOptReuseAddr();
      virtual int getSocketOptReusePort();
      virtual int getSocketOptSndBuf();
      virtual struct timeval getSocketOptSndTimeout();
      virtual int getSocketOptType();
      virtual std::string ipAddress();
      virtual bool isSocketConnected();
      virtual bool isSocketNonBlocking();
      virtual int port();
      virtual ProtocolFamilyType::ProtocolFamilyTypeEnum protocolFamily();
      virtual void setConnected(bool p_connected);
      virtual void setNonBlocking(bool p_enable);
      virtual void setSocketOptRcvBuf(int p_buffer_size);
      virtual void setSocketOptRcvTimeout(int p_timeout_secs);
      virtual void setSocketOptReuseAddr(bool p_enable);
      virtual void setSocketOptReusePort(bool p_enable);
      virtual void setSocketOptSndBuf(int p_buffer_size);
      virtual void setSocketOptSndTimeout(int p_timeout_secs);
      virtual int socketFd();
      virtual SocketType::SocketTypeEnum socketType();

   protected:

      Socket(std::string p_ip_address,
             int p_port,
             SocketType::SocketTypeEnum p_socket_type,
             ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family = ProtocolFamilyType::ProtocolFamilyTypeEnum::IPV4);

      bool m_connected;
      int m_port;
      int m_socket_fd;
      std::string m_ip_address;
      ProtocolFamilyType::ProtocolFamilyTypeEnum m_protocol_family;
      SocketType::SocketTypeEnum m_socket_type;
};

#endif
