#ifndef ProtocolFamilyType_h
#define ProtocolFamilyType_h

#include <string>
#include <arpa/inet.h>

namespace ProtocolFamilyType
{
   enum class ProtocolFamilyTypeEnum : unsigned int
   {
      IPV4 = AF_INET
   };

   std::string enumToString(ProtocolFamilyType::ProtocolFamilyTypeEnum p_enum);
   ProtocolFamilyType::ProtocolFamilyTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
