#ifndef TcpSocketType_h
#define TcpSocketType_h

#include <string>

namespace TcpSocketType
{
   enum class TcpSocketTypeEnum : unsigned int
   {
      UNKNOWN = 0,
      CLIENT  = 1,
      SERVER  = 2
   };

   std::string enumToString(TcpSocketType::TcpSocketTypeEnum p_enum);
   TcpSocketType::TcpSocketTypeEnum stringToEnum(const std::string& p_enum);
}

#endif
