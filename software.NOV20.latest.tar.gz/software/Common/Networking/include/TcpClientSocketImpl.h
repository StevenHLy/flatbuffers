#ifndef TcpClientSocketImpl_h
#define TcpClientSocketImpl_h

#include "ProtocolFamilyType.h"
#include "TcpSocket.h"
#include <string>

class TcpClientSocketImpl : public TcpSocket
{
   public:

      TcpClientSocketImpl(std::string p_ip_address,
                          int p_port,
                          ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family = ProtocolFamilyType::ProtocolFamilyTypeEnum::IPV4);
      virtual ~TcpClientSocketImpl();

      virtual int recvMessage(void* p_data_buffer,
                              unsigned int p_byte_count) override;
      virtual int sendMessage(void* p_data_buffer,
                              unsigned int p_byte_count) override;

      virtual void connectToServer(double p_connect_timeout_secs);
};

#endif
