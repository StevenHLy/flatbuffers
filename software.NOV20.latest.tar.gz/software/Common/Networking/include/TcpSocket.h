#ifndef TcpSocket_h
#define TcpSocket_h

#include "ProtocolFamilyType.h"
#include "TcpSocketType.h"
#include "Socket.h"
#include <string>

class TcpSocket : public Socket
{
   public:

      virtual ~TcpSocket();

      virtual int recvMessage(void* p_data_buffer,
                              unsigned int p_byte_count) = 0;
      virtual int sendMessage(void* p_data_buffer,
                              unsigned int p_byte_count) = 0;

      virtual int getSockOptDebug();
      virtual int getSocketOptKeepAlive();
      virtual struct linger getSocketOptLinger();
      virtual void setSocketOptDebug(bool p_enable);
      virtual void setSocketOptKeepAlive(bool p_enable);
      virtual void setSocketOptLinger(bool p_enable,
                                      unsigned int p_linger_time_secs = 0);
      virtual TcpSocketType::TcpSocketTypeEnum tcpSocketType();

   protected:

      TcpSocket(std::string p_ip_address,
                int p_port,
                TcpSocketType::TcpSocketTypeEnum p_tcp_socket_type,
                ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family = ProtocolFamilyType::ProtocolFamilyTypeEnum::IPV4);

      TcpSocketType::TcpSocketTypeEnum m_tcp_socket_type;
};

#endif
