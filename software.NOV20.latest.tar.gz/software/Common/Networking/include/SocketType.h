#ifndef SocketType_h
#define SocketType_h

#include <string>
#include <arpa/inet.h>

namespace SocketType
{
   enum class SocketTypeEnum : unsigned int
   {
      UNKNOWN = 0,
      TCP     = SOCK_STREAM,
      UDP     = SOCK_DGRAM
   };

   std::string enumToString(SocketType::SocketTypeEnum p_enum);
   SocketType::SocketTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
