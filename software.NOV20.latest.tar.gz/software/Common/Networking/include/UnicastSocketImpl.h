#ifndef UnicastSocketImpl_h
#define UnicastSocketImpl_h

#include "ProtocolFamilyType.h"
#include "UdpSocket.h"
#include <string>

class UnicastSocketImpl : public UdpSocket
{
   public:

      UnicastSocketImpl(std::string p_ip_address,
                        int p_port,
                        ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family = ProtocolFamilyType::ProtocolFamilyTypeEnum::IPV4);
      virtual ~UnicastSocketImpl();

      int recvMessage(void* p_data_buffer,
                      unsigned int p_byte_count) override;

      int sendMessage(void* p_data_buffer,
                      unsigned int p_byte_count) override;
};

#endif
