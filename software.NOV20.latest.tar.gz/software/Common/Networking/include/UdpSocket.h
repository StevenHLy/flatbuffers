#ifndef UdpSocket_h
#define UdpSocket_h

#include "ProtocolFamilyType.h"
#include "Socket.h"
#include "UdpSocketType.h"
#include <string>

class UdpSocket : public Socket
{
   public:

      virtual ~UdpSocket();

      virtual int recvMessage(void* p_data_buffer,
                              unsigned int p_byte_count) = 0;
      virtual int sendMessage(void* p_data_buffer,
                              unsigned int p_byte_count) = 0;

      virtual void bindLocalPort();
      virtual void createSocket();
      virtual int getSocketOptBroadcast();
      virtual void setSocketOptBroadcast(bool p_enable);
      virtual UdpSocketType::UdpSocketTypeEnum udpSocketType();

   protected:

      UdpSocket(std::string p_ip_address,
                int p_port,
                UdpSocketType::UdpSocketTypeEnum p_udp_socket_type,
                ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family = ProtocolFamilyType::ProtocolFamilyTypeEnum::IPV4);

      UdpSocketType::UdpSocketTypeEnum m_udp_socket_type;
};

#endif
