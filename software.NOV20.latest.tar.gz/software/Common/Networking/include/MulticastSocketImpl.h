#ifndef MulticastSocketImpl_h
#define MulticastSocketImpl_h

#include "ProtocolFamilyType.h"
#include "UdpSocket.h"
#include <string>

class MulticastSocketImpl : public UdpSocket
{
   public:

      MulticastSocketImpl(std::string p_ip_address,
                          int p_port,
                          ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family = ProtocolFamilyType::ProtocolFamilyTypeEnum::IPV4);
      virtual ~MulticastSocketImpl();

      virtual int recvMessage(void* p_data_buffer,
                              unsigned int p_byte_count) override;
      virtual int sendMessage(void* p_data_buffer,
                              unsigned int p_byte_count) override;

      virtual int getSocketOptMulticastLoop();
      virtual struct in_addr getSocketOptMulticastIf();
      virtual int getSocketOptMulticastTtl();
      virtual std::string ipAddressFromInterfaceName(std::string p_interface_name);
      virtual void setSocketOptAddMembership();
      virtual void setSocketOptDropMembership();
      virtual void setSocketOptMulticastIf(std::string p_local_interface);
      virtual void setSocketOptMulticastLoop(bool p_enable);
      virtual void setSocketOptMulticastTtl(int p_time_to_live);

   protected:

      std::string m_local_interface;
      std::string m_local_interface_ip_address;
};

#endif
