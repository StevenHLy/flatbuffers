#ifndef UdpSocketType_h
#define UdpSocketType_h

#include <string>

namespace UdpSocketType
{
   enum class UdpSocketTypeEnum : unsigned int
   {
      UNKNOWN   = 0,
      UNICAST   = 1,
      MULTICAST = 2
   };

   std::string enumToString(UdpSocketType::UdpSocketTypeEnum p_enum);
   UdpSocketType::UdpSocketTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
