#include "TcpClientSocketImpl.h"
#include "DscConstants.h"
#include "FailedToConnectException.h"
#include "PeerDisconnectException.h"
#include "SelectTimeoutException.h"
#include "SystemCallException.h"
#include "TcpSocketType.h"
#include <errno.h>
#include <math.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>

TcpClientSocketImpl::TcpClientSocketImpl(std::string p_ip_address,
                                         int p_port,
                                         ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family)
: TcpSocket(p_ip_address, p_port, TcpSocketType::TcpSocketTypeEnum::CLIENT, p_protocol_family)
{
}

TcpClientSocketImpl::~TcpClientSocketImpl()
{
   closeSocket();
}

void TcpClientSocketImpl::connectToServer(double p_connect_timeout_secs)
{
   struct sockaddr_in connect_addr = {0};
   connect_addr.sin_family = (sa_family_t)protocolFamily();
   connect_addr.sin_port = htons(port());

   if (inet_aton(ipAddress().c_str(), &connect_addr.sin_addr) != 0)
   {
      if (connect(socketFd(), (struct sockaddr *)&connect_addr, sizeof(connect_addr)) == -1)
      {
         if (errno == EINPROGRESS)
         {
            int select_return_code = 0;
            fd_set wfdset;
            struct timeval tv = {0};

            FD_ZERO(&wfdset);
            FD_SET(socketFd(), &wfdset);

            unsigned int secs = static_cast<unsigned int>(trunc(p_connect_timeout_secs));
            unsigned int usecs = static_cast<unsigned int>(trunc((p_connect_timeout_secs - secs) * Constants::TO_USECS_FROM_SECS));

            tv.tv_sec = secs;
            tv.tv_usec = usecs;

            select_return_code = select(socketFd() + 1, NULL, &wfdset, NULL, &tv);

            if (select_return_code == -1)
            {
               throw SystemCallException(__FILE__,
                                         __LINE__,
                                         "select()",
                                         errno);
            }
            else if (select_return_code == 0)
            {
               throw SelectTimeoutException(__FILE__,
                                            __LINE__);
            }
            else
            {
               int so_error = getSocketOptError();

               if (so_error == 0)
               {
                  setConnected(true);
               }
               else
               {
                  throw FailedToConnectException(__FILE__,
                                                 __LINE__,
                                                 so_error);
               }
            }
         }
         else
         {
            throw SystemCallException(__FILE__,
                                      __LINE__,
                                      "connect()",
                                      errno);
         }
      }
      else
      {
         setConnected(true);
      }
   }
   else
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "inet_aton()",
                                errno);
   }
}

int TcpClientSocketImpl::recvMessage(void* p_data_buffer,
                                     unsigned int p_byte_count)
{
   int current_bytes_read = 0;
   int total_bytes_read = 0;

   if ((current_bytes_read = recv(socketFd(), p_data_buffer, p_byte_count, MSG_PEEK | MSG_DONTWAIT)) > 0)
   {
      int bytes_remaining = p_byte_count;

      while (bytes_remaining > 0)
      {
         errno = 0;

         current_bytes_read = recv(socketFd(),
                                   static_cast<unsigned char*>(p_data_buffer) + total_bytes_read,
                                   bytes_remaining,
                                   0);

         if (current_bytes_read > 0)
         {
            bytes_remaining -= current_bytes_read;
            total_bytes_read += current_bytes_read;
         }
         else
         {
            if (current_bytes_read == 0)
            {
               throw PeerDisconnectException(__FILE__,
                                             __LINE__);
            }
            else if (errno != EAGAIN && errno != EWOULDBLOCK)
            {
               throw SystemCallException(__FILE__,
                                         __LINE__,
                                         "recv()",
                                         errno);
            }
         }
      }
   }
   else
   {
      if (current_bytes_read == 0)
      {
         throw PeerDisconnectException(__FILE__, __LINE__);
      }
      else if (current_bytes_read < 0 && errno != EAGAIN && errno != EWOULDBLOCK)
      {
         throw SystemCallException(__FILE__,
                                   __LINE__,
                                   "recv()",
                                   errno);
      }
   }

   return total_bytes_read;
}

int TcpClientSocketImpl::sendMessage(void* p_data_buffer,
                                     unsigned int p_byte_count)
{
   int bytes_sent = 0;

   if ((bytes_sent = send(socketFd(), p_data_buffer, p_byte_count, 0)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "send()",
                                errno);
   }

   return bytes_sent;
}
