#include "UnicastSocketImpl.h"
#include "SystemCallException.h"
#include "UdpSocketType.h"
#include <sys/socket.h>
#include <sys/types.h>

UnicastSocketImpl::UnicastSocketImpl(std::string p_ip_address,
                                     int p_port,
                                     ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family)
: UdpSocket(p_ip_address, p_port, UdpSocketType::UdpSocketTypeEnum::UNICAST, p_protocol_family)
{
}

UnicastSocketImpl::~UnicastSocketImpl()
{
   closeSocket();
}

int UnicastSocketImpl::recvMessage(void* p_data_buffer,
                                   unsigned int p_byte_count)
{
   int bytes_read = 0;

   struct sockaddr_in source_addr = {0};
   socklen_t source_addr_len = sizeof(source_addr);

   if ((bytes_read = recvfrom(socketFd(), p_data_buffer, p_byte_count, 0, (struct sockaddr*)&source_addr, &source_addr_len)) == -1)
   {
      if (errno != EAGAIN && errno != EWOULDBLOCK)
      {
         throw SystemCallException(__FILE__,
                                   __LINE__,
                                   "recvfrom()",
                                   errno);
      }
   }

   return bytes_read;
}

int UnicastSocketImpl::sendMessage(void* p_data_buffer,
                                   unsigned int p_byte_count)
{
   int bytes_sent = 0;

   struct sockaddr_in destination_addr = {0};
   destination_addr.sin_family = (sa_family_t)protocolFamily();
   destination_addr.sin_addr.s_addr = inet_addr(m_ip_address.c_str());
   destination_addr.sin_port = htons(m_port);

   if ((bytes_sent = sendto(socketFd(), p_data_buffer, p_byte_count, 0, (struct sockaddr*)&destination_addr, sizeof(destination_addr))) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "sendto()",
                                errno);
   }

   return bytes_sent;
}
