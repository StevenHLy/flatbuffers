#include "ProtocolFamilyType.h"
#include <map>
#include <stdexcept>

namespace ProtocolFamilyType
{
   std::string enumToString(ProtocolFamilyType::ProtocolFamilyTypeEnum p_enum)
   {
      static std::map<ProtocolFamilyTypeEnum, std::string> enum_to_string_map =
      {
         {ProtocolFamilyTypeEnum::IPV4, "IPV4"}
      };

      try
      {
         return enum_to_string_map.at(p_enum);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("ProtocolFamilyType::enumToString() - invalid enum (" + std::to_string(static_cast<unsigned int>(p_enum)) + ")");
      }
   }

   ProtocolFamilyType::ProtocolFamilyTypeEnum stringToEnum(const std::string& p_enum_string)
   {
      static std::map<std::string, ProtocolFamilyTypeEnum> string_to_enum_map =
      {
         {"IPV4", ProtocolFamilyTypeEnum::IPV4}
      };

      try
      {
         return string_to_enum_map.at(p_enum_string);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("ProtocolFamilyType::stringToEnum() - invalid enum string (" + p_enum_string + ")");
      }
   }
}
