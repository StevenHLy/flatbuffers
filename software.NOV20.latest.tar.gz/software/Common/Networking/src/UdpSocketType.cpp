#include "UdpSocketType.h"
#include <map>
#include <stdexcept>

namespace UdpSocketType
{
   std::string enumToString(UdpSocketType::UdpSocketTypeEnum p_enum)
   {
      static std::map<UdpSocketTypeEnum, std::string> enum_to_string_map =
      {
         {UdpSocketTypeEnum::UNKNOWN, "UNKNOWN"},
         {UdpSocketTypeEnum::UNICAST, "UNICAST"},
         {UdpSocketTypeEnum::MULTICAST, "MULTICAST"}
      };

      try
      {
         return enum_to_string_map.at(p_enum);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("UdpSocketType::enumToString() - invalid enum (" + std::to_string(static_cast<unsigned int>(p_enum)) + ")");
      }
   }

   UdpSocketType::UdpSocketTypeEnum stringToEnum(const std::string& p_enum_string)
   {
      static std::map<std::string, UdpSocketTypeEnum> string_to_enum_map =
      {
         {"UNKNOWN", UdpSocketTypeEnum::UNKNOWN},
         {"UNICAST", UdpSocketTypeEnum::UNICAST},
         {"MULTICAST", UdpSocketTypeEnum::MULTICAST}
      };

      try
      {
         return string_to_enum_map.at(p_enum_string);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("UdpSocketType::stringToEnum() - invalid enum string (" + p_enum_string + ")");
      }
   }
}
