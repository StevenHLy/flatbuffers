#include "TcpSocket.h"
#include "SocketType.h"
#include "SystemCallException.h"
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>

TcpSocket::TcpSocket(std::string p_ip_address,
                     int p_port,
                     TcpSocketType::TcpSocketTypeEnum p_tcp_socket_type,
                     ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family)
: Socket(p_ip_address, p_port, SocketType::SocketTypeEnum::TCP, p_protocol_family)
, m_tcp_socket_type(p_tcp_socket_type)
{
}

TcpSocket::~TcpSocket()
{
   closeSocket();
}

int TcpSocket::getSockOptDebug()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_DEBUG, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_DEBUG)",
                                errno);
   }

   return optval;
}

int TcpSocket::getSocketOptKeepAlive()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_KEEPALIVE, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_KEEPALIVE)",
                                errno);
   }

   return optval;
}

struct linger TcpSocket::getSocketOptLinger()
{
   struct linger optval = {0};
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_LINGER, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_LINGER)",
                                errno);
   }

   return optval;
}

void TcpSocket::setSocketOptDebug(bool p_enable)
{
   int optval = (p_enable) ? 1 : 0;

   if (setsockopt(socketFd(), SOL_SOCKET, SO_DEBUG, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_DEBUG)",
                                errno);
   }
}

void TcpSocket::setSocketOptKeepAlive(bool p_enable)
{
   int optval = (p_enable) ? 1 : 0;

   if ((setsockopt(socketFd(), SOL_SOCKET, SO_KEEPALIVE, &optval, sizeof(optval)) == -1))
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_KEEPALIVE)",
                                errno);
   }
}

void TcpSocket::setSocketOptLinger(bool p_enable,
                                   unsigned int p_linger_time_secs)
{
   struct linger optval = {0};
   optval.l_onoff = (p_enable) ? 1 : 0;
   optval.l_linger = p_linger_time_secs;

   if (setsockopt(socketFd(), SOL_SOCKET, SO_LINGER, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_LINGER)",
                                errno);
   }
}

TcpSocketType::TcpSocketTypeEnum TcpSocket::tcpSocketType()
{
   return m_tcp_socket_type;
}
