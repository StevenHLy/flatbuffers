#include "Socket.h"
#include "SystemCallException.h"
#include "UnsupportedProtocolFamilyException.h"
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>

Socket::Socket(std::string p_ip_address,
               int p_port,
               SocketType::SocketTypeEnum p_socket_type,
               ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family)
: m_connected(false)
, m_port(p_port)
, m_socket_fd(-1)
, m_ip_address(p_ip_address)
, m_protocol_family(p_protocol_family)
, m_socket_type(p_socket_type)
{
}

Socket::~Socket()
{
   closeSocket();
}

void Socket::closeSocket()
{
   if (isSocketConnected())
   {
      close(socketFd());
   }

   m_connected = false;
   m_socket_fd = -1;
}

void Socket::createSocket()
{
   if (protocolFamily() == ProtocolFamilyType::ProtocolFamilyTypeEnum::IPV4)
   {
      if ((m_socket_fd = socket(static_cast<int>(protocolFamily()), static_cast<int>(socketType()), 0)) == -1)
      {
         throw SystemCallException(__FILE__,
                                   __LINE__,
                                   "socket()",
                                   errno);
      }
   }
   else
   {
      throw UnsupportedProtocolFamilyException(__FILE__,
                                               __LINE__);
   }
}

int Socket::getSocketOptError()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_ERROR, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_ERROR)",
                                errno);
   }

   return optval;
}

int Socket::getSocketOptRcvBuf()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_RCVBUF, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_RCVBUF)",
                                errno);
   }

   return optval;
}

struct timeval Socket::getSocketOptRcvTimeout()
{
   struct timeval optval = {0};
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_RCVTIMEO, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_RCVTIMEO)",
                                errno);
   }

   return optval;
}

int Socket::getSocketOptReuseAddr()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_REUSEADDR, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_REUSEADDR)",
                                errno);
   }

   return optval;
}

int Socket::getSocketOptReusePort()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_REUSEPORT, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_REUSEPORT)",
                                errno);
   }

   return optval;
}

int Socket::getSocketOptSndBuf()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_SNDBUF, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_SNDBUF)",
                                errno);
   }

   return optval;
}

struct timeval Socket::getSocketOptSndTimeout()
{
   struct timeval optval = {0};
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_SNDTIMEO, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_SNDTIMEO)",
                                errno);
   }

   return optval;
}

int Socket::getSocketOptType()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_TYPE, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_TYPE)",
                                errno);
   }

   return optval;
}

std::string Socket::ipAddress()
{
   return m_ip_address;
}

bool Socket::isSocketConnected()
{
   return m_connected;
}

bool Socket::isSocketNonBlocking()
{
   int socket_flags = 0;

   if ((socket_flags = fcntl(socketFd(), F_GETFL)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "fcntl(F_GETFL)",
                                errno);
   }

   return (socket_flags & O_NONBLOCK);
}

int Socket::port()
{
   return m_port;
}

ProtocolFamilyType::ProtocolFamilyTypeEnum Socket::protocolFamily()
{
   return m_protocol_family;
}

void Socket::setConnected(bool p_connected)
{
   m_connected = p_connected;
}

void Socket::setNonBlocking(bool p_enable)
{
   int socket_flags = 0;

   if ((socket_flags = fcntl(socketFd(), F_GETFL)) != -1)
   {
      if (p_enable)
      {
         socket_flags |= O_NONBLOCK;
      }
      else
      {
         socket_flags &= ~O_NONBLOCK;
      }

      if (fcntl(socketFd(), F_SETFL, socket_flags) == -1)
      {
         throw SystemCallException(__FILE__,
                                   __LINE__,
                                   "fcntl(F_SETFL)",
                                   errno);
      }
   }
   else
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "fcntl(F_GETFL)",
                                errno);
   }
}

void Socket::setSocketOptRcvBuf(int p_buffer_size)
{
   if (setsockopt(socketFd(), SOL_SOCKET, SO_RCVBUF, &p_buffer_size, sizeof(p_buffer_size)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_RCVBUF)",
                                errno);
   }
}

void Socket::setSocketOptRcvTimeout(int p_timeout_secs)
{
   struct timeval optval = {0};
   optval.tv_sec = p_timeout_secs;

   if (setsockopt(socketFd(), SOL_SOCKET, SO_RCVTIMEO, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_RCVTIMEO)",
                                errno);
   }
}

void Socket::setSocketOptReuseAddr (bool p_enable)
{
   int optval = (p_enable) ? 1 : 0;

   if (setsockopt(socketFd(), SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_REUSEADDR)",
                                errno);
   }
}

void Socket::setSocketOptReusePort(bool p_enable)
{
   int optval = (p_enable) ? 1 : 0;

   if (setsockopt(socketFd(), SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_REUSEPORT)",
                                errno);
   }
}

void Socket::setSocketOptSndBuf(int p_buffer_size)
{
   if (setsockopt(socketFd(), SOL_SOCKET, SO_SNDBUF, &p_buffer_size, sizeof(p_buffer_size)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_SNDBUF)",
                                errno);
   }
}

void Socket::setSocketOptSndTimeout(int p_timeout_secs)
{
   struct timeval optval = {0};
   optval.tv_sec = p_timeout_secs;

   if (setsockopt(socketFd(), SOL_SOCKET, SO_SNDTIMEO, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_SNDTIMEO)",
                                errno);
   }
}

int Socket::socketFd()
{
   return m_socket_fd;
}

SocketType::SocketTypeEnum Socket::socketType()
{
   return m_socket_type;
}
