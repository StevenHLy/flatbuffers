#include "MulticastSocketImpl.h"
#include "ProtocolFamilyType.h"
#include "SocketType.h"
#include "SystemCallException.h"
#include "UdpSocketType.h"
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>

MulticastSocketImpl::MulticastSocketImpl(std::string p_ip_address,
                                         int p_port,
                                         ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family)
: UdpSocket(p_ip_address, p_port, UdpSocketType::UdpSocketTypeEnum::MULTICAST, p_protocol_family)
, m_local_interface("")
, m_local_interface_ip_address("")
{
}

MulticastSocketImpl::~MulticastSocketImpl()
{
   closeSocket();
}

struct in_addr MulticastSocketImpl::getSocketOptMulticastIf()
{
   struct in_addr optval = {0};
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), IPPROTO_IP, IP_MULTICAST_IF, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(IP_MULTICAST_IF)",
                                errno);
   }

   return optval;
}

int MulticastSocketImpl::getSocketOptMulticastLoop()
{
   unsigned char optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), IPPROTO_IP, IP_MULTICAST_LOOP, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(IP_MULTICAST_LOOP)",
                                errno);
   }

   return optval;
}

int MulticastSocketImpl::getSocketOptMulticastTtl()
{
   unsigned char optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), IPPROTO_IP, IP_MULTICAST_TTL, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(IP_MULTICAST_TTL)",
                                errno);
   }

   return optval;
}

std::string MulticastSocketImpl::ipAddressFromInterfaceName(std::string p_interface_name)
{
   char* address = nullptr;

   struct ifreq ifr = {0};
   ifr.ifr_addr.sa_family = (sa_family_t)protocolFamily();
   strncpy(ifr.ifr_name, p_interface_name.c_str(), IFNAMSIZ - 1);

   if (ioctl(socketFd(), SIOCGIFADDR, &ifr) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "ioctl(SIOCGIFADDR)",
                                errno);
   }
   else
   {
      address = inet_ntoa(((struct sockaddr_in*)&ifr.ifr_addr)->sin_addr);
   }

   return (std::string(address));
}

int MulticastSocketImpl::recvMessage(void* p_data_buffer,
                                     unsigned int p_byte_count)
{
   int bytes_read = 0;

   struct sockaddr_in source_addr = {0};
   socklen_t source_addr_len = sizeof(source_addr);

   if ((bytes_read = recvfrom(socketFd(), p_data_buffer, p_byte_count, 0, (struct sockaddr*)&source_addr, &source_addr_len)) == -1)
   {
      if (errno != EAGAIN && errno != EWOULDBLOCK)
      {
         throw SystemCallException(__FILE__,
                                   __LINE__,
                                   "recvfrom()",
                                   errno);
      }
   }

   return bytes_read;
}

int MulticastSocketImpl::sendMessage(void* p_data_buffer,
                                     unsigned int p_byte_count)
{
   int bytes_sent = 0;

   struct sockaddr_in destination_addr = {0};
   destination_addr.sin_family = (sa_family_t)protocolFamily();
   destination_addr.sin_addr.s_addr = inet_addr(m_ip_address.c_str());
   destination_addr.sin_port = htons(m_port);

   if ((bytes_sent = sendto(socketFd(), p_data_buffer, p_byte_count, 0, (struct sockaddr*)&destination_addr, sizeof(destination_addr))) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "sendto()",
                                errno);
   }

   return bytes_sent;
}

void MulticastSocketImpl::setSocketOptAddMembership()
{
   struct ip_mreq optval = {0};
   optval.imr_multiaddr.s_addr = inet_addr(ipAddress().c_str());
   optval.imr_interface.s_addr = (m_local_interface.empty()) ? htonl(INADDR_ANY) :
                                                               inet_addr(m_local_interface_ip_address.c_str());

   if (setsockopt(socketFd(), IPPROTO_IP, IP_ADD_MEMBERSHIP, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(IP_ADD_MEMBERSHIP)",
                                errno);
   }
}

void MulticastSocketImpl::setSocketOptDropMembership()
{
   struct ip_mreq optval = {0};
   optval.imr_multiaddr.s_addr = inet_addr(ipAddress().c_str());
   optval.imr_interface.s_addr = (m_local_interface.empty()) ? htonl(INADDR_ANY) :
                                                               inet_addr(m_local_interface_ip_address.c_str());

   if (setsockopt(socketFd(), IPPROTO_IP, IP_DROP_MEMBERSHIP, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(IP_DROP_MEMBERSHIP)",
                                errno);
   }
}

void MulticastSocketImpl::setSocketOptMulticastIf(std::string p_local_interface)
{
   m_local_interface = p_local_interface;
   m_local_interface_ip_address = ipAddressFromInterfaceName(p_local_interface);

   struct in_addr addr{0};
   addr.s_addr = (m_local_interface.empty()) ? htonl(INADDR_ANY) :
                                               inet_addr(m_local_interface_ip_address.c_str());

   if (setsockopt(socketFd(), IPPROTO_IP, IP_MULTICAST_IF, &addr, sizeof(addr)) == -1)
   {
      m_local_interface = "";
      m_local_interface_ip_address = ipAddressFromInterfaceName(m_local_interface);

      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(IP_MULTICAST_IF)",
                                errno);
   }
}

void MulticastSocketImpl::setSocketOptMulticastLoop(bool p_enable)
{
   int optval = (p_enable) ? 1 : 0;

   if (setsockopt(socketFd(), IPPROTO_IP, IP_MULTICAST_LOOP, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(IP_MULTICAST_LOOP)",
                                errno);
   }
}

void MulticastSocketImpl::setSocketOptMulticastTtl(int p_time_to_live)
{
   unsigned char optval = p_time_to_live;

   if (setsockopt(socketFd(), IPPROTO_IP, IP_MULTICAST_TTL, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(IP_MULTICAST_TTL)",
                                errno);
   }
}
