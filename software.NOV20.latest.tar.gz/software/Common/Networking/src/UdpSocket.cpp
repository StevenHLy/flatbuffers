#include "UdpSocket.h"
#include "SystemCallException.h"
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>

UdpSocket::UdpSocket(std::string p_ip_address,
                     int p_port,
                     UdpSocketType::UdpSocketTypeEnum p_udp_socket_type,
                     ProtocolFamilyType::ProtocolFamilyTypeEnum p_protocol_family)
: Socket(p_ip_address, p_port, SocketType::SocketTypeEnum::UDP, p_protocol_family)
, m_udp_socket_type(p_udp_socket_type)
{
}

UdpSocket::~UdpSocket()
{
   closeSocket();
}

void UdpSocket::bindLocalPort()
{
   struct sockaddr_in receive_addr = {0};
   receive_addr.sin_family = (sa_family_t)protocolFamily();
   receive_addr.sin_addr.s_addr = htonl(INADDR_ANY);
   receive_addr.sin_port = htons(port());

   if (bind(m_socket_fd, (struct sockaddr*)&receive_addr, sizeof(receive_addr)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "bind()",
                                errno);
   }
}

void UdpSocket::createSocket()
{
   Socket::createSocket();
   setConnected(true);
}

int UdpSocket::getSocketOptBroadcast()
{
   int optval = 0;
   socklen_t optval_len = sizeof(optval);

   if (getsockopt(socketFd(), SOL_SOCKET, SO_BROADCAST, &optval, &optval_len) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "getsockopt(SO_BROADCAST)",
                                errno);
   }

   return optval;
}

void UdpSocket::setSocketOptBroadcast(bool p_enable)
{
   int optval = (p_enable) ? 1 : 0;

   if (setsockopt(socketFd(), SOL_SOCKET, SO_BROADCAST, &optval, sizeof(optval)) == -1)
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "setsockopt(SO_BROADCAST)",
                                errno);
   }
}

UdpSocketType::UdpSocketTypeEnum UdpSocket::udpSocketType()
{
   return m_udp_socket_type;
}
