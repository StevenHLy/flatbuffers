#ifndef PlatformServicesComponent_h
#define PlatformServicesComponent_h

#include "CommsService.h"
#include "DataService.h"
#include "DscApplicationComponent.h"
#include "JoinService.h"
#include "ScheduleService.h"
#include "StatusService.h"

class PlatformServicesComponent : public DscApplicationComponent
{
   public:

      static constexpr const char* COMPONENT_NAME = "PlatformServices";

      PlatformServicesComponent(unsigned int p_component_id);
      ~PlatformServicesComponent() = default;

      void initializeComponent() override;

      CommsService* commsService();
      DataService* dataService();
      JoinService* joinService();
      ScheduleService* scheduleService();
      StatusService* statusService();

   protected:

      CommsService m_comms_service;
      DataService m_data_service;
      JoinService m_join_service;
      ScheduleService m_schedule_service;
      StatusService m_status_service;
};

#endif
