#ifndef CommsService_h
#define CommsService_h

class PlatformServicesComponent;

class CommsService
{
   public:

      CommsService(PlatformServicesComponent* p_component_handle);
      ~CommsService() = default;

   protected:

      PlatformServicesComponent* m_component_handle;
};

#endif
