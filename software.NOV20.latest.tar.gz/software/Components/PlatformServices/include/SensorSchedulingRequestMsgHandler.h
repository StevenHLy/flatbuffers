#ifndef SensorSchedulingRequestMsgHandler_h
#define SensorSchedulingRequestMsgHandler_h

#include "InternalMsg.h"
#include "InternalMsgHandler.h"

class PlatformServicesComponent;

class SensorSchedulingRequestMsgHandler : public InternalMsgHandler
{
   public:

      SensorSchedulingRequestMsgHandler(PlatformServicesComponent* p_component_handle);
      ~SensorSchedulingRequestMsgHandler() = default;

      void processInternalMsg(const InternalMsg* p_msg) override;

   protected:

      PlatformServicesComponent* m_component_handle;
};

#endif
