#ifndef StatusService_h
#define StatusService_h

class PlatformServicesComponent;

class StatusService
{
   public:

      StatusService(PlatformServicesComponent* p_component_handle);
      ~StatusService() = default;

   protected:

      PlatformServicesComponent* m_component_handle;
};

#endif
