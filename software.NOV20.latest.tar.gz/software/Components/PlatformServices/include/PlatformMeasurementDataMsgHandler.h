#ifndef PlatformMeasurementDataMsgHandler_h
#define PlatformMeasurementDataMsgHandler_h

#include "InternalMsg.h"
#include "InternalMsgHandler.h"

class PlatformServicesComponent;

class PlatformMeasurementDataMsgHandler : public InternalMsgHandler
{
   public:

      PlatformMeasurementDataMsgHandler(PlatformServicesComponent* p_component_handle);
      ~PlatformMeasurementDataMsgHandler() = default;

      void processInternalMsg(const InternalMsg* p_msg) override;

   protected:

      PlatformServicesComponent* m_component_handle;
};

#endif
