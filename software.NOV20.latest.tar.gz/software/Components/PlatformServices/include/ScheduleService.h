#ifndef ScheduleService_h
#define ScheduleService_h

#include "InternalMsg.h"
#include "SensorSchedulingRequestMsg.h"

class PlatformServicesComponent;

class ScheduleService
{
   public:

      ScheduleService(PlatformServicesComponent* p_component_handle);
      ~ScheduleService() = default;

      void processRadarActionReturn(const InternalMsg* p_msg);
      void processSensorSchedulingRequest(const SensorSchedulingRequestMsg& p_msg);

   protected:

      PlatformServicesComponent* m_component_handle;
};

#endif

