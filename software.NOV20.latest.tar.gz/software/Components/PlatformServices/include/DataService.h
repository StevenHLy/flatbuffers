#ifndef DataService_h
#define DataService_h

#include "InternalMsg.h"

class PlatformServicesComponent;

class DataService
{
   public:

      DataService(PlatformServicesComponent* p_component_handle);
      ~DataService() = default;

      void processPlatformMeasurementData(const InternalMsg* p_msg);

   protected:

      PlatformServicesComponent* m_component_handle;
};

#endif
