#ifndef JoinService_h
#define JoinService_h

class PlatformServicesComponent;

class JoinService
{
   public:

      JoinService(PlatformServicesComponent* p_component_handle);
      ~JoinService() = default;

   protected:

      PlatformServicesComponent* m_component_handle;
};

#endif
