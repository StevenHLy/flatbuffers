#include "StatusService.h"
#include "PlatformServicesComponent.h"

StatusService::StatusService(PlatformServicesComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
