#include "PlatformMeasurementDataMsgHandler.h"
#include "LogService.h"
#include "PlatformServicesComponent.h"
#include "Service.h"

PlatformMeasurementDataMsgHandler::PlatformMeasurementDataMsgHandler(PlatformServicesComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void PlatformMeasurementDataMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "PlatformMeasurementDataMsgHandler::processInternalMsg() called");

   m_component_handle->dataService()->processPlatformMeasurementData(p_msg);
}

