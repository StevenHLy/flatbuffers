#include "DataService.h"
#include "DiscoGuiBoundaryMeasurementReportMsg.h"
#include "PlatformServicesComponent.h"
#include "LogService.h"
#include "MsgService.h"
#include "NodeService.h"
#include "Service.h"
#include "TrackerBoundaryMeasurementReportMsg.h"

DataService::DataService(PlatformServicesComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void DataService::processPlatformMeasurementData(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "DataService::processPlatformMeasurementData() called");

   TrackerBoundaryMeasurementReportMsg tracker_boundary_measurement_report_msg;

   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                      Service<NodeService>::getInstance().componentNameToComponentId("TrackerBoundary"),
                                      &tracker_boundary_measurement_report_msg);

   DiscoGuiBoundaryMeasurementReportMsg disco_gui_boundary_measurement_report_msg;

   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                      Service<NodeService>::getInstance().componentNameToComponentId("DiscoGuiBoundary"),
                                      &disco_gui_boundary_measurement_report_msg);
}
