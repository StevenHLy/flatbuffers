#include "JoinService.h"
#include "PlatformServicesComponent.h"

JoinService::JoinService(PlatformServicesComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
