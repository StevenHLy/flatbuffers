#include "ScheduleService.h"
#include "DataProcessingCommandMsg.h"
#include "LogService.h"
#include "MsgService.h"
#include "NodeService.h"
#include "PlatformServicesComponent.h"
#include "RadarActionControlMsg.h"
#include "Service.h"
#include "SensorSchedulingRequestStatusMsg.h"
#include "SignalProcessingCommandMsg.h"

ScheduleService::ScheduleService(PlatformServicesComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void ScheduleService::processRadarActionReturn(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "ScheduleService::processRadarActionReturn() called");

   SensorSchedulingRequestStatusMsg sensor_scheduling_request_status_msg;

   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                      Service<NodeService>::getInstance().componentNameToComponentId("DistributedCoordinator"),
                                      &sensor_scheduling_request_status_msg);
}

void ScheduleService::processSensorSchedulingRequest(const SensorSchedulingRequestMsg &p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "ScheduleService::processSensorSchedulingRequest() called");

   RadarActionControlMsg radar_action_control_msg;

   radar_action_control_msg.m_body.Command_Type       = p_msg.m_body.Command_Type;
   radar_action_control_msg.m_body.Number_Of_Commands = p_msg.m_body.Number_Of_Commands;

   if (1 == radar_action_control_msg.m_body.Command_Type) // slew command
   {
      for (int idx=0; idx<radar_action_control_msg.m_body.Number_Of_Commands; idx++)
      {
         radar_action_control_msg.m_body.Slew_Commands[idx].Dish              = p_msg.m_body.Slew_Commands[idx].Dish;
         radar_action_control_msg.m_body.Slew_Commands[idx].Azimuth_Degrees   = p_msg.m_body.Slew_Commands[idx].Azimuth_Degrees;
         radar_action_control_msg.m_body.Slew_Commands[idx].Elevation_Degrees = p_msg.m_body.Slew_Commands[idx].Elevation_Degrees;
      }
   }
   else if (2 == radar_action_control_msg.m_body.Command_Type) // transmit command
   {
      for (int idx=0; idx<radar_action_control_msg.m_body.Number_Of_Commands; idx++)
      {
         radar_action_control_msg.m_body.Transmit_Commands[idx].Dish              = p_msg.m_body.Transmit_Commands[idx].Dish;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Pulsewidth_usec   = p_msg.m_body.Transmit_Commands[idx].Pulsewidth_usec;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Amplitude         = p_msg.m_body.Transmit_Commands[idx].Amplitude;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Bandwidth_MHz     = p_msg.m_body.Transmit_Commands[idx].Bandwidth_MHz;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Phase_Offsec_psec = p_msg.m_body.Transmit_Commands[idx].Phase_Offsec_psec;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Offset_MHz        = p_msg.m_body.Transmit_Commands[idx].Offset_MHz;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Samples_Per_Chip  = p_msg.m_body.Transmit_Commands[idx].Samples_Per_Chip;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Gold_Code_Index   = p_msg.m_body.Transmit_Commands[idx].Gold_Code_Index;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Num_Pulses        = p_msg.m_body.Transmit_Commands[idx].Num_Pulses;
         radar_action_control_msg.m_body.Transmit_Commands[idx].Repetition_Count  = p_msg.m_body.Transmit_Commands[idx].Repetition_Count;
      }
   }

   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                      Service<NodeService>::getInstance().componentNameToComponentId("Blding142PlatformTranslator"),
                                      &radar_action_control_msg);

   SignalProcessingCommandMsg signal_processing_command_msg;

   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                      Service<NodeService>::getInstance().componentNameToComponentId("Blding142PlatformTranslator"),
                                      &signal_processing_command_msg);

   DataProcessingCommandMsg data_processing_command_msg;

   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                      Service<NodeService>::getInstance().componentNameToComponentId("Blding142PlatformTranslator"),
                                      &data_processing_command_msg);
}
