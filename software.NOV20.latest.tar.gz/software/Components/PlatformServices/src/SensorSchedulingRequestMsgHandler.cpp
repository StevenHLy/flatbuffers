#include "SensorSchedulingRequestMsgHandler.h"
#include "LogService.h"
#include "PlatformServicesComponent.h"
#include "Service.h"

SensorSchedulingRequestMsgHandler::SensorSchedulingRequestMsgHandler(PlatformServicesComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void SensorSchedulingRequestMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "SensorSchedulingRequestMsgHandler::processInternalMsg() called");

   const SensorSchedulingRequestMsg* msg_ptr = reinterpret_cast<const SensorSchedulingRequestMsg*>(p_msg);

   m_component_handle->scheduleService()->processSensorSchedulingRequest(*msg_ptr);
}


