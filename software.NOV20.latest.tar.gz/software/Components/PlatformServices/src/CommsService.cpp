#include "CommsService.h"
#include "PlatformServicesComponent.h"

CommsService::CommsService(PlatformServicesComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
