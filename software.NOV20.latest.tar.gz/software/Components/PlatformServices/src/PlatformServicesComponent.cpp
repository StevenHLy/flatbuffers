#include "PlatformServicesComponent.h"
#include "InternalMsgIdType.h"
#include "InternalMsgIdType.h"
#include "LogService.h"
#include "PlatformMeasurementDataMsgHandler.h"
#include "RadarActionReturnMsgHandler.h"
#include "SensorSchedulingRequestMsgHandler.h"
#include "Service.h"

PlatformServicesComponent::PlatformServicesComponent(unsigned int p_component_id)
: DscApplicationComponent(PlatformServicesComponent::COMPONENT_NAME,
                          p_component_id)
, m_comms_service(this)
, m_data_service(this)
, m_join_service(this)
, m_schedule_service(this)
, m_status_service(this)
{
}

CommsService* PlatformServicesComponent::commsService()
{
   return &m_comms_service;
}

DataService* PlatformServicesComponent::dataService()
{
   return &m_data_service;
}

void PlatformServicesComponent::initializeComponent()
{
   Service<LogService>::getInstance().registerRequester(componentName(),
                                                        componentId());

   registerInternalMsgHandler<PlatformMeasurementDataMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_PLATFORM_MEASUREMENT_DATA,
                                                                 this);

   registerInternalMsgHandler<RadarActionReturnMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_RADAR_ACTION_RETURN,
                                                           this);

   registerInternalMsgHandler<SensorSchedulingRequestMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_SENSOR_SCHEDULING_REQUEST,
                                                                          this);
}

JoinService* PlatformServicesComponent::joinService()
{
   return &m_join_service;
}

ScheduleService* PlatformServicesComponent::scheduleService()
{
   return &m_schedule_service;
}

StatusService* PlatformServicesComponent::statusService()
{
   return &m_status_service;
}

