#include "RadarActionReturnMsgHandler.h"
#include "LogService.h"
#include "PlatformServicesComponent.h"
#include "Service.h"

RadarActionReturnMsgHandler::RadarActionReturnMsgHandler(PlatformServicesComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void RadarActionReturnMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "RadarActionReturnMsgHandler::processInternalMsg() called");

   m_component_handle->scheduleService()->processRadarActionReturn(p_msg);
}

