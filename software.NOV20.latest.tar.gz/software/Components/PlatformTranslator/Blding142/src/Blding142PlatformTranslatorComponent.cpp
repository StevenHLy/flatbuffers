#include "Blding142PlatformTranslatorComponent.h"
#include "Blding142MsgIdType.h"
#include "Blding142PlatformMeasurementDataMsgHandler.h"
#include "Blding142PlatformSensorCommandStatusMsgHandler.h"
#include "DataProcessingCommandMsgHandler.h"
#include "InternalMsgIdType.h"
#include "LogService.h"
#include "RadarActionControlMsgHandler.h"
#include "Service.h"
#include "SignalProcessingCommandMsgHandler.h"
#include <stdexcept>
#include <string.h>

Blding142PlatformTranslatorComponent::Blding142PlatformTranslatorComponent(unsigned int p_component_id)
: DscPlatformBoundaryComponent(Blding142PlatformTranslatorComponent::COMPONENT_NAME,
                               p_component_id)
, m_platform_interface(this)
{
}

void Blding142PlatformTranslatorComponent::initializeComponent()
{
   Service<LogService>::getInstance().registerRequester(componentName(),
                                                        componentId());

   registerInternalMsgHandler<DataProcessingCommandMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_DATA_PROCESSING_COMMAND,
                                                                          this);

   registerInternalMsgHandler<RadarActionControlMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_RADAR_ACTION_CONTROL,
                                                                          this);

   registerInternalMsgHandler<SignalProcessingCommandMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_SIGNAL_PROCESSING_COMMAND,
                                                                          this);

   registerExternalMsgHandler<Blding142PlatformMeasurementDataMsgHandler>((unsigned int)Blding142MsgIdType::Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_MEASUREMENT_DATA,
                                                                          this);

   registerExternalMsgHandler<Blding142PlatformSensorCommandStatusMsgHandler>((unsigned int)Blding142MsgIdType::Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_SENSOR_COMMAND_STATUS,
                                                                              this);

   platformInterface()->initialize();
}

Blding142PlatformInterface* Blding142PlatformTranslatorComponent::platformInterface()
{
   return &m_platform_interface;
}

void Blding142PlatformTranslatorComponent::processQueuedMsg()
{
   if (not externalMsgQueue().empty())
   {
      Blding142Msg* blding142_msg = (Blding142Msg*)(*(externalMsgQueue().begin()))->buffer();

      try
      {
         externalMsgSubscribers().at((unsigned int)blding142_msg->m_header.m_msg_id)(blding142_msg);
      }
      catch(std::out_of_range const& e)
      {
         Service<LogService>::getInstance().log(componentId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::WARNING,
                                                "No registered external msg handler for component %s (%d) and msg %s (%d)",
                                                Service<NodeService>::getInstance().componentIdToComponentName(componentId()).c_str(),
                                                componentId(),
                                                Blding142MsgIdType::enumToString(blding142_msg->m_header.m_msg_id).c_str(),
                                                blding142_msg->m_header.m_msg_id);
      }

      delete(externalMsgQueue().front());
      externalMsgQueue().pop_front();
   }
}

void Blding142PlatformTranslatorComponent::queueReceivedMsg(Blding142Msg* p_msg)
{
   GenericBuffer<unsigned char>* new_msg_buffer = new GenericBuffer<unsigned char>(p_msg->m_header.m_msg_size);

   memcpy(new_msg_buffer->buffer(),
          p_msg,
          new_msg_buffer->bufferSize());

   m_msg_queue.push_back(new_msg_buffer);
}

void Blding142PlatformTranslatorComponent::shutdownComponent()
{
   platformInterface()->shutdown();
}
