#include "DataProcessingCommandMsgHandler.h"
#include "Blding142PlatformTranslatorComponent.h"
#include "LogService.h"
#include "Service.h"

DataProcessingCommandMsgHandler::DataProcessingCommandMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void DataProcessingCommandMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "DataProcessingCommandMsgHandler::processInternalMsg() called");
}

