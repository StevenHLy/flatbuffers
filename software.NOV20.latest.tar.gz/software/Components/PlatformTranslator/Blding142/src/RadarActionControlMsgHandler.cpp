#include "RadarActionControlMsgHandler.h"
#include "Blding142PlatformTranslatorComponent.h"
#include "LogService.h"
#include "Service.h"
#include "RadarActionControlMsg.h"
#include "Blding142PlatformSensorCommandMsg.h"
#include <cstring>
#include <iostream>
RadarActionControlMsgHandler::RadarActionControlMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void RadarActionControlMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "RadarActionControlMsgHandler::processInternalMsg() called");

   const RadarActionControlMsg * rac_ptr = reinterpret_cast<const RadarActionControlMsg*>(p_msg);

   if (1 == rac_ptr->m_body.Command_Type) // slew command
   {
      for (int idx=0; idx<rac_ptr->m_body.Number_Of_Commands; idx++)
      {
         Blding142PlatformSensorCommandMsg platform_sensor_command;

         std::string dish_name = getDishAsString(rac_ptr->m_body.Slew_Commands[idx].Dish);
        
        std::cout<<"@@@dish_name::::"<<dish_name<<std::endl;

         strncpy(platform_sensor_command.m_body.Dish, dish_name.c_str(), sizeof(platform_sensor_command.m_body.Dish));

         platform_sensor_command.m_body.Command_Type                   = 1;
         platform_sensor_command.m_body.Slew_Command.Azimuth_Degrees   = rac_ptr->m_body.Slew_Commands[idx].Azimuth_Degrees;
         platform_sensor_command.m_body.Slew_Command.Elevation_Degrees = rac_ptr->m_body.Slew_Commands[idx].Elevation_Degrees;

         // Remove the following log
         Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::DEBUG,
                                                "RadarActionControlMsgHandler::processInternalMsg() \n "
                                                "Dish:%s \n Command_Type:%d \n Azimuth_Degrees:%f \n Elevation_Degrees:%f",
                                                platform_sensor_command.m_body.Dish,
                                                platform_sensor_command.m_body.Command_Type,
                                                platform_sensor_command.m_body.Slew_Command.Azimuth_Degrees,
                                                platform_sensor_command.m_body.Slew_Command.Elevation_Degrees);

         sendPlatformSensorCommandMessage(platform_sensor_command, dish_name);
         

      }
   }
   else if (2 == rac_ptr->m_body.Command_Type) // transmit command
   {
      for (int idx=0; idx<rac_ptr->m_body.Number_Of_Commands; idx++)
      {
         Blding142PlatformSensorCommandMsg platform_sensor_command;

         std::string dish_name = getDishAsString(rac_ptr->m_body.Transmit_Commands[idx].Dish);

         strncpy(platform_sensor_command.m_body.Dish, dish_name.c_str(), sizeof(platform_sensor_command.m_body.Dish));

         platform_sensor_command.m_body.Command_Type                      = 2;
         platform_sensor_command.m_body.Transmit_Command.Pulsewidth_usec  = rac_ptr->m_body.Transmit_Commands[idx].Pulsewidth_usec;
         platform_sensor_command.m_body.Transmit_Command.Amplitude        = rac_ptr->m_body.Transmit_Commands[idx].Amplitude;
         platform_sensor_command.m_body.Transmit_Command.Bandwidth_MHz    = rac_ptr->m_body.Transmit_Commands[idx].Bandwidth_MHz;
         platform_sensor_command.m_body.Transmit_Command.Offset_MHz       = rac_ptr->m_body.Transmit_Commands[idx].Offset_MHz;
         platform_sensor_command.m_body.Transmit_Command.Samples_Per_Chip = rac_ptr->m_body.Transmit_Commands[idx].Samples_Per_Chip;
         platform_sensor_command.m_body.Transmit_Command.Gold_Code_Index  = rac_ptr->m_body.Transmit_Commands[idx].Gold_Code_Index;
         platform_sensor_command.m_body.Transmit_Command.Num_Pulses       = rac_ptr->m_body.Transmit_Commands[idx].Num_Pulses;
         platform_sensor_command.m_body.Transmit_Command.Repetition_Count = rac_ptr->m_body.Transmit_Commands[idx].Repetition_Count;

         // Remove the following log
         Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::DEBUG,
                                                "RadarActionControlMsgHandler::processInternalMsg() \n "
                                                "Dish:%s \n Command_Type:%d \n Pulsewidth_usec:%f \n Amplitude:%f \n Bandwidth_MHz:%d \n Phase_Offsec_psec:%f \n "
                                                "Offset_MHz:%d \n Samples_Per_Chip:%d \n Gold_Code_Index:%d \n Num_Pulses:%d \n Repetition_Count:%d",
                                                platform_sensor_command.m_body.Dish,
                                                platform_sensor_command.m_body.Command_Type,
                                                platform_sensor_command.m_body.Transmit_Command.Pulsewidth_usec,
                                                platform_sensor_command.m_body.Transmit_Command.Amplitude,
                                                platform_sensor_command.m_body.Transmit_Command.Bandwidth_MHz,
                                                platform_sensor_command.m_body.Transmit_Command.Phase_Offsec_psec,
                                                platform_sensor_command.m_body.Transmit_Command.Offset_MHz,
                                                platform_sensor_command.m_body.Transmit_Command.Samples_Per_Chip,
                                                platform_sensor_command.m_body.Transmit_Command.Gold_Code_Index,
                                                platform_sensor_command.m_body.Transmit_Command.Num_Pulses,
                                                platform_sensor_command.m_body.Transmit_Command.Repetition_Count);

         sendPlatformSensorCommandMessage(platform_sensor_command, dish_name);
      }
      
   }
}

std::string RadarActionControlMsgHandler::getDishAsString(int p_val)
{
   std::string dish_name = "";

   switch(p_val)
   {
      case 1:
         dish_name = "Dickie";
      break;
      case 2:
         dish_name = "Penzias";
      break;
      case 3:
         dish_name = "Wilson";
      break;
      default:
         Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::ERROR,
                                                "RadarActionControlMsgHandler::processInternalMsg() Unknown/Invalid Blding142 Dish value: %d",
                                                p_val);
      break;
   }

   return dish_name;
}

void RadarActionControlMsgHandler::sendPlatformSensorCommandMessage(Blding142PlatformSensorCommandMsg &p_psc_msg,
                                                                    const std::string &dish)
{
   if(dish == "Dickie") //filter for Dickie only
   {

      m_component_handle->platformInterface()->sendMsg(dish,
                                                    "TcTactical",
                                                    &p_psc_msg);

      m_component_handle->platformInterface()->sendMsg(dish,
                                                    "SdTactical",
                                                    &p_psc_msg);
   }
}
