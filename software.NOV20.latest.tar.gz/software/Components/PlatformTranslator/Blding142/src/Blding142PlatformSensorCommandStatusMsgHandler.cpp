#include "Blding142PlatformSensorCommandStatusMsgHandler.h"
#include "Blding142PlatformTranslatorComponent.h"
#include "LogService.h"
#include "MsgService.h"
#include "NodeService.h"
#include "RadarActionReturnMsg.h"
#include "Service.h"
#include "Blding142PlatformSensorCommandStatusMsg.h" //@SL
#include <cstring>

Blding142PlatformSensorCommandStatusMsgHandler::Blding142PlatformSensorCommandStatusMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void Blding142PlatformSensorCommandStatusMsgHandler::processExternalMsg(const Blding142Msg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "Blding142PlatformSensorCommandStatusMsgHandler::processExternalMsg() called");

   //RadarActionReturnMsg radar_action_return_msg;

   //@SL map SLEW cmd status to radar_action_return_msg 
   const Blding142PlatformSensorCommandStatusMsg * status_ptr   = reinterpret_cast< const Blding142PlatformSensorCommandStatusMsg*>(p_msg);

   if(status_ptr)

   {    std::string dish_name(status_ptr->m_body.Dish);

        if("Dickie" == dish_name) //Dickie
        {
          if( 1 == status_ptr->m_body.Command_Type) //slew
          {
              RadarActionReturnMsg radar_action_return_msg;

              strncpy(radar_action_return_msg.m_body.Dish,"Dickie",sizeof(radar_action_return_msg.m_body.Dish));
              radar_action_return_msg.m_body.Command_Type                   = 1;
              radar_action_return_msg.m_body.Slew_Command.Azimuth_Degrees   = status_ptr->m_body.Slew_Command.Azimuth_Degrees;
              radar_action_return_msg.m_body.Slew_Command.Elevation_Degrees = status_ptr->m_body.Slew_Command.Elevation_Degrees;

              Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                              Service<NodeService>::getInstance().componentNameToComponentId("PlatformServices"),
                                              &radar_action_return_msg);
          }                                

        }

        else if("Penzias" == dish_name) //Penzias
        {
          if( 1 == status_ptr->m_body.Command_Type) //slew
          {
              RadarActionReturnMsg radar_action_return_msg;

              strncpy(radar_action_return_msg.m_body.Dish,"Penzias", sizeof(radar_action_return_msg.m_body.Dish));
              radar_action_return_msg.m_body.Command_Type                   = 1;
              radar_action_return_msg.m_body.Slew_Command.Azimuth_Degrees   = status_ptr->m_body.Slew_Command.Azimuth_Degrees;
              radar_action_return_msg.m_body.Slew_Command.Elevation_Degrees = status_ptr->m_body.Slew_Command.Elevation_Degrees;

              Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                              Service<NodeService>::getInstance().componentNameToComponentId("PlatformServices"),
                                              &radar_action_return_msg);
          }                                

        }
        else if("Wilson" == dish_name) //Penzias
        {
          if( 1 == status_ptr->m_body.Command_Type) //slew
          {
              RadarActionReturnMsg radar_action_return_msg;

              strncpy(radar_action_return_msg.m_body.Dish,"Wilson", sizeof(radar_action_return_msg.m_body.Dish));
              radar_action_return_msg.m_body.Command_Type                   = 1;
              radar_action_return_msg.m_body.Slew_Command.Azimuth_Degrees   = status_ptr->m_body.Slew_Command.Azimuth_Degrees;
              radar_action_return_msg.m_body.Slew_Command.Elevation_Degrees = status_ptr->m_body.Slew_Command.Elevation_Degrees;

              Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                              Service<NodeService>::getInstance().componentNameToComponentId("PlatformServices"),
                                              &radar_action_return_msg);
          }                                

        }




   }
     

/*
   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                              Service<NodeService>::getInstance().componentNameToComponentId("PlatformServices"),
                                              &radar_action_return_msg);
*/

}

