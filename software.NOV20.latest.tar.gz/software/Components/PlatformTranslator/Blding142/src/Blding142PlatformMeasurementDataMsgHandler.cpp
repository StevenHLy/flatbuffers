#include "Blding142PlatformMeasurementDataMsgHandler.h"
#include "Blding142PlatformTranslatorComponent.h"
#include "LogService.h"
#include "PlatformMeasurementDataMsg.h"
#include "Service.h"
#include "Blding142PlatformMeasurementDataMsg.h" //@SL
#include <iostream> //@SL
#include <cstring>
Blding142PlatformMeasurementDataMsgHandler::Blding142PlatformMeasurementDataMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void Blding142PlatformMeasurementDataMsgHandler::processExternalMsg(const Blding142Msg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "Blding142PlatformMeasurementDataMsgHandler::processExternalMsg() called");

   //PlatformMeasurementDataMsg platform_measurement_data;
   //@SL
   //Map from const Blding142PlatformMeasurementDataMsg into platform_measurement_data then send to Serv

   const Blding142PlatformMeasurementDataMsg * meas_ptr   = reinterpret_cast< const Blding142PlatformMeasurementDataMsg*>(p_msg);


   if (meas_ptr)
   {
     std::string dish_name(meas_ptr->m_body.Dish); 

     if("Dickie" == meas_ptr->m_body.Dish) //Dickie
     {

       PlatformMeasurementDataMsg platform_measurement_data;

       if( 2 == meas_ptr->m_body.Command_Type) //Transmit
       {
         platform_measurement_data.m_body.Command_Type                        = meas_ptr->m_body.Command_Type;

         strncpy(platform_measurement_data.m_body.Dish, "Dickie",sizeof(platform_measurement_data.m_body.Dish));
         
         platform_measurement_data.m_body.Transmit_Command.Pulsewidth_usec    = meas_ptr->m_body.Transmit_Command.Pulsewidth_usec;
         platform_measurement_data.m_body.Transmit_Command.Amplitude          = meas_ptr->m_body.Transmit_Command.Amplitude;
         platform_measurement_data.m_body.Transmit_Command.Bandwidth_MHz      = meas_ptr->m_body.Transmit_Command.Bandwidth_MHz;
         platform_measurement_data.m_body.Transmit_Command.Offset_MHz         = meas_ptr->m_body.Transmit_Command.Offset_MHz;
         platform_measurement_data.m_body.Transmit_Command.Samples_Per_Chip   = meas_ptr->m_body.Transmit_Command.Samples_Per_Chip;
         platform_measurement_data.m_body.Transmit_Command.Gold_Code_Index    = meas_ptr->m_body.Transmit_Command.Gold_Code_Index;
         platform_measurement_data.m_body.Transmit_Command.Num_Pulses         = meas_ptr->m_body.Transmit_Command.Num_Pulses;
         platform_measurement_data.m_body.Transmit_Command.Repetition_Count   = meas_ptr->m_body.Transmit_Command.Repetition_Count;


         std::cout<<"@@@platform_measurement_data.m_body.Command_Type::"<<platform_measurement_data.m_body.Command_Type <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Dish::"<<platform_measurement_data.m_body.Dish <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Transmit_Command.Pulsewidth_usec::"<<platform_measurement_data.m_body.Transmit_Command.Pulsewidth_usec <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Transmit_Command.Amplitude::"<<platform_measurement_data.m_body.Transmit_Command.Amplitude <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Transmit_Command.Bandwidth_MHz::"<<platform_measurement_data.m_body.Transmit_Command.Bandwidth_MHz <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Transmit_Command.Offset_MHz::"<<platform_measurement_data.m_body.Transmit_Command.Offset_MHz <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Transmit_Command.Samples_Per_Chip::"<<platform_measurement_data.m_body.Transmit_Command.Samples_Per_Chip <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Transmit_Command.Gold_Code_Index::"<<platform_measurement_data.m_body.Transmit_Command.Gold_Code_Index <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Transmit_Command.Num_Pulses::"<<platform_measurement_data.m_body.Transmit_Command.Num_Pulses <<std::endl;
         std::cout<<"@@@platform_measurement_data.m_body.Transmit_Command.Repetition_Count::"<<platform_measurement_data.m_body.Transmit_Command.Repetition_Count <<std::endl;



         Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                              Service<NodeService>::getInstance().componentNameToComponentId("PlatformServices"),
                                           &platform_measurement_data);
       }



     }
     else if ("Penzias" == dish_name) //Penzias
     { 

       PlatformMeasurementDataMsg platform_measurement_data;


     }
     else  if ("Wilson" == dish_name) //Wilson
     {
       PlatformMeasurementDataMsg platform_measurement_data;

     }

   }
/*
   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                              Service<NodeService>::getInstance().componentNameToComponentId("PlatformServices"),
                                           &platform_measurement_data);
*/
}

