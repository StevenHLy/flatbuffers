#ifndef SignalProcessingCommandMsgHandler_h
#define SignalProcessingCommandMsgHandler_h

#include "InternalMsg.h"
#include "InternalMsgHandler.h"

class Blding142PlatformTranslatorComponent;

class SignalProcessingCommandMsgHandler : public InternalMsgHandler
{
   public:

      SignalProcessingCommandMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle);
      ~SignalProcessingCommandMsgHandler() = default;

      void processInternalMsg(const InternalMsg* p_msg) override;

   protected:

      Blding142PlatformTranslatorComponent* m_component_handle;
};

#endif
