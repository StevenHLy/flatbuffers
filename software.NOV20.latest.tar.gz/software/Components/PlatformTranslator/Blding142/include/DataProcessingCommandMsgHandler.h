#ifndef DataProcessingCommandMsgHandler_h
#define DataProcessingCommandMsgHandler_h

#include "InternalMsg.h"
#include "InternalMsgHandler.h"

class Blding142PlatformTranslatorComponent;

class DataProcessingCommandMsgHandler : public InternalMsgHandler
{
   public:

      DataProcessingCommandMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle);
      ~DataProcessingCommandMsgHandler() = default;

      void processInternalMsg(const InternalMsg* p_msg) override;

   protected:

      Blding142PlatformTranslatorComponent* m_component_handle;
};

#endif
