#ifndef Blding142PlatformTranslatorComponent_h
#define Blding142PlatformTranslatorComponent_h

#include "Blding142Msg.h"
#include "Blding142PlatformInterface.h"
#include "DscPlatformBoundaryComponent.h"

class Blding142PlatformTranslatorComponent : public DscPlatformBoundaryComponent<Blding142Msg>
{
   public:

      static constexpr const char* COMPONENT_NAME = "Blding142PlatformTranslator";

      Blding142PlatformTranslatorComponent(unsigned int p_component_id);
      ~Blding142PlatformTranslatorComponent() = default;

      void initializeComponent() override;
      void processQueuedMsg() override;
      void queueReceivedMsg(Blding142Msg* p_msg) override;
      void shutdownComponent() override;

      Blding142PlatformInterface* platformInterface();

   protected:

      Blding142PlatformInterface m_platform_interface;
};

#endif
