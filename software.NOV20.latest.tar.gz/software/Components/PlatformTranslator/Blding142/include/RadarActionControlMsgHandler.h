#ifndef RadarActionControlMsgHandler_h
#define RadarActionControlMsgHandler_h

#include "InternalMsg.h"
#include "InternalMsgHandler.h"

#include<string>

class Blding142PlatformTranslatorComponent;
class Blding142PlatformSensorCommandMsg;

class RadarActionControlMsgHandler : public InternalMsgHandler
{
   public:

      RadarActionControlMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle);
      ~RadarActionControlMsgHandler() = default;

      void processInternalMsg(const InternalMsg* p_msg) override;
      std::string getDishAsString(int p_val);
      void sendPlatformSensorCommandMessage(Blding142PlatformSensorCommandMsg &p_psc_msg,
                                            const std::string &dish);

   protected:

      Blding142PlatformTranslatorComponent* m_component_handle;
};

#endif
