#ifndef Blding142PlatformMeasurementDataMsgHandler_h
#define Blding142PlatformMeasurementDataMsgHandler_h

#include "Blding142Msg.h"
#include "ExternalMsgHandler.h"

class Blding142PlatformTranslatorComponent;

class Blding142PlatformMeasurementDataMsgHandler : public ExternalMsgHandler<Blding142Msg>
{
   public:

      Blding142PlatformMeasurementDataMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle);
      ~Blding142PlatformMeasurementDataMsgHandler() = default;

      void processExternalMsg(const Blding142Msg* p_msg) override;

   protected:

      Blding142PlatformTranslatorComponent* m_component_handle;
};

#endif
