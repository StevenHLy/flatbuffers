#ifndef Blding142PlatformSensorCommandStatusMsgHandler_h
#define Blding142PlatformSensorCommandStatusMsgHandler_h

#include "Blding142Msg.h"
#include "ExternalMsgHandler.h"

class Blding142PlatformTranslatorComponent;

class Blding142PlatformSensorCommandStatusMsgHandler : public ExternalMsgHandler<Blding142Msg>
{
   public:

      Blding142PlatformSensorCommandStatusMsgHandler(Blding142PlatformTranslatorComponent* p_component_handle);
      ~Blding142PlatformSensorCommandStatusMsgHandler() = default;

      void processExternalMsg(const Blding142Msg* p_msg) override;

   protected:

      Blding142PlatformTranslatorComponent* m_component_handle;
};

#endif
