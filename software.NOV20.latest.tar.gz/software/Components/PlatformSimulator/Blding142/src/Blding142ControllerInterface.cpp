#include "Blding142ControllerInterface.h"
#include "Blding142PlatformSimulatorComponent.h"
#include "ConfigParameters.h"
#include "DscException.h"
#include "LogService.h"
#include "NodeService.h"
#include "PollingService.h"
#include "Service.h"
#include "TimeService.h"
#include <exception>

Blding142ControllerInterface::Blding142ControllerInterface(Blding142PlatformSimulatorComponent* p_component_handle)
: m_polling_id(0)
, m_platforms()
, m_component_handle(p_component_handle)
{
}

void Blding142ControllerInterface::closeControllerConnections()
{
   for (auto& platform : m_platforms)
   {
      for (auto& connection : platform.second.m_network_connections)
      {
         if (connection.second.m_socket->isSocketConnected())
         {
            connection.second.m_socket->setSocketOptDropMembership();
            connection.second.m_socket->closeSocket();
         }
      }
   }
}

std::string Blding142ControllerInterface::connectionIdToConnectionName(std::string p_platform_name,
                                                                       unsigned int p_platform_connection_id)
{
   std::string connection_name = "";
   std::map<std::string, PlatformData>::iterator it = m_platforms.find(p_platform_name);

   if (it != m_platforms.end())
   {
      for (auto& connection : it->second.m_network_connections)
      {
         if (connection.second.m_connection_id == p_platform_connection_id)
         {
            connection_name = connection.first;
            break;
         }
      }
   }

   return connection_name;
}

unsigned int Blding142ControllerInterface::connectionNameToConnectionId(std::string p_platform_name,
                                                                         std::string p_platform_connection_name)
{
   unsigned int connection_id = 0;

   try
   {
      connection_id = m_platforms.at(p_platform_name).m_network_connections.at(p_platform_connection_name).m_connection_id;
   }
   catch(std::out_of_range const& e)
   {
   }

   return connection_id;
}

bool Blding142ControllerInterface::controllerConnectionsEstablished()
{
   bool all_connections_established = true;

   for (auto& platform : m_platforms)
   {
      for (auto& connection : platform.second.m_network_connections)
      {
         if (not connection.second.m_socket->isSocketConnected())
         {
            all_connections_established = false;
            break;
         }
      }
   }

   return all_connections_established;
}

void Blding142ControllerInterface::establishControllerConnections()
{
   double current_time = Service<TimeService>::getInstance().currentTimeSecs();

   for (auto& platform : m_platforms)
   {
      for (auto& connection : platform.second.m_network_connections)
      {
         if (not connection.second.m_socket->isSocketConnected())
         {
            double connection_attempt_delta_time = current_time - connection.second.m_time_of_last_outbound_connection_attempt;

            if (connection_attempt_delta_time >= connection.second.m_connection_attempt_interval)
            {
               connection.second.m_time_of_last_outbound_connection_attempt = current_time;

               Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                      __FILE__,
                                                      __LINE__,
                                                      LogSeverityTypeEnum::INFO,
                                                      "Blding142ControllerInterface attempting to join multicast group using %s:%d",
                                                      connection.second.m_socket->ipAddress().c_str(),
                                                      connection.second.m_socket->port());

               try
               {
                  connection.second.m_socket->createSocket();
                  connection.second.m_socket->setNonBlocking(true);
                  connection.second.m_socket->setSocketOptReuseAddr(true);
                  connection.second.m_socket->setSocketOptMulticastTtl(connection.second.m_time_to_live);
                  connection.second.m_socket->setSocketOptMulticastLoop(true);
                  connection.second.m_socket->bindLocalPort();
                  connection.second.m_socket->setSocketOptAddMembership();
               }
               catch(DscException const& e_dsc)
               {
                  Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                         __FILE__,
                                                         __LINE__,
                                                         LogSeverityTypeEnum::ERROR,
                                                         "Blding142ControllerInterface DscException(%s) using %s:%d",
                                                         e_dsc.what(),
                                                         connection.second.m_socket->ipAddress().c_str(),
                                                         connection.second.m_socket->port());

                  connection.second.m_socket->closeSocket();
               }
               catch(std::exception const& e_std)
               {
                  Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                         __FILE__,
                                                         __LINE__,
                                                         LogSeverityTypeEnum::ERROR,
                                                         "Blding142ControllerInterface std::exception(%s) using %s:%d",
                                                         e_std.what(),
                                                         connection.second.m_socket->ipAddress().c_str(),
                                                         connection.second.m_socket->port());

                  connection.second.m_socket->closeSocket();
               }

               if (connection.second.m_socket->isSocketConnected())
               {
                  Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                         __FILE__,
                                                         __LINE__,
                                                         LogSeverityTypeEnum::INFO,
                                                         "Blding142ControllerInterface joined multicast group using %s:%d",
                                                         connection.second.m_socket->ipAddress().c_str(),
                                                         connection.second.m_socket->port());
               }
               else
               {
                  Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                         __FILE__,
                                                         __LINE__,
                                                         LogSeverityTypeEnum::WARNING,
                                                         "Blding142ControllerInterface unable to join multicast group using %s:%d",
                                                         connection.second.m_socket->ipAddress().c_str(),
                                                         connection.second.m_socket->port());
               }
            }
         }
      }
   }
}

void Blding142ControllerInterface::initialize()
{
   ConfigParameters::iterator platform_iter, connection_iter;

   for (platform_iter = ConfigParameters::getInstance().getPropertyTree().get_child("SiteConfiguration.Building142.Platforms").begin();
        platform_iter != ConfigParameters::getInstance().getPropertyTree().get_child("SiteConfiguration.Building142.Platforms").end();
        ++platform_iter)
   {
      unsigned int platform_id = ConfigParameters::getInstance().getRequiredParam<unsigned int>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".Platform_Id");

      PlatformData& new_platform = m_platforms[platform_iter->first];
      new_platform.m_platform_id = ConfigParameters::getInstance().getRequiredParam<unsigned int>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".Platform_Id");

      for (connection_iter = ConfigParameters::getInstance().getPropertyTree().get_child("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections").begin();
           connection_iter != ConfigParameters::getInstance().getPropertyTree().get_child("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections").end();
           ++connection_iter)
      {
         bool enabled = ConfigParameters::getInstance().getRequiredParam<bool>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections." + connection_iter->first + ".Enabled");

         if (enabled)
         {
            std::string ip_address = ConfigParameters::getInstance().getRequiredParam<std::string>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections." + connection_iter->first + ".IP_Address");
            int port_number =  ConfigParameters::getInstance().getRequiredParam<int>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections." + connection_iter->first + ".Port_Number");

            NetworkConnectionData& new_connection = new_platform.m_network_connections[connection_iter->first];
            new_connection.m_connection_id = ConfigParameters::getInstance().getRequiredParam<unsigned int>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections." + connection_iter->first + ".Connection_Id");
            new_connection.m_connection_attempt_interval = ConfigParameters::getInstance().getRequiredParam<double>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections." + connection_iter->first + ".Connection_Attempt_Interval_Secs");
            new_connection.m_time_to_live = ConfigParameters::getInstance().getRequiredParam<unsigned int>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections." + connection_iter->first + ".Time_To_Live");
            new_connection.m_incoming_msg_buffer.reset(new GenericBuffer<unsigned char>(ConfigParameters::getInstance().getRequiredParam<unsigned int>("SiteConfiguration.Building142.Platforms." + platform_iter->first + ".NetworkConnections." + connection_iter->first + ".Incoming_Msg_Buffer_Size_Bytes")));
            new_connection.m_socket.reset(new MulticastSocketImpl(ip_address, port_number));
         }
      }
   }

   m_polling_id = Service<PollingService>::getInstance().registerCallback(PollingService::MethodCallbackType([this]()
                                                                                                             {
                                                                                                                this->run();
                                                                                                             }));

   Service<PollingService>::getInstance().enableCallback(m_polling_id);
}

MulticastSocketImpl* Blding142ControllerInterface::networkConnection(unsigned int p_platform_id,
                                                                     unsigned int p_platform_connection_id)
{
   MulticastSocketImpl* platform_interface = nullptr;

   for (auto& platform : m_platforms)
   {
      if (platform.second.m_platform_id == p_platform_id)
      {
         for (auto& connection : platform.second.m_network_connections)
         {
            if (connection.second.m_connection_id == p_platform_connection_id)
            {
               platform_interface = connection.second.m_socket.get();
               break;
            }
         }
      }
   }

   return platform_interface;
}

MulticastSocketImpl* Blding142ControllerInterface::networkConnection(std::string p_platform_name,
                                                                     std::string p_platform_interface_name)
{
   MulticastSocketImpl* platform_interface = nullptr;

   try
   {
      platform_interface = m_platforms.at(p_platform_name).m_network_connections.at(p_platform_interface_name).m_socket.get();
   }
   catch(std::out_of_range const& e)
   {
   }

   return platform_interface;
}

std::string Blding142ControllerInterface::platformIdToPlatformName(unsigned int p_platform_id)
{
   std::string platform_name = "";

   for (auto& platform : m_platforms)
   {
      if (platform.second.m_platform_id == p_platform_id)
      {
         platform_name = platform.first;
         break;
      }
   }

   return platform_name;
}

unsigned int Blding142ControllerInterface::platformNameToPlatformId(std::string p_platform_name)
{
   unsigned int platform_id = 0;
   std::map<std::string, PlatformData>::iterator it = m_platforms.find(p_platform_name);

   if (it != m_platforms.end())
   {
      platform_id = it->second.m_platform_id;
   }

   return platform_id;
}

void Blding142ControllerInterface::receivePendingControllerMessages()
{
   for (auto& platform : m_platforms)
   {
      for (auto& connection : platform.second.m_network_connections)
      {
         if (connection.second.m_socket->isSocketConnected())
         {
            bool recv_error = false;
            int byte_count = 0;

            connection.second.m_incoming_msg_buffer->init();

            try
            {
               byte_count = connection.second.m_socket->recvMessage(connection.second.m_incoming_msg_buffer->buffer(),
                                                                    connection.second.m_incoming_msg_buffer->bufferSize());
            }
            catch(DscException const& e_dsc)
            {
               Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                      __FILE__,
                                                      __LINE__,
                                                      LogSeverityTypeEnum::ERROR,
                                                      "Blding142ControllerInterface DscException(%s) using %s:%d",
                                                      e_dsc.what(),
                                                      connection.second.m_socket->ipAddress().c_str(),
                                                      connection.second.m_socket->port());

               recv_error = true;
            }
            catch(std::exception const& e_std)
            {
               Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                      __FILE__,
                                                      __LINE__,
                                                      LogSeverityTypeEnum::ERROR,
                                                      "Blding142ControllerInterface std::exception(%s) using %s:%d",
                                                      e_std.what(),
                                                      connection.second.m_socket->ipAddress().c_str(),
                                                      connection.second.m_socket->port());

               recv_error = true;
            }

            if (not recv_error && byte_count > 0)
            {
               m_component_handle->queueReceivedMsg((Blding142Msg*)connection.second.m_incoming_msg_buffer->buffer());
            }
            else
            {
               if (recv_error)
               {
                  connection.second.m_socket->setSocketOptDropMembership();
                  connection.second.m_socket->closeSocket();
               }
            }
         }
      }
   }
}

void Blding142ControllerInterface::run()
{
   if (not controllerConnectionsEstablished())
   {
      establishControllerConnections();
   }

   receivePendingControllerMessages();
   m_component_handle->processQueuedMsg();
}

void Blding142ControllerInterface::sendMsg(unsigned int p_platform_id,
                                           unsigned int p_platform_connection_id,
                                           Blding142Msg* p_msg)
{
   p_msg->m_header.m_platform_id = p_platform_id;
   p_msg->m_header.m_connection_id = p_platform_connection_id;
   p_msg->m_header.m_send_time = Service<TimeService>::getInstance().currentTimeSecs();

   networkConnection(p_platform_id, p_platform_connection_id)->sendMessage(p_msg,
                                                                           p_msg->m_header.m_msg_size);
}

void Blding142ControllerInterface::sendMsg(std::string p_platform_name,
                                           std::string p_platform_connection_name,
                                           Blding142Msg* p_msg)
{
   p_msg->m_header.m_platform_id = platformNameToPlatformId(p_platform_name);
   p_msg->m_header.m_connection_id = connectionNameToConnectionId(p_platform_name,
                                                                  p_platform_connection_name);
   p_msg->m_header.m_send_time = Service<TimeService>::getInstance().currentTimeSecs();

   networkConnection(p_platform_name, p_platform_connection_name)->sendMessage(p_msg,
                                                                               p_msg->m_header.m_msg_size);

}

void Blding142ControllerInterface::shutdown()
{
   closeControllerConnections();
}
