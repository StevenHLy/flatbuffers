#include "Blding142PlatformSensorCommandMsgHandler.h"
#include "Blding142PlatformMeasurementDataMsg.h"
#include "Blding142PlatformSensorCommandStatusMsg.h"
#include "Blding142PlatformSimulatorComponent.h"
#include "LogService.h"
#include "MsgService.h"
#include "NodeService.h"
#include "Service.h"
#include "Blding142PlatformSensorCommandMsg.h"
#include <iostream> //@SL
#include <sstream>
#include <vector>
#include <string>
#include <cstring>

Blding142PlatformSensorCommandMsgHandler::Blding142PlatformSensorCommandMsgHandler(Blding142PlatformSimulatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void Blding142PlatformSensorCommandMsgHandler::processExternalMsg(const Blding142Msg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "Blding142PlatformSensorCommandMsgHandler::processExternalMsg() called");

  // Blding142PlatformSensorCommandStatusMsg blding142_platform_sensor_command_status_msg;
  // Blding142PlatformMeasurementDataMsg blding142_platform_measurement_data_msg;
  //@SL
   const Blding142PlatformSensorCommandMsg * sensor_ptr = reinterpret_cast< const Blding142PlatformSensorCommandMsg*>(p_msg);

   int count = 250 ; 

   if(sensor_ptr)
   {
         std::string dish_name(sensor_ptr->m_body.Dish); 

         if ("Dickie" == dish_name) //Dickie
         {

            if (1 ==  sensor_ptr->m_body.Command_Type) // slew
            {
               Blding142PlatformSensorCommandStatusMsg blding142_platform_sensor_command_status_msg;

               blding142_platform_sensor_command_status_msg.m_body.Command_Type = 1;

               strncpy(blding142_platform_sensor_command_status_msg.m_body.Dish, "Dickie", sizeof(blding142_platform_sensor_command_status_msg.m_body.Dish));
               
               blding142_platform_sensor_command_status_msg.m_body.Slew_Command.Azimuth_Degrees   = sensor_ptr->m_body.Slew_Command.Azimuth_Degrees ;
               blding142_platform_sensor_command_status_msg.m_body.Slew_Command.Elevation_Degrees = sensor_ptr->m_body.Slew_Command.Elevation_Degrees ;
               m_component_handle->controllerInterface()->sendMsg("Dickie",
                                                                  "RpTactical",
                                                                  &blding142_platform_sensor_command_status_msg);
            
            }

            else if (2 ==   sensor_ptr->m_body.Command_Type) //transmit
            {
               Blding142PlatformMeasurementDataMsg blding142_platform_measurement_data_msg;

               blding142_platform_measurement_data_msg.m_body.Command_Type = 2;

               strncpy(blding142_platform_measurement_data_msg.m_body.Dish, "Dickie", sizeof(blding142_platform_measurement_data_msg.m_body.Dish));


               blding142_platform_measurement_data_msg.m_body.executeSensorCommands (count, sensor_ptr->m_body.Dish ); 
               
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Pulsewidth_usec  = sensor_ptr->m_body.Transmit_Command.Pulsewidth_usec;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Amplitude        = sensor_ptr->m_body.Transmit_Command.Amplitude;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Bandwidth_MHz    = sensor_ptr->m_body.Transmit_Command.Bandwidth_MHz;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Offset_MHz       = sensor_ptr->m_body.Transmit_Command.Offset_MHz;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Samples_Per_Chip = sensor_ptr->m_body.Transmit_Command.Samples_Per_Chip;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Gold_Code_Index  = sensor_ptr->m_body.Transmit_Command.Gold_Code_Index;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Num_Pulses       = sensor_ptr->m_body.Transmit_Command.Num_Pulses;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Repetition_Count = sensor_ptr->m_body.Transmit_Command.Repetition_Count;

               m_component_handle->controllerInterface()->sendMsg("Dickie",
                                                                  "RpTactical",
                                                                  &blding142_platform_measurement_data_msg);
            }



         }

         else if ("Penzias" == dish_name) //Penzias
         {

            if (1 ==  sensor_ptr->m_body.Command_Type) // slew
            {
               Blding142PlatformSensorCommandStatusMsg blding142_platform_sensor_command_status_msg;

               blding142_platform_sensor_command_status_msg.m_body.Command_Type = 1;

               strncpy(blding142_platform_sensor_command_status_msg.m_body.Dish, "Penzias", sizeof(blding142_platform_sensor_command_status_msg.m_body.Dish));
        
               blding142_platform_sensor_command_status_msg.m_body.Slew_Command.Azimuth_Degrees   = sensor_ptr->m_body.Slew_Command.Azimuth_Degrees ;
               blding142_platform_sensor_command_status_msg.m_body.Slew_Command.Elevation_Degrees = sensor_ptr->m_body.Slew_Command.Elevation_Degrees ;
               m_component_handle->controllerInterface()->sendMsg("Penzias",
                                                                  "RpTactical",
                                                                  &blding142_platform_sensor_command_status_msg);
            
            }

            else if (2 ==   sensor_ptr->m_body.Command_Type)
            {
               Blding142PlatformMeasurementDataMsg blding142_platform_measurement_data_msg;

               blding142_platform_measurement_data_msg.m_body.Command_Type = 2;

               strncpy(blding142_platform_measurement_data_msg.m_body.Dish, "Penzias", sizeof(blding142_platform_measurement_data_msg.m_body.Dish));

               blding142_platform_measurement_data_msg.m_body.executeSensorCommands (count, sensor_ptr->m_body.Dish ); 
               
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Pulsewidth_usec  = sensor_ptr->m_body.Transmit_Command.Pulsewidth_usec;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Amplitude        = sensor_ptr->m_body.Transmit_Command.Amplitude;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Bandwidth_MHz    = sensor_ptr->m_body.Transmit_Command.Bandwidth_MHz;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Offset_MHz       = sensor_ptr->m_body.Transmit_Command.Offset_MHz;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Samples_Per_Chip = sensor_ptr->m_body.Transmit_Command.Samples_Per_Chip;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Gold_Code_Index  = sensor_ptr->m_body.Transmit_Command.Gold_Code_Index;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Num_Pulses       = sensor_ptr->m_body.Transmit_Command.Num_Pulses;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Repetition_Count = sensor_ptr->m_body.Transmit_Command.Repetition_Count;

               m_component_handle->controllerInterface()->sendMsg("Penzias",
                                                                  "RpTactical",
                                                                  &blding142_platform_measurement_data_msg);
            }




         }

         else if ("Wilson" == dish_name) //Wilson
         {
            if (1 ==  sensor_ptr->m_body.Command_Type) // slew
            {
               Blding142PlatformSensorCommandStatusMsg blding142_platform_sensor_command_status_msg;

               blding142_platform_sensor_command_status_msg.m_body.Command_Type = 1;

               strncpy(blding142_platform_sensor_command_status_msg.m_body.Dish, "Wilson", sizeof(blding142_platform_sensor_command_status_msg.m_body.Dish));

               blding142_platform_sensor_command_status_msg.m_body.Slew_Command.Azimuth_Degrees   = sensor_ptr->m_body.Slew_Command.Azimuth_Degrees ;
               blding142_platform_sensor_command_status_msg.m_body.Slew_Command.Elevation_Degrees = sensor_ptr->m_body.Slew_Command.Elevation_Degrees ;
               m_component_handle->controllerInterface()->sendMsg("Wilson",
                                                                  "RpTactical",
                                                                  &blding142_platform_sensor_command_status_msg);
            
            }

            else if (2 ==  sensor_ptr->m_body.Command_Type)
            {
               Blding142PlatformMeasurementDataMsg blding142_platform_measurement_data_msg;

               blding142_platform_measurement_data_msg.m_body.Command_Type = 2;

               strncpy(blding142_platform_measurement_data_msg.m_body.Dish, "Wilson", sizeof(blding142_platform_measurement_data_msg.m_body.Dish));

               blding142_platform_measurement_data_msg.m_body.executeSensorCommands (count, sensor_ptr->m_body.Dish ); 
               
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Pulsewidth_usec  = sensor_ptr->m_body.Transmit_Command.Pulsewidth_usec;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Amplitude        = sensor_ptr->m_body.Transmit_Command.Amplitude;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Bandwidth_MHz    = sensor_ptr->m_body.Transmit_Command.Bandwidth_MHz;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Offset_MHz       = sensor_ptr->m_body.Transmit_Command.Offset_MHz;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Samples_Per_Chip = sensor_ptr->m_body.Transmit_Command.Samples_Per_Chip;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Gold_Code_Index  = sensor_ptr->m_body.Transmit_Command.Gold_Code_Index;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Num_Pulses       = sensor_ptr->m_body.Transmit_Command.Num_Pulses;
               blding142_platform_measurement_data_msg.m_body.Transmit_Command.Repetition_Count = sensor_ptr->m_body.Transmit_Command.Repetition_Count;

               m_component_handle->controllerInterface()->sendMsg("Wilson",
                                                                  "RpTactical",
                                                                  &blding142_platform_measurement_data_msg);
            }

         }
         
         else
         {
               std::cout<<"Unknown Dish"<<std::endl;

         }

   } // END if(sensor_ptr)
}
