#include "Blding142PlatformSimulatorComponent.h"
#include "Blding142MsgIdType.h"
#include "Blding142PlatformSensorCommandMsgHandler.h"
#include "LogService.h"
#include "Service.h"
#include "TimeService.h"
#include <stdexcept>
#include <string.h>

Blding142PlatformSimulatorComponent::Blding142PlatformSimulatorComponent(unsigned int p_component_id)
: DscPlatformBoundaryComponent(Blding142PlatformSimulatorComponent::COMPONENT_NAME,
                               p_component_id)
, m_controller_interface(this)
{
}

Blding142ControllerInterface* Blding142PlatformSimulatorComponent::controllerInterface()
{
   return &m_controller_interface;
}

void Blding142PlatformSimulatorComponent::initializeComponent()
{
   Service<LogService>::getInstance().registerRequester(componentName(),
                                                        componentId());

   registerExternalMsgHandler<Blding142PlatformSensorCommandMsgHandler>((unsigned int)Blding142MsgIdType::Blding142MsgIdTypeEnum::BLDING142_MT_PLATFORM_SENSOR_COMMAND,
                                                                         this);

   controllerInterface()->initialize();
}

void Blding142PlatformSimulatorComponent::processQueuedMsg()
{
   if (not externalMsgQueue().empty())
   {
      Blding142Msg* blding142_msg = (Blding142Msg*)(*(externalMsgQueue().begin()))->buffer();

      try
      {
         externalMsgSubscribers().at((unsigned int)blding142_msg->m_header.m_msg_id)(blding142_msg);
      }
      catch(std::out_of_range const& e)
      {
         Service<LogService>::getInstance().log(componentId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::WARNING,
                                                "No registered external msg handler for component %s (%d) and msg %s (%d)",
                                                Service<NodeService>::getInstance().componentIdToComponentName(componentId()).c_str(),
                                                componentId(),
                                                Blding142MsgIdType::enumToString(blding142_msg->m_header.m_msg_id).c_str(),
                                                blding142_msg->m_header.m_msg_id);
      }

      delete(externalMsgQueue().front());
      externalMsgQueue().pop_front();
   }
}

void Blding142PlatformSimulatorComponent::queueReceivedMsg(Blding142Msg* p_msg)
{
   p_msg->m_header.m_receive_time = Service<TimeService>::getInstance().currentTimeSecs();

   GenericBuffer<unsigned char>* new_msg_buffer = new GenericBuffer<unsigned char>(p_msg->m_header.m_msg_size);

   memcpy(new_msg_buffer->buffer(),
          p_msg,
          new_msg_buffer->bufferSize());

   m_msg_queue.push_back(new_msg_buffer);
}

void Blding142PlatformSimulatorComponent::shutdownComponent()
{
   controllerInterface()->shutdown();
}
