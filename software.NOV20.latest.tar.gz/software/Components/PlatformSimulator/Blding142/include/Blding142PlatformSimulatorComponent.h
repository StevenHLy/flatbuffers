#ifndef Blding142PlatformSimulatorComponent_h
#define Blding142PlatformSimulatorComponent_h

#include "Blding142ControllerInterface.h"
#include "Blding142Msg.h"
#include "DscPlatformBoundaryComponent.h"

class Blding142PlatformSimulatorComponent : public DscPlatformBoundaryComponent<Blding142Msg>
{
   public:

      static constexpr const char* COMPONENT_NAME = "Blding142PlatformSimulator";

      Blding142PlatformSimulatorComponent(unsigned int p_component_id);
      ~Blding142PlatformSimulatorComponent() = default;

      void initializeComponent() override;
      void processQueuedMsg() override;
      void queueReceivedMsg(Blding142Msg* p_msg) override;
      void shutdownComponent() override;

      Blding142ControllerInterface* controllerInterface();

   protected:

      Blding142ControllerInterface m_controller_interface;
};

#endif
