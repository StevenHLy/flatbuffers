#ifndef Blding142ControllerInterface_h
#define Blding142ControllerInterface_h

#include "Blding142Msg.h"
#include "GenericBuffer.h"
#include "MulticastSocketImpl.h"
#include <map>
#include <memory>
#include <string>

class Blding142PlatformSimulatorComponent;

class Blding142ControllerInterface
{
   public:

      Blding142ControllerInterface(Blding142PlatformSimulatorComponent* p_component_handle);
      ~Blding142ControllerInterface() = default;

      std::string connectionIdToConnectionName(std::string p_platform_name,
                                               unsigned int p_platform_connection_id);
      unsigned int connectionNameToConnectionId(std::string p_platform_name,
                                                std::string p_platform_connection_name);
      void initialize();
      MulticastSocketImpl* networkConnection(unsigned int p_platform_id,
                                             unsigned int p_platform_connection_id);
      MulticastSocketImpl* networkConnection(std::string p_platform_name,
                                             std::string p_platform_interface_name);
      std::string platformIdToPlatformName(unsigned int p_platform_id);
      unsigned int platformNameToPlatformId(std::string p_platform_name);
      void run();
      void sendMsg(unsigned int p_platform_id,
                   unsigned int p_platform_connection_id,
                   Blding142Msg* p_msg);
      void sendMsg(std::string p_platform_name,
                   std::string p_platform_connection_name,
                   Blding142Msg* p_msg);
      void shutdown();

   protected:

      struct NetworkConnectionData
      {
         unsigned int m_connection_id;
         unsigned int m_time_to_live;
         double m_connection_attempt_interval;
         double m_time_of_last_outbound_connection_attempt;
         std::unique_ptr<GenericBuffer<unsigned char>> m_incoming_msg_buffer;
         std::unique_ptr<MulticastSocketImpl> m_socket;

         NetworkConnectionData()
         : m_connection_id(0)
         , m_time_to_live(0)
         , m_connection_attempt_interval(0.0)
         , m_time_of_last_outbound_connection_attempt(0.0)
         , m_incoming_msg_buffer()
         , m_socket()
         {}
      };

      struct PlatformData
      {
         unsigned int m_platform_id;
         std::map<std::string, NetworkConnectionData> m_network_connections;

         PlatformData()
         : m_platform_id(0)
         ,m_network_connections()
         {}
      };

      void closeControllerConnections();
      void establishControllerConnections();
      bool controllerConnectionsEstablished();
      void receivePendingControllerMessages();

      unsigned int m_polling_id;
      std::map<std::string, PlatformData> m_platforms;
      Blding142PlatformSimulatorComponent* m_component_handle;
};

#endif
