#ifndef Blding142PlatformSensorCommandMsgHandler_h
#define Blding142PlatformSensorCommandMsgHandler_h

#include "Blding142Msg.h"
#include "ExternalMsgHandler.h"

class Blding142PlatformSimulatorComponent;

class Blding142PlatformSensorCommandMsgHandler : public ExternalMsgHandler<Blding142Msg>
{
   public:

      Blding142PlatformSensorCommandMsgHandler(Blding142PlatformSimulatorComponent* p_component_handle);
      ~Blding142PlatformSensorCommandMsgHandler() = default;

      void processExternalMsg(const Blding142Msg* p_msg) override;

   protected:

      Blding142PlatformSimulatorComponent* m_component_handle;
};

#endif
