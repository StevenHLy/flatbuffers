#ifndef EnvironmentManager_h
#define EnvironmentManager_h

class DistributedCoordinatorComponent;

class EnvironmentManager
{
   public:

      EnvironmentManager(DistributedCoordinatorComponent* p_component_handle);
      ~EnvironmentManager() = default;

   protected:

      DistributedCoordinatorComponent* m_component_handle;
};

#endif
