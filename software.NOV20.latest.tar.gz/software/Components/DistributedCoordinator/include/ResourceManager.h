#ifndef ResourceManager_h
#define ResourceManager_h

class DistributedCoordinatorComponent;

class ResourceManager
{
   public:

      ResourceManager(DistributedCoordinatorComponent* p_component_handle);
      ~ResourceManager() = default;

   protected:

      DistributedCoordinatorComponent* m_component_handle;
};

#endif
