#ifndef SensorManager_h
#define SensorManager_h

class DistributedCoordinatorComponent;

class SensorManager
{
   public:

      SensorManager(DistributedCoordinatorComponent* p_component_handle);
      ~SensorManager() = default;

   protected:

      DistributedCoordinatorComponent* m_component_handle;
};

#endif
