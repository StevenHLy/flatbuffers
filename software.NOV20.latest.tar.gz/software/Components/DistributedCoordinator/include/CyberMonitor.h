#ifndef CyberMonitor_h
#define CyberMonitor_h

class DistributedCoordinatorComponent;

class CyberMonitor
{
   public:

      CyberMonitor(DistributedCoordinatorComponent* p_component_handle);
      ~CyberMonitor() = default;

   protected:

      DistributedCoordinatorComponent* m_component_handle;
};

#endif
