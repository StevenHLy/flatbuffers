#ifndef MissionStatusMonitor_h
#define MissionStatusMonitor_h

class DistributedCoordinatorComponent;

class MissionStatusMonitor
{
   public:

      MissionStatusMonitor(DistributedCoordinatorComponent* p_component_handle);
      ~MissionStatusMonitor() = default;

   protected:

      DistributedCoordinatorComponent* m_component_handle;
};

#endif
