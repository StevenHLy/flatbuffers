#ifndef RequestGenerator_h
#define RequestGenerator_h

class DistributedCoordinatorComponent;

class RequestGenerator
{
   public:

      RequestGenerator(DistributedCoordinatorComponent* p_component_handle);
      ~RequestGenerator() = default;

   protected:

      DistributedCoordinatorComponent* m_component_handle;
};

#endif
