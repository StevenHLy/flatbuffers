#ifndef OptimizationService_h
#define OptimizationService_h

class DistributedCoordinatorComponent;

class OptimizationService
{
   public:

      OptimizationService(DistributedCoordinatorComponent* p_component_handle);
      ~OptimizationService() = default;

   protected:

      DistributedCoordinatorComponent* m_component_handle;
};

#endif
