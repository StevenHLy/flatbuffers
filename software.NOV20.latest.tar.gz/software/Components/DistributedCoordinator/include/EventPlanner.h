#ifndef EventPlanner_h
#define EventPlanner_h

#include "ScriptProcessingData.h"
#include <map>
#include <vector>

class DistributedCoordinatorComponent;

class EventPlanner
{
   public:

      EventPlanner(DistributedCoordinatorComponent* p_component_handle);
      ~EventPlanner() = default;

      void disableScriptedRequestGeneration();
      void enableScriptedRequestGeneration();
      void disableScriptProcessing();
      void enableScriptProcessing();
      void initialize();

   protected:

      void generateScriptedRequest();
      void startScriptedDemo(double p_delay);
      void loadScenario();
      void loadStep(const std::string &p_step_path, double p_time_delay);
      void loadWaveforms();
      void scheduleScriptSteps();

      unsigned int m_request_generation_timer_id;
      unsigned int m_script_action_timer_id;
      std::map<std::string, ScriptProcessingDataBody::Waveform> waveform_repo;
      std::vector<ScriptProcessingData> step_repo;
      DistributedCoordinatorComponent* m_component_handle;
};

#endif
