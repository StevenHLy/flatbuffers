#ifndef DistributedCoordinatorComponent_h
#define DistributedCoordinatorComponent_h

#include "CyberMonitor.h"
#include "DscApplicationComponent.h"
#include "EventPlanner.h"
#include "EnvironmentManager.h"
#include "MissionStatusMonitor.h"
#include "OptimizationService.h"
#include "RequestGenerator.h"
#include "ResourceManager.h"
#include "SensorManager.h"

class DistributedCoordinatorComponent : public DscApplicationComponent
{
   public:

      static constexpr const char* COMPONENT_NAME = "DistributedCoordinator";

      DistributedCoordinatorComponent(unsigned int p_component_id);
      ~DistributedCoordinatorComponent() = default;

      void initializeComponent() override;
      void shutdownComponent() override;

      CyberMonitor* cyberMonitor();
      EventPlanner* eventPlanner();
      EnvironmentManager* environmentManager();
      MissionStatusMonitor* missionStatusMonitor();
      OptimizationService* optimizationService();
      RequestGenerator* requestGenerator();
      ResourceManager* resourceManager();
      SensorManager* sensorManager();

   protected:

      void startScriptedDemo();

      CyberMonitor m_cyber_monitor;
      EventPlanner m_event_planner;
      EnvironmentManager m_environment_manager;
      MissionStatusMonitor m_mission_status_monitor;
      OptimizationService m_optimization_service;
      RequestGenerator m_request_generator;
      ResourceManager m_resource_manager;
      SensorManager m_sensor_manager;
};

#endif
