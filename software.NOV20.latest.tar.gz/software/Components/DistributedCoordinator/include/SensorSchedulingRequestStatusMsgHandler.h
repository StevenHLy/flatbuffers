#ifndef SensorSchedulingRequestStatusMsgHandler_h
#define SensorSchedulingRequestStatusMsgHandler_h

#include "InternalMsg.h"
#include "InternalMsgHandler.h"

class DistributedCoordinatorComponent;

class SensorSchedulingRequestStatusMsgHandler : public InternalMsgHandler
{
   public:

      SensorSchedulingRequestStatusMsgHandler(DistributedCoordinatorComponent* p_component_handle);
      ~SensorSchedulingRequestStatusMsgHandler() = default;

      void processInternalMsg(const InternalMsg* p_msg) override;

   protected:

      DistributedCoordinatorComponent* m_component_handle;
};

#endif
