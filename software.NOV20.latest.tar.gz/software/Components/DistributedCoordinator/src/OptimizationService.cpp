#include "OptimizationService.h"
#include "DistributedCoordinatorComponent.h"

OptimizationService::OptimizationService(DistributedCoordinatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
