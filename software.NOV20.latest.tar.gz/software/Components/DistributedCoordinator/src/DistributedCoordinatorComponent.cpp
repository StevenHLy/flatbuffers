#include "DistributedCoordinatorComponent.h"
#include "ConfigParameters.h"
#include "InternalMsgIdType.h"
#include "LogService.h"
#include "SensorSchedulingRequestStatusMsg.h"
#include "SensorSchedulingRequestStatusMsgHandler.h"
#include "Service.h"
#include "TimerService.h"

DistributedCoordinatorComponent::DistributedCoordinatorComponent(unsigned int p_component_id)
: DscApplicationComponent(DistributedCoordinatorComponent::COMPONENT_NAME,
                          p_component_id)
, m_cyber_monitor(this)
, m_event_planner(this)
, m_environment_manager(this)
, m_mission_status_monitor(this)
, m_optimization_service(this)
, m_request_generator(this)
, m_resource_manager(this)
, m_sensor_manager(this)
{
}

CyberMonitor* DistributedCoordinatorComponent::cyberMonitor()
{
   return &m_cyber_monitor;
}

EventPlanner* DistributedCoordinatorComponent::eventPlanner()
{
   return &m_event_planner;
}

EnvironmentManager* DistributedCoordinatorComponent::environmentManager()
{
   return &m_environment_manager;
}

void DistributedCoordinatorComponent::initializeComponent()
{
   Service<LogService>::getInstance().registerRequester(componentName(),
                                                        componentId());

   registerInternalMsgHandler<SensorSchedulingRequestStatusMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_SENSOR_SCHEDULING_REQUEST_STATUS,
                                                                       this);

   unsigned int timer_id = Service<TimerService>::getInstance().registerOneShotTimer(componentId(),
                                                                                     TimerService::MethodCallbackType([this](unsigned int p_timer_id)
                                                                                     {
                                                                                        startScriptedDemo();
                                                                                     }));

   eventPlanner()->initialize();

   double scenario_delay = ConfigParameters::getInstance().getRequiredParam<double>("Blding142Demo.Scenarios.Scenario_1.Start_Time_Delay_Secs");

   Service<TimerService>::getInstance().enable(componentId(),
                                               timer_id,
                                               scenario_delay);
}

MissionStatusMonitor* DistributedCoordinatorComponent::missionStatusMonitor()
{
   return &m_mission_status_monitor;
}

OptimizationService* DistributedCoordinatorComponent::optimizationService()
{
   return &m_optimization_service;
}

RequestGenerator* DistributedCoordinatorComponent::requestGenerator()
{
   return &m_request_generator;
}

ResourceManager* DistributedCoordinatorComponent::resourceManager()
{
   return &m_resource_manager;
}

SensorManager* DistributedCoordinatorComponent::sensorManager()
{
   return &m_sensor_manager;
}

void DistributedCoordinatorComponent::shutdownComponent()
{
   eventPlanner()->disableScriptedRequestGeneration();
}

void DistributedCoordinatorComponent::startScriptedDemo()
{
   Service<LogService>::getInstance().log(componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "*** Starting scripted demo ***");

   eventPlanner()->enableScriptedRequestGeneration();
}
