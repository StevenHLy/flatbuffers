#include "SensorSchedulingRequestStatusMsgHandler.h"
#include "DistributedCoordinatorComponent.h"
#include "LogService.h"
#include "Service.h"

SensorSchedulingRequestStatusMsgHandler::SensorSchedulingRequestStatusMsgHandler(DistributedCoordinatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void SensorSchedulingRequestStatusMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "SensorSchedulingRequestStatusMsgHandler::processInternalMsg() called");


                                          
}
