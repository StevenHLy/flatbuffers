#include "RequestGenerator.h"
#include "DistributedCoordinatorComponent.h"

RequestGenerator::RequestGenerator(DistributedCoordinatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
