#include "MissionStatusMonitor.h"
#include "DistributedCoordinatorComponent.h"

MissionStatusMonitor::MissionStatusMonitor(DistributedCoordinatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
