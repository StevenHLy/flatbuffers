#include "CyberMonitor.h"
#include "DistributedCoordinatorComponent.h"

CyberMonitor::CyberMonitor(DistributedCoordinatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
