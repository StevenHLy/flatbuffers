#include "EnvironmentManager.h"
#include "DistributedCoordinatorComponent.h"

EnvironmentManager::EnvironmentManager(DistributedCoordinatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
