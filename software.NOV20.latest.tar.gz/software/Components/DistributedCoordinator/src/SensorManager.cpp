#include "SensorManager.h"
#include "DistributedCoordinatorComponent.h"

SensorManager::SensorManager(DistributedCoordinatorComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}
