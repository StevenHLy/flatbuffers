#include "EventPlanner.h"
#include "DistributedCoordinatorComponent.h"
#include "MsgService.h"
#include "NodeService.h"
#include "SensorSchedulingRequestMsg.h"
#include "Service.h"
#include "TimerService.h"
#include "TimeService.h"
#include "ConfigParameters.h"
#include "ScriptProcessingData.h"

EventPlanner::EventPlanner(DistributedCoordinatorComponent* p_component_handle)
: m_request_generation_timer_id(0)
, m_script_action_timer_id(0)
, waveform_repo()
, step_repo()
, m_component_handle(p_component_handle)
{
}

void EventPlanner::disableScriptedRequestGeneration()
{
   Service<TimerService>::getInstance().disable(m_component_handle->componentId(),
                                                m_request_generation_timer_id);
}

void EventPlanner::enableScriptedRequestGeneration()
{
   Service<TimerService>::getInstance().enable(m_component_handle->componentId(),
                                               m_request_generation_timer_id);
}

void EventPlanner::generateScriptedRequest()
{
   SensorSchedulingRequestMsg sensor_scheduling_request_msg;

   Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                              Service<NodeService>::getInstance().componentNameToComponentId("PlatformServices"),
                                              &sensor_scheduling_request_msg);
}

void EventPlanner::initialize()
{
   m_request_generation_timer_id = Service<TimerService>::getInstance().registerPeriodicTimer(m_component_handle->componentId(),
                                                                                              1.0,
                                                                                              TimerService::MethodCallbackType([this](unsigned int p_timer_id)
                                                                                              {
                                                                                                 generateScriptedRequest();
                                                                                              }));

   startScriptedDemo(15.0);
}

void EventPlanner::startScriptedDemo(double p_delay)
{
   loadWaveforms();
   loadScenario();

   m_script_action_timer_id = Service<TimerService>::getInstance().registerOneShotTimer(m_component_handle->componentId(),
                                                                                        TimerService::MethodCallbackType([this](unsigned int p_timer_id)
                                                                                        {
                                                                                           scheduleScriptSteps();
                                                                                        }));

   Service<TimerService>::getInstance().enable(m_component_handle->componentId(),
                                               m_script_action_timer_id,
                                               p_delay);
}

void EventPlanner::loadScenario()
{
   double start_time_delay = 0.0;

   std::string dot = ".";
   std::string parent_scenario = "Blding142Demo.Scenarios";
  
   ConfigParameters::iterator iter_0;

   for (iter_0 = ConfigParameters::getInstance().getPropertyTree().get_child(parent_scenario).begin();
        iter_0 != ConfigParameters::getInstance().getPropertyTree().get_child(parent_scenario).end();
        ++iter_0)
   {
      std::string scn_idx_node = iter_0->first;

      if (scn_idx_node.rfind("Scenario_", 0) == 0)
      {
         ConfigParameters::iterator iter_1;

         for (iter_1 = ConfigParameters::getInstance().getPropertyTree().get_child(parent_scenario + dot + scn_idx_node).begin();
             iter_1 != ConfigParameters::getInstance().getPropertyTree().get_child(parent_scenario + dot + scn_idx_node).end();
             ++iter_1)
         {
            std::string scn_prop = iter_1->first;

            if ("Start_Time_Delay_Secs" == scn_prop)
            {
               start_time_delay = ConfigParameters::getInstance().getRequiredParam<double>(parent_scenario + dot + scn_idx_node + dot + "Start_Time_Delay_Secs");
            }

            if (scn_prop.rfind("Step_", 0) == 0)
            {
               // Found a Step
               std::string step_ = parent_scenario + dot + scn_idx_node + dot + scn_prop;

               loadStep(step_, start_time_delay);
            }
         }

         std::sort(step_repo.begin(), step_repo.end()); // sort by execution time
      }
   }
}

void EventPlanner::loadStep(const std::string &step_path, double p_time_delay)
{
   std::string dot = ".";
   std::string time_prop = step_path + dot + "Time_Offset_Secs";
  
   double time_offset = ConfigParameters::getInstance().getRequiredParam<double>(time_prop);

   ConfigParameters::iterator i_0;
 
   for (i_0 = ConfigParameters::getInstance().getPropertyTree().get_child(step_path).begin();
        i_0 != ConfigParameters::getInstance().getPropertyTree().get_child(step_path).end();
        ++i_0)
   {   
      if ("SlewCommand" == i_0->first)
      {
         ScriptProcessingData script_cmd;
         script_cmd.m_body.setCommandType(i_0->first);

         std::string xmit_cmd_path = step_path + dot + i_0->first;

         int slew_cmd_count = 0;
         ConfigParameters::iterator i_1;

         for (i_1 = ConfigParameters::getInstance().getPropertyTree().get_child(xmit_cmd_path).begin();
              i_1 != ConfigParameters::getInstance().getPropertyTree().get_child(xmit_cmd_path).end();
              ++i_1)
         {
            std::string dish_name = i_1->first;
            std::string dish_path = xmit_cmd_path + dot + dish_name;

            script_cmd.m_body.Slew_Commands[slew_cmd_count].setDish(dish_name);

            double azimuth_prop   = ConfigParameters::getInstance().getRequiredParam<double>(dish_path + dot + "Azimuth_Degrees");
            double elevation_prop = ConfigParameters::getInstance().getRequiredParam<double>(dish_path + dot + "Elevation_Degrees");

            script_cmd.m_body.Slew_Commands[slew_cmd_count].Azimuth_Degrees   = azimuth_prop;
            script_cmd.m_body.Slew_Commands[slew_cmd_count].Elevation_Degrees = elevation_prop;

            ++slew_cmd_count;
         }

         script_cmd.m_body.Number_Of_Commands = slew_cmd_count;
         script_cmd.m_body.Execution_Time     = time_offset + p_time_delay;

         step_repo.push_back(script_cmd); 
      }
      
      if ("TransmitCommand" == i_0->first)
      {
         ScriptProcessingData script_cmd;
         script_cmd.m_body.setCommandType(i_0->first);

         std::string xmit_cmd_path = step_path + dot + i_0->first;

         int xmit_cmd_count = 0;
         ConfigParameters::iterator i_2;

         for (i_2 = ConfigParameters::getInstance().getPropertyTree().get_child(xmit_cmd_path).begin();
              i_2 != ConfigParameters::getInstance().getPropertyTree().get_child(xmit_cmd_path).end();
              ++i_2)
         {
            std::string dish_name = i_2->first;
            std::string dish_path = xmit_cmd_path + dot + dish_name;

            script_cmd.m_body.Transmit_Commands[xmit_cmd_count].setDish(dish_name);

            std::string waveform_prop    = ConfigParameters::getInstance().getRequiredParam<std::string>(dish_path + dot + "Waveform");
            double num_pulses_prop       = ConfigParameters::getInstance().getRequiredParam<double>(     dish_path + dot + "Num_Pulses");
            double repetition_count_prop = ConfigParameters::getInstance().getRequiredParam<double>(     dish_path + dot + "Repetition_Count");

            script_cmd.m_body.Transmit_Commands[xmit_cmd_count].Num_Pulses         = num_pulses_prop;
            script_cmd.m_body.Transmit_Commands[xmit_cmd_count].Repetition_Count   = repetition_count_prop;

            if (waveform_repo.count(waveform_prop) != 0)
            {
               script_cmd.m_body.Transmit_Commands[xmit_cmd_count].waveform.Pulsewidth_usec   = waveform_repo[waveform_prop].Pulsewidth_usec;
               script_cmd.m_body.Transmit_Commands[xmit_cmd_count].waveform.Amplitude         = waveform_repo[waveform_prop].Amplitude;
               script_cmd.m_body.Transmit_Commands[xmit_cmd_count].waveform.Bandwidth_MHz     = waveform_repo[waveform_prop].Bandwidth_MHz;
               script_cmd.m_body.Transmit_Commands[xmit_cmd_count].waveform.Phase_Offsec_psec = waveform_repo[waveform_prop].Phase_Offsec_psec;
               script_cmd.m_body.Transmit_Commands[xmit_cmd_count].waveform.Offset_MHz        = waveform_repo[waveform_prop].Offset_MHz;
               script_cmd.m_body.Transmit_Commands[xmit_cmd_count].waveform.Samples_Per_Chip  = waveform_repo[waveform_prop].Samples_Per_Chip;
               script_cmd.m_body.Transmit_Commands[xmit_cmd_count].waveform.Gold_Code_Index   = waveform_repo[waveform_prop].Gold_Code_Index;
            }
            else
            {
                // print error message
            }

            ++xmit_cmd_count;
         }

         script_cmd.m_body.Number_Of_Commands = xmit_cmd_count;
         script_cmd.m_body.Execution_Time     = time_offset + p_time_delay;

         step_repo.push_back(script_cmd);
      }
   }
}

void EventPlanner::loadWaveforms()
{
   std::string dot = ".";
   std::string parent_scenario = "Blding142Demo.Waveforms";

   ConfigParameters::iterator iter_0;

   for (iter_0 = ConfigParameters::getInstance().getPropertyTree().get_child(parent_scenario).begin();
        iter_0 != ConfigParameters::getInstance().getPropertyTree().get_child(parent_scenario).end();
        ++iter_0)
   {
      std::string wf_type = iter_0->first;

      if (wf_type.rfind("Waveform_", 0) == 0)
      {
         // Found a Waveform
         std::string wf_path =  parent_scenario + dot + wf_type;

         int pulsewidth_usec_prop   = ConfigParameters::getInstance().getRequiredParam<int>(wf_path + dot + "Pulsewidth_usec");
         int amp_prop               = ConfigParameters::getInstance().getRequiredParam<int>(wf_path + dot + "Amp");
         int bandwidth_mhz_prop     = ConfigParameters::getInstance().getRequiredParam<int>(wf_path + dot + "Bandwidth_MHz");
         int phase_offsec_psec_prop = ConfigParameters::getInstance().getRequiredParam<int>(wf_path + dot + "Phase_Offset_psec");
         int offset_mhz_prop        = ConfigParameters::getInstance().getRequiredParam<int>(wf_path + dot + "Offset_MHz");
         int samples_per_chip_prop  = ConfigParameters::getInstance().getRequiredParam<int>(wf_path + dot + "Samples_Per_Chip");
         int gold_code_index_prop   = ConfigParameters::getInstance().getRequiredParam<int>(wf_path + dot + "Gold_Code_Index");

         ScriptProcessingDataBody::Waveform wf_struct;

         wf_struct.Pulsewidth_usec   = pulsewidth_usec_prop;
         wf_struct.Amplitude         = amp_prop;
         wf_struct.Bandwidth_MHz     = bandwidth_mhz_prop;
         wf_struct.Phase_Offsec_psec = phase_offsec_psec_prop;
         wf_struct.Offset_MHz        = offset_mhz_prop;
         wf_struct.Samples_Per_Chip  = samples_per_chip_prop;
         wf_struct.Gold_Code_Index   = gold_code_index_prop;

         waveform_repo.insert(std::pair<std::string, ScriptProcessingDataBody::Waveform>(wf_type, wf_struct));
      }
   }
}

void EventPlanner::scheduleScriptSteps()
{
   static double previous_time = 0.0;

   if (!step_repo.empty())
   {
      const ScriptProcessingData &step = step_repo[0];

      SensorSchedulingRequestMsg sensor_scheduling_request_msg;

      sensor_scheduling_request_msg.m_body.Command_Type       = step.m_body.Command_Type;
      sensor_scheduling_request_msg.m_body.Number_Of_Commands = step.m_body.Number_Of_Commands;

      if (1 == step.m_body.Command_Type) // slew command
      {
         for (int idx=0; idx<step.m_body.Number_Of_Commands; idx++)
         {
            sensor_scheduling_request_msg.m_body.Slew_Commands[idx].Dish              = step.m_body.Slew_Commands[idx].Dish;
            sensor_scheduling_request_msg.m_body.Slew_Commands[idx].Azimuth_Degrees   = step.m_body.Slew_Commands[idx].Azimuth_Degrees;
            sensor_scheduling_request_msg.m_body.Slew_Commands[idx].Elevation_Degrees = step.m_body.Slew_Commands[idx].Elevation_Degrees;
         }
      }
      else if (2 == step.m_body.Command_Type) // transmit command
      {
         for (int idx=0; idx<step.m_body.Number_Of_Commands; idx++)
         {
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Dish              = step.m_body.Transmit_Commands[idx].Dish;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Pulsewidth_usec   = step.m_body.Transmit_Commands[idx].waveform.Pulsewidth_usec;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Amplitude         = step.m_body.Transmit_Commands[idx].waveform.Amplitude;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Bandwidth_MHz     = step.m_body.Transmit_Commands[idx].waveform.Bandwidth_MHz;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Phase_Offsec_psec = step.m_body.Transmit_Commands[idx].waveform.Phase_Offsec_psec;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Offset_MHz        = step.m_body.Transmit_Commands[idx].waveform.Offset_MHz;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Samples_Per_Chip  = step.m_body.Transmit_Commands[idx].waveform.Samples_Per_Chip;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Gold_Code_Index   = step.m_body.Transmit_Commands[idx].waveform.Gold_Code_Index;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Num_Pulses        = step.m_body.Transmit_Commands[idx].Num_Pulses;
            sensor_scheduling_request_msg.m_body.Transmit_Commands[idx].Repetition_Count  = step.m_body.Transmit_Commands[idx].Repetition_Count;
         }
      }

      Service<MsgService>::getInstance().sendMsg(m_component_handle->componentId(),
                                                 Service<NodeService>::getInstance().componentNameToComponentId("PlatformServices"),
                                                 &sensor_scheduling_request_msg);

      previous_time = step.m_body.Execution_Time;

      step_repo.erase(step_repo.begin());

      if (!step_repo.empty())
      {
         double next_time = step_repo.front().m_body.Execution_Time;
         double delay = next_time - previous_time;

         m_script_action_timer_id = Service<TimerService>::getInstance().registerOneShotTimer(m_component_handle->componentId(),
                                                                                              TimerService::MethodCallbackType([this](unsigned int p_timer_id)
                                                                                              {
                                                                                                 scheduleScriptSteps();
                                                                                              }));

         Service<TimerService>::getInstance().enable(m_component_handle->componentId(),
                                                     m_script_action_timer_id,
                                                     delay);
      }
   }
}
