#ifndef TrackerBoundaryComponent_h
#define TrackerBoundaryComponent_h

#include "DscBoundaryComponent.h"
#include "TrackerInterface.h"
#include "TrackerMsg.h"

class TrackerBoundaryComponent : public DscBoundaryComponent<TrackerMsg>
{
   public:

      static constexpr const char* COMPONENT_NAME = "TrackerBoundary";

      TrackerBoundaryComponent(unsigned int p_component_id);
      ~TrackerBoundaryComponent() = default;

      void initializeComponent() override;
      void processQueuedMsg() override;
      void queueReceivedMsg(TrackerMsg* p_msg) override;
      void shutdownComponent() override;

      TrackerInterface* trackerInterface();

   protected:

      TrackerInterface m_tracker_interface;
};

#endif
