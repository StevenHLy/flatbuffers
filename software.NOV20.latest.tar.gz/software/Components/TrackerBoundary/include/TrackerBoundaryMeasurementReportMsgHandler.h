#ifndef TrackerBoundaryMeasurementReportMsgHandler_h
#define TrackerBoundaryMeasurementReportMsgHandler_h

#include "InternalMsg.h"
#include "InternalMsgHandler.h"

class TrackerBoundaryComponent;

class TrackerBoundaryMeasurementReportMsgHandler : public InternalMsgHandler
{
   public:

      TrackerBoundaryMeasurementReportMsgHandler(TrackerBoundaryComponent* p_component_handle);
      ~TrackerBoundaryMeasurementReportMsgHandler() = default;

      void processInternalMsg(const InternalMsg* p_msg) override;

   protected:

      TrackerBoundaryComponent* m_component_handle;
};

#endif
