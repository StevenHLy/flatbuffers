#ifndef TrackerInterface_h
#define TrackerInterface_h

#include "TrackerMsg.h"

class TrackerBoundaryComponent;

class TrackerInterface
{
   public:

      TrackerInterface(TrackerBoundaryComponent* p_component_handle);
      ~TrackerInterface() = default;

      void initialize();
      void run();
      void sendMsg(TrackerMsg* p_msg);
      void shutdown();

   protected:

      void closeTrackerConnection();
      void establishTrackerConnection();
      void receivePendingTrackerMessages();
      bool trackerConnectionEstablished();

      unsigned int m_polling_id;
      TrackerBoundaryComponent* m_component_handle;
};

#endif
