#include "TrackerBoundaryMeasurementReportMsgHandler.h"
#include "LogService.h"
#include "Service.h"
#include "TrackerBoundaryComponent.h"
#include "TrackerMeasurementReportMsg.h"

TrackerBoundaryMeasurementReportMsgHandler::TrackerBoundaryMeasurementReportMsgHandler(TrackerBoundaryComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void TrackerBoundaryMeasurementReportMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "TrackerBoundaryMeasurementReportMsgHandler::processInternalMsg() called");

   TrackerMeasurementReportMsg tracker_measurement_report_msg;

   m_component_handle->trackerInterface()->sendMsg(&tracker_measurement_report_msg);
}
