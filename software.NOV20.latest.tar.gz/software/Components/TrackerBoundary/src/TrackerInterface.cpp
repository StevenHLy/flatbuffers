#include "TrackerInterface.h"
#include "PollingService.h"
#include "Service.h"
#include "TrackerBoundaryComponent.h"

TrackerInterface::TrackerInterface(TrackerBoundaryComponent* p_component_handle)
: m_polling_id(0)
, m_component_handle(p_component_handle)
{
}

void TrackerInterface::closeTrackerConnection()
{
}

void TrackerInterface::establishTrackerConnection()
{
}

void TrackerInterface::initialize()
{
   m_polling_id = Service<PollingService>::getInstance().registerCallback(PollingService::MethodCallbackType([this]()
                                                                                                             {
                                                                                                                this->run();
                                                                                                             }));

   Service<PollingService>::getInstance().enableCallback(m_polling_id);
}

void TrackerInterface::receivePendingTrackerMessages()
{
}

void TrackerInterface::run()
{
   if (not trackerConnectionEstablished())
   {
      establishTrackerConnection();
   }

   receivePendingTrackerMessages();
   m_component_handle->processQueuedMsg();
}

void TrackerInterface::sendMsg(TrackerMsg* p_msg)
{
}

void TrackerInterface::shutdown()
{
   closeTrackerConnection();
}

bool TrackerInterface::trackerConnectionEstablished()
{
   return false;
}
