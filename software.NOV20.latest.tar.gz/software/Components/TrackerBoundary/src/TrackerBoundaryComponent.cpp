#include "TrackerBoundaryComponent.h"
#include "InternalMsgIdType.h"
#include "TrackerBoundaryMeasurementReportMsgHandler.h"

TrackerBoundaryComponent::TrackerBoundaryComponent(unsigned int p_component_id)
: DscBoundaryComponent(TrackerBoundaryComponent::COMPONENT_NAME,
                       p_component_id)
, m_tracker_interface(this)
{
}

void TrackerBoundaryComponent::initializeComponent()
{
   Service<LogService>::getInstance().registerRequester(componentName(),
                                                        componentId());

   registerInternalMsgHandler<TrackerBoundaryMeasurementReportMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_TRACKER_BOUNDARY_MEASUREMENT_REPORT,
                                                                          this);

   trackerInterface()->initialize();
}

void TrackerBoundaryComponent::processQueuedMsg()
{
}

void TrackerBoundaryComponent::queueReceivedMsg(TrackerMsg* p_msg)
{
}

void TrackerBoundaryComponent::shutdownComponent()
{
   trackerInterface()->shutdown();
}

TrackerInterface* TrackerBoundaryComponent::trackerInterface()
{
   return &m_tracker_interface;
}
