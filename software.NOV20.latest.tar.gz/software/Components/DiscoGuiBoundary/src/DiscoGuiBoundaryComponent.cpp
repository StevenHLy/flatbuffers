#include "DiscoGuiBoundaryComponent.h"
#include "DiscoGuiBoundaryMeasurementReportMsgHandler.h"
#include "InternalMsgIdType.h"

DiscoGuiBoundaryComponent::DiscoGuiBoundaryComponent(unsigned int p_component_id)
: DscBoundaryComponent(DiscoGuiBoundaryComponent::COMPONENT_NAME,
                       p_component_id)
, m_disco_gui_interface(this)
{
}

DiscoGuiInterface* DiscoGuiBoundaryComponent::discoGuiInterface()
{
   return &m_disco_gui_interface;
}

void DiscoGuiBoundaryComponent::initializeComponent()
{
   Service<LogService>::getInstance().registerRequester(componentName(),
                                                        componentId());

   registerInternalMsgHandler<DiscoGuiBoundaryMeasurementReportMsgHandler>(InternalMsgIdType::InternalMsgIdTypeEnum::MT_DISCO_GUI_BOUNDARY_MEASUREMENT_REPORT,
                                                                           this);

   discoGuiInterface()->initialize();
}

void DiscoGuiBoundaryComponent::processQueuedMsg()
{
}

void DiscoGuiBoundaryComponent::queueReceivedMsg(DiscoGuiMsg* p_msg)
{
}

void DiscoGuiBoundaryComponent::shutdownComponent()
{
   discoGuiInterface()->shutdown();
}
