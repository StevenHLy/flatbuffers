#include "DiscoGuiInterface.h"
#include "ConfigParameters.h"
#include "DiscoGuiBoundaryComponent.h"
#include "LogService.h"
#include "LogSeverityType.h"
#include "PollingService.h"
#include "Service.h"
#include "TimeService.h"
#include <cstring>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <string>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

DiscoGuiInterface::DiscoGuiInterface(DiscoGuiBoundaryComponent* p_component_handle)
: CONNECTION_ATTEMPT_INTERVAL(ConfigParameters::getInstance().getRequiredParam<double>("DiscoGuiBoundary.NetworkConnection.Connection_Attempt_Interval_Secs"))
, SERVER_PORT_NUMBER(ConfigParameters::getInstance().getRequiredParam<unsigned int>("DiscoGuiBoundary.NetworkConnection.Port_Number"))
, m_disco_gui_connection_established(false)
, m_time_of_last_client_connection_attempt(0.0)
, m_disco_gui_socket(-1)
, m_server_socket(-1)
, m_polling_id(0)
, m_component_handle(p_component_handle)
{
}

void DiscoGuiInterface::closeDiscoGuiConnection()
{
   close(m_disco_gui_socket);
   close(m_server_socket);
}

bool DiscoGuiInterface::discoGuiConnectionEstablished()
{
   return m_disco_gui_connection_established;
}

void DiscoGuiInterface::establishDiscoGuiConnection()
{
   double current_time = Service<TimeService>::getInstance().currentTimeSecs();
   double connection_attempt_delta_time = current_time - m_time_of_last_client_connection_attempt;

   if (connection_attempt_delta_time >= CONNECTION_ATTEMPT_INTERVAL)
   {
      m_time_of_last_client_connection_attempt = current_time;

      Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::INFO,
                                             "Attempting to establish DiSCo GUI client connection");

      if ((m_disco_gui_socket = accept(m_server_socket, nullptr, nullptr)) != -1)
      {
         Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::INFO,
                                                "Established DiSCo GUI client connection");

         int socket_flags = fcntl(m_disco_gui_socket, F_GETFL);
         socket_flags |= O_NONBLOCK;
         fcntl(m_disco_gui_socket, F_SETFL, socket_flags);

         int optval = 1;
         setsockopt(m_disco_gui_socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &optval, sizeof(optval));
         
         m_disco_gui_connection_established = true;
      }
      else
      {
         Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::INFO,
                                                "accept call error (%s)",
                                                std::string(strerror(errno)).c_str());
      }
   }
}

void DiscoGuiInterface::initialize()
{
   m_server_socket = socket(AF_INET, SOCK_STREAM, 0);

   int socket_flags = fcntl(m_server_socket, F_GETFL);
   socket_flags |= O_NONBLOCK;
   fcntl(m_server_socket, F_SETFL, socket_flags);

   int optval = 1;
   setsockopt(m_server_socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &optval, sizeof(optval));

   sockaddr_in server_address;
   server_address.sin_family = AF_INET;
   server_address.sin_port = htons(SERVER_PORT_NUMBER);
   server_address.sin_addr.s_addr = INADDR_ANY;

   bind(m_server_socket, (struct sockaddr*)&server_address, sizeof(server_address));
   listen(m_server_socket, 1);

   m_polling_id = Service<PollingService>::getInstance().registerCallback(PollingService::MethodCallbackType([this]()
                                                                                                             {
                                                                                                                this->run();
                                                                                                             }));

   Service<PollingService>::getInstance().enableCallback(m_polling_id);
}

void DiscoGuiInterface::receivePendingDiscoGuiMessages()
{
   if (discoGuiConnectionEstablished())
   {
      char buf[256];
      unsigned int bytes = 0;

      if (recv(m_disco_gui_socket, buf, 256, 0) == 0)
      {
         Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::INFO,
                                                "DiSCo GUI client disconnected");

         m_disco_gui_connection_established = false;
      }
   }
}

void DiscoGuiInterface::run()
{
   if (not discoGuiConnectionEstablished())
   {
      establishDiscoGuiConnection();
   }

   receivePendingDiscoGuiMessages();
   m_component_handle->processQueuedMsg();
}

void DiscoGuiInterface::sendMsg(DiscoGuiMsg* p_msg)
{
}

void DiscoGuiInterface::shutdown()
{
   closeDiscoGuiConnection();
}
