#include "DiscoGuiBoundaryMeasurementReportMsgHandler.h"
#include "DiscoGuiBoundaryComponent.h"
#include "DiscoGuiMeasurementReportMsg.h"
#include "LogService.h"
#include "Service.h"

DiscoGuiBoundaryMeasurementReportMsgHandler::DiscoGuiBoundaryMeasurementReportMsgHandler(DiscoGuiBoundaryComponent* p_component_handle)
: m_component_handle(p_component_handle)
{
}

void DiscoGuiBoundaryMeasurementReportMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
   Service<LogService>::getInstance().log(m_component_handle->componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::DEBUG,
                                          "DiscoGuiBoundaryMeasurementReportMsgHandler::processInternalMsg() called");

   DiscoGuiMeasurementReportMsg disco_gui_measurement_report_msg;

   m_component_handle->discoGuiInterface()->sendMsg(&disco_gui_measurement_report_msg);
}
