#ifndef DiscoGuiInterface_h
#define DiscoGuiInterface_h

#include "DiscoGuiMsg.h"

class DiscoGuiBoundaryComponent;

class DiscoGuiInterface
{
   public:

      DiscoGuiInterface(DiscoGuiBoundaryComponent* p_component_handle);
      ~DiscoGuiInterface() = default;

      void initialize();
      void run();
      void sendMsg(DiscoGuiMsg* p_msg);
      void shutdown();

   protected:

      const double CONNECTION_ATTEMPT_INTERVAL;
      const unsigned int SERVER_PORT_NUMBER;
      
      void closeDiscoGuiConnection();
      bool discoGuiConnectionEstablished();
      void establishDiscoGuiConnection();
      void receivePendingDiscoGuiMessages();

      bool m_disco_gui_connection_established;
      double m_time_of_last_client_connection_attempt;
      int m_disco_gui_socket;
      int m_server_socket;
      unsigned int m_polling_id;
      DiscoGuiBoundaryComponent* m_component_handle;
};

#endif
