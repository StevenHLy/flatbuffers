#ifndef DiscoGuiBoundaryMeasurementReportMsgHandler_h
#define DiscoGuiBoundaryMeasurementReportMsgHandler_h

#include "InternalMsg.h"
#include "InternalMsgHandler.h"

class DiscoGuiBoundaryComponent;

class DiscoGuiBoundaryMeasurementReportMsgHandler : public InternalMsgHandler
{
   public:

      DiscoGuiBoundaryMeasurementReportMsgHandler(DiscoGuiBoundaryComponent* p_component_handle);
      ~DiscoGuiBoundaryMeasurementReportMsgHandler() = default;

      void processInternalMsg(const InternalMsg* p_msg) override;

   protected:

      DiscoGuiBoundaryComponent* m_component_handle;
};

#endif
