#ifndef DiscoGuiBoundaryComponent_h
#define DiscoGuiBoundaryComponent_h

#include "DiscoGuiInterface.h"
#include "DiscoGuiMsg.h"
#include "DscBoundaryComponent.h"

class DiscoGuiBoundaryComponent : public DscBoundaryComponent<DiscoGuiMsg>
{
   public:

      static constexpr const char* COMPONENT_NAME = "DiscoGuiBoundary";

      DiscoGuiBoundaryComponent(unsigned int p_component_id);
      ~DiscoGuiBoundaryComponent() = default;

      void initializeComponent() override;
      void processQueuedMsg() override;
      void queueReceivedMsg(DiscoGuiMsg* p_msg) override;
      void shutdownComponent() override;

      DiscoGuiInterface* discoGuiInterface();

   protected:

      DiscoGuiInterface m_disco_gui_interface;
};

#endif
