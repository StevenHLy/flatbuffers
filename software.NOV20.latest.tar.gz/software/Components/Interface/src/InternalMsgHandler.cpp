#include "InternalMsgHandler.h"

void InternalMsgHandler::processInternalMsg(const InternalMsg* p_msg)
{
}
