#include "DscApplicationComponent.h"
#include "LogService.h"
#include "Service.h"

DscApplicationComponent::DscApplicationComponent(std::string p_component_name,
                                                 unsigned int p_component_id)
: COMPONENT_NAME(p_component_name)
, COMPONENT_ID(p_component_id)
{
   Service<LogService>::getInstance().log(componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "creating %s component",
                                          componentName().c_str());
}

void DscApplicationComponent::initializeComponent()
{
}

unsigned int DscApplicationComponent::componentId()
{
   return COMPONENT_ID;
}

std::string DscApplicationComponent::componentName()
{
   return COMPONENT_NAME;
}

void DscApplicationComponent::shutdownComponent()
{
}
