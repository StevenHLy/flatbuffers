#ifndef DscPlatformBoundaryComponent_h
#define DscPlatformBoundaryComponent_h

#include "DscBoundaryComponent.h"

template<typename BaseMsgType>
class DscPlatformBoundaryComponent : public DscBoundaryComponent<BaseMsgType>
{
   public:

      DscPlatformBoundaryComponent(std::string p_component_name,
                                   unsigned int p_component_id);
      virtual ~DscPlatformBoundaryComponent() = default;

      virtual void processQueuedMsg() = 0;
      virtual void queueReceivedMsg(BaseMsgType* p_msg) = 0;
};

template<typename BaseMsgType>
DscPlatformBoundaryComponent<BaseMsgType>::DscPlatformBoundaryComponent(std::string p_component_name,
                                                                        unsigned int p_component_id)
: DscBoundaryComponent<BaseMsgType>(p_component_name,
                                    p_component_id)
{
}

#endif
