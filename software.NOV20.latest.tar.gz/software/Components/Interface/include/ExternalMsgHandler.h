#ifndef ExternalMsgHandler_h
#define ExternalMsgHandler_h

template<typename BaseMsgType>
class ExternalMsgHandler
{
   public:

      ExternalMsgHandler() = default;
      virtual ~ExternalMsgHandler() = default;

      virtual void processExternalMsg(const BaseMsgType* p_msg) = 0;
};

#endif
