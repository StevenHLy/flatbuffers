#ifndef InternalMsgHandler_h
#define InternalMsgHandler_h

#include "InternalMsg.h"

class InternalMsgHandler
{
   public:

      InternalMsgHandler() = default;
      virtual ~InternalMsgHandler() = default;

      virtual void processInternalMsg(const InternalMsg* p_msg);
};

#endif
