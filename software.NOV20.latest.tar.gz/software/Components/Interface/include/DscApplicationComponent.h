#ifndef DscApplicationComponent_h
#define DscApplicationComponent_h

#include "InternalMsgIdType.h"
#include "MsgService.h"
#include "Service.h"

class DscApplicationComponent
{
   public:

      DscApplicationComponent(std::string p_component_name,
                              unsigned int p_component_id);
      virtual ~DscApplicationComponent() = default;

      virtual void initializeComponent();
      virtual void shutdownComponent();

      unsigned int componentId();
      std::string componentName();

   protected:

      const std::string COMPONENT_NAME;
      const unsigned int COMPONENT_ID;

      template<typename MsgHandlerBaseType, typename... Args> void registerInternalMsgHandler(InternalMsgIdType::InternalMsgIdTypeEnum p_msg_id,
                                                                                              Args&&... p_args);
};

template<typename MsgHandlerBaseType, typename... Args>
void DscApplicationComponent::registerInternalMsgHandler(InternalMsgIdType::InternalMsgIdTypeEnum p_msg_id,
                                                         Args&&... p_args)
{
   MsgHandlerBaseType* handler = new MsgHandlerBaseType(std::forward<Args>(p_args)...);

   Service<MsgService>::getInstance().subscribe(p_msg_id,
                                                componentId(),
                                                std::bind(&MsgHandlerBaseType::processInternalMsg, handler, std::placeholders::_1));
}

#endif
