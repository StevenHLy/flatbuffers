#ifndef DscBoundaryComponent_h
#define DscBoundaryComponent_h

#include "DscApplicationComponent.h"
#include "GenericBuffer.h"
#include "LogService.h"
#include "NodeService.h"
#include "Service.h"
#include <functional>
#include <list>
#include <map>

template<typename BaseMsgType>
class DscBoundaryComponent : public DscApplicationComponent
{
   public:

      typedef std::function<void(const BaseMsgType*)> MethodCallbackType;
      typedef std::map<unsigned int, MethodCallbackType> SubscribersType;

      DscBoundaryComponent(std::string p_component_name,
                           unsigned int p_component_id);
      virtual ~DscBoundaryComponent() = default;


      virtual void processQueuedMsg() = 0;
      virtual void queueReceivedMsg(BaseMsgType* p_msg) = 0;

      virtual std::list<GenericBuffer<unsigned char>*>& externalMsgQueue();
      virtual SubscribersType& externalMsgSubscribers();

   protected:

      template<typename MsgHandlerBaseType, typename... Args> void registerExternalMsgHandler(unsigned int p_msg_id,
                                                                                              Args&&... p_args);
      void subscribe(unsigned int p_msg_id,
                     MethodCallbackType p_callback_method);

      std::list<GenericBuffer<unsigned char>*> m_msg_queue;
      SubscribersType m_subscribers;
};

template<typename BaseMsgType>
DscBoundaryComponent<BaseMsgType>::DscBoundaryComponent(std::string p_component_name,
                                                        unsigned int p_component_id)
: DscApplicationComponent(p_component_name,
                          p_component_id)
{
}

template<typename BaseMsgType>
std::list<GenericBuffer<unsigned char>*>& DscBoundaryComponent<BaseMsgType>::externalMsgQueue()
{
   return m_msg_queue;
}

template<typename BaseMsgType>
typename DscBoundaryComponent<BaseMsgType>::SubscribersType& DscBoundaryComponent<BaseMsgType>::externalMsgSubscribers()
{
   return m_subscribers;
}

template<typename BaseMsgType>
template<typename MsgHandlerBaseType, typename... Args>
void DscBoundaryComponent<BaseMsgType>::registerExternalMsgHandler(unsigned int p_msg_id,
                                                                   Args&&... p_args)
{
   MsgHandlerBaseType* handler = new MsgHandlerBaseType(std::forward<Args>(p_args)...);

   subscribe(p_msg_id,
             std::bind(&MsgHandlerBaseType::processExternalMsg, handler, std::placeholders::_1));
}

template<typename BaseMsgType>
void DscBoundaryComponent<BaseMsgType>::subscribe(unsigned int p_msg_id,
                                                  MethodCallbackType p_callback_method)
{
   m_subscribers[p_msg_id] = p_callback_method;

   Service<LogService>::getInstance().log(componentId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "Registered external msg handler for component id %d and msg id %d",
                                          componentId(),
                                          p_msg_id);
}

#endif
