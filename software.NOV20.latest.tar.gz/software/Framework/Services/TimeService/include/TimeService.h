#ifndef TimeService_h
#define TimeService_h

class TimeService
{
   public:

      static constexpr const char* SERVICE_NAME = "TimeService";

      TimeService() = default;
      virtual ~TimeService() = default;

      virtual double currentTimeMicroSecs() = 0;
      virtual double currentTimeNanoSecs() = 0;
      virtual double currentTimeSecs() = 0;
      virtual double currentTimeDays() = 0;
      virtual double currentTimeHours() = 0;
      virtual double currentTimeMinutes() = 0;
};

#endif
