#ifndef TimeServiceImpl_h
#define TimeServiceImpl_h

#include "ServiceImpl.h"
#include "TimeService.h"

class TimeServiceImpl : public ServiceImpl<TimeService>
{
   public:

      TimeServiceImpl(unsigned int p_service_id);
      ~TimeServiceImpl() = default;

      double currentTimeMicroSecs();
      double currentTimeNanoSecs();
      double currentTimeSecs();
      double currentTimeDays();
      double currentTimeHours();
      double currentTimeMinutes();
};

#endif
