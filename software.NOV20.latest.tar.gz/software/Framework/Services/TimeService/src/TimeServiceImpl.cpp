#include "TimeServiceImpl.h"
#include "DscConstants.h"
#include <chrono>

 TimeServiceImpl::TimeServiceImpl(unsigned int p_service_id)
: ServiceImpl<TimeService>(TimeService::SERVICE_NAME,
                           p_service_id)
{
}

 double TimeServiceImpl::currentTimeMicroSecs()
 {
    return (std::chrono::system_clock::now().time_since_epoch().count() * Constants::TO_SECS_FROM_MSECS);
 }

 double TimeServiceImpl::currentTimeNanoSecs()
 {
    return (std::chrono::system_clock::now().time_since_epoch().count());
 }

 double TimeServiceImpl::currentTimeSecs()
 {
    return (std::chrono::system_clock::now().time_since_epoch().count() * Constants::TO_SECS_FROM_NSECS);
 }

 double TimeServiceImpl::currentTimeDays()
 {
    return (currentTimeSecs() * Constants::TO_DAYS_FROM_SECS);
 }

 double TimeServiceImpl::currentTimeHours()
 {
    return (currentTimeSecs() * Constants::TO_HOURS_FROM_SECS);
 }

 double TimeServiceImpl::currentTimeMinutes()
 {
    return (currentTimeSecs() * Constants::TO_MINUTES_FROM_SECS);
 }
