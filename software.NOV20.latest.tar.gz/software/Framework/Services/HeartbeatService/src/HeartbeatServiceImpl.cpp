#include "HeartbeatServiceImpl.h"
#include "ConfigParameters.h"
#include "DscException.h"
#include "LogService.h"
#include "NodeService.h"
#include "PollingService.h"
#include "ProtocolFamilyType.h"
#include "Service.h"
#include "TimeService.h"
#include <exception>
#include <string>
#include <string.h>

HeartbeatServiceImpl::HeartbeatServiceImpl(unsigned int p_service_id)
: ServiceImpl<HeartbeatService>(HeartbeatService::SERVICE_NAME,
                                p_service_id)
, SERVICE_ENABLED(ConfigParameters::getInstance().getRequiredParam<bool>("HeartbeatService.Enabled"))
, CONNECTION_ATTEMPT_INTERVAL(ConfigParameters::getInstance().getRequiredParam<double>("HeartbeatService.NetworkConnection.Connection_Attempt_Interval_Secs"))
, HEARTBEAT_INTERVAL(ConfigParameters::getInstance().getRequiredParam<double>("HeartbeatService.Heartbeat_Interval"))
, TIME_TO_LIVE(ConfigParameters::getInstance().getRequiredParam<int>("HeartbeatService.NetworkConnection.Multicast_Time_To_Live"))
, m_last_heartbeat_time(0.0)
, m_time_of_last_connection_attempt(0.0)
, m_polling_id(0)
, m_heartbeat_socket()
, m_framework_heartbeat_msg()
, m_incoming_msg_buffer(ConfigParameters::getInstance().getRequiredParam<int>("HeartbeatService.NetworkConnection.Incoming_Msg_Buffer_Size_Bytes"))
{
}

void HeartbeatServiceImpl::closeNetworkConnection()
{
   if (networkConnectionEstablished())
   {
      m_heartbeat_socket->setSocketOptDropMembership();
      m_heartbeat_socket->closeSocket();
   }
}

void HeartbeatServiceImpl::disable()
{
   if (serviceEnabled())
   {
      closeNetworkConnection();
   }
}

void HeartbeatServiceImpl::enable()
{
   if (serviceEnabled())
   {
      std::string local_node_name = Service<NodeService>::getInstance().localNodeName();

      strncpy(m_framework_heartbeat_msg.m_body.m_sending_node_name,
              local_node_name.c_str(),
              local_node_name.size());

      std::string ip_address = ConfigParameters::getInstance().getRequiredParam<std::string>("HeartbeatService.NetworkConnection.IP_Address");
      int port_number =  ConfigParameters::getInstance().getRequiredParam<int>("HeartbeatService.NetworkConnection.Port_Number");

      m_heartbeat_socket.reset(new MulticastSocketImpl(ip_address,
                                                       port_number));

      m_polling_id = Service<PollingService>::getInstance().registerCallback(PollingService::MethodCallbackType([this]()
                                                                                                                {
                                                                                                                   this->run();
                                                                                                                }));

      Service<PollingService>::getInstance().enableCallback(m_polling_id);
      m_last_heartbeat_time = Service<TimeService>::getInstance().currentTimeSecs();
   }
}

void HeartbeatServiceImpl::establishNetworkConnection()
{
   double current_time = Service<TimeService>::getInstance().currentTimeSecs();
   double connection_attempt_delta_time = current_time - m_time_of_last_connection_attempt;

   if (connection_attempt_delta_time >= CONNECTION_ATTEMPT_INTERVAL)
   {
      m_time_of_last_connection_attempt = current_time;

      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::INFO,
                                             "Heartbeat service attempting to join multicast group using %s:%d",
                                             m_heartbeat_socket->ipAddress().c_str(),
                                             m_heartbeat_socket->port());

      try
      {
         m_heartbeat_socket->createSocket();
         m_heartbeat_socket->setNonBlocking(true);
         m_heartbeat_socket->setSocketOptReuseAddr(true);
         m_heartbeat_socket->setSocketOptMulticastTtl(TIME_TO_LIVE);
         m_heartbeat_socket->setSocketOptMulticastLoop(false);
         m_heartbeat_socket->bindLocalPort();
         m_heartbeat_socket->setSocketOptAddMembership();
      }
      catch(DscException const& e_dsc)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::ERROR,
                                                "Heartbeat service DscException(%s) using %s:%d",
                                                e_dsc.what(),
                                                m_heartbeat_socket->ipAddress().c_str(),
                                                m_heartbeat_socket->port());

         m_heartbeat_socket->closeSocket();
      }
      catch(std::exception const& e_std)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::ERROR,
                                                "Heartbeat service std::exception(%s) using %s:%d",
                                                e_std.what(),
                                                m_heartbeat_socket->ipAddress().c_str(),
                                                m_heartbeat_socket->port());

         m_heartbeat_socket->closeSocket();
      }

      if (m_heartbeat_socket->isSocketConnected())
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::INFO,
                                                "Heartbeat service joined multicast group using %s:%d",
                                                m_heartbeat_socket->ipAddress().c_str(),
                                                m_heartbeat_socket->port());
      }
      else
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::WARNING,
                                                "Heartbeat service unable to join multicast group using %s:%d",
                                                m_heartbeat_socket->ipAddress().c_str(),
                                                m_heartbeat_socket->port());
      }
   }
}

bool HeartbeatServiceImpl::networkConnectionEstablished()
{
   return m_heartbeat_socket->isSocketConnected();
}

void HeartbeatServiceImpl::processReceivedHeartbeatMsg(void* p_msg)
{
   FrameworkHeartbeatMsg* received_heartbeat_msg = (FrameworkHeartbeatMsg*)p_msg;

   Service<LogService>::getInstance().log(serviceId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "Heartbeat service received heartbeat message from node %s using %s:%d",
                                          received_heartbeat_msg->m_body.m_sending_node_name,
                                          m_heartbeat_socket->ipAddress().c_str(),
                                          m_heartbeat_socket->port());
}

void HeartbeatServiceImpl::receiveHeartbeats()
{
   bool recv_error = false;
   int byte_count = 0;

   m_incoming_msg_buffer.init();

   try
   {
      byte_count = m_heartbeat_socket->recvMessage(m_incoming_msg_buffer.buffer(),
                                                   m_incoming_msg_buffer.bufferSize());
   }
   catch(DscException const& e_dsc)
   {
      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::ERROR,
                                             "Heartbeat service DscException(%s) using %s:%d",
                                             e_dsc.what(),
                                             m_heartbeat_socket->ipAddress().c_str(),
                                             m_heartbeat_socket->port());

      recv_error = true;
   }
   catch(std::exception const& e_std)
   {
      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::ERROR,
                                             "Heartbeat service std::exception(%s) using %s:%d",
                                             e_std.what(),
                                             m_heartbeat_socket->ipAddress().c_str(),
                                             m_heartbeat_socket->port());

      recv_error = true;
   }

   if (not recv_error && byte_count > 0)
   {
      processReceivedHeartbeatMsg(m_incoming_msg_buffer.buffer());
   }
   else
   {
      if (recv_error)
      {
         closeNetworkConnection();
      }
   }
}

void HeartbeatServiceImpl::run()
{
   if (serviceEnabled())
   {
      if (not networkConnectionEstablished())
      {
         establishNetworkConnection();
      }
      else
      {
         sendHeartbeat();
         receiveHeartbeats();
      }
   }
}

void HeartbeatServiceImpl::sendHeartbeat()
{
   double current_time = Service<TimeService>::getInstance().currentTimeSecs();

   if ((current_time - m_last_heartbeat_time) >= HEARTBEAT_INTERVAL)
   {
      bool send_error = false;
      int bytes_count = 0;

      try
      {
         bytes_count = m_heartbeat_socket->sendMessage(&m_framework_heartbeat_msg,
                                                       m_framework_heartbeat_msg.m_header.m_msg_size);
      }
      catch(DscException const& e_dsc)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::ERROR,
                                                "Heartbeat service DscException(%s) using %s:%d",
                                                e_dsc.what(),
                                                m_heartbeat_socket->ipAddress().c_str(),
                                                m_heartbeat_socket->port());

         send_error = true;
      }
      catch(std::exception const& e_std)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::ERROR,
                                                "Heartbeat service std::exception(%s) using %s:%d",
                                                e_std.what(),
                                                m_heartbeat_socket->ipAddress().c_str(),
                                                m_heartbeat_socket->port());

         send_error = true;
      }

      if (not send_error && bytes_count > 0)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::INFO,
                                                "Heartbeat service sent heartbeat message using %s:%d",
                                                m_heartbeat_socket->ipAddress().c_str(),
                                                m_heartbeat_socket->port());
      }

      m_last_heartbeat_time = Service<TimeService>::getInstance().currentTimeSecs();
   }
}

bool HeartbeatServiceImpl::serviceEnabled()
{
   return SERVICE_ENABLED;
}
