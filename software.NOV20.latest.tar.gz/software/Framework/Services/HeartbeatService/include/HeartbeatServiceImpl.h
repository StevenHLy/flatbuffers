#ifndef HeartbeatServiceImpl_h
#define HeartbeatServiceImpl_h

#include "FrameworkHeartbeatMsg.h"
#include "GenericBuffer.h"
#include "HeartbeatService.h"
#include "MulticastSocketImpl.h"
#include "ServiceImpl.h"
#include <memory>

class HeartbeatServiceImpl : public ServiceImpl<HeartbeatService>
{
   public:

      HeartbeatServiceImpl(unsigned int p_service_id);
      virtual ~HeartbeatServiceImpl() = default;

      void disable() override;
      void enable() override;

      void run();

   protected:

      const bool SERVICE_ENABLED;
      const double CONNECTION_ATTEMPT_INTERVAL;
      const double HEARTBEAT_INTERVAL;
      const int TIME_TO_LIVE;

      void closeNetworkConnection();
      void establishNetworkConnection();
      bool networkConnectionEstablished();
      void processReceivedHeartbeatMsg(void* p_msg);
      void receiveHeartbeats();
      void sendHeartbeat();
      bool serviceEnabled();

      double m_last_heartbeat_time;
      double m_time_of_last_connection_attempt;
      unsigned int m_polling_id;
      std::unique_ptr<MulticastSocketImpl> m_heartbeat_socket;
      FrameworkHeartbeatMsg m_framework_heartbeat_msg;
      GenericBuffer<unsigned char> m_incoming_msg_buffer;
};

#endif
