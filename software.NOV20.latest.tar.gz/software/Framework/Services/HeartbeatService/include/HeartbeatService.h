#ifndef HeartbeatService_h
#define HeartbeatService_h

class HeartbeatService
{
   public:

      static constexpr const char* SERVICE_NAME = "HeartbeatService";

      HeartbeatService() = default;
      virtual ~HeartbeatService() = default;
};

#endif
