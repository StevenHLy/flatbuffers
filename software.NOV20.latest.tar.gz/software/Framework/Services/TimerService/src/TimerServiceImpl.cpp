#include "TimerServiceImpl.h"
#include "LogService.h"
#include "LogSeverityType.h"
#include "Service.h"
#include "TimerIdNotRegisteredException.h"
#include "TimeService.h"
#include <list>

TimerServiceImpl::TimerServiceImpl(unsigned int p_service_id)
: ServiceImpl<TimerService>(TimerService::SERVICE_NAME,
                            p_service_id)
, m_mutex()
, m_remove_timer_list()
, m_active_timer_list()
, m_timer_id_generator()
, m_master_timer_list()
{
}

void TimerServiceImpl::disable(unsigned int p_requester_id,
                               unsigned int p_timer_id)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   TimerData* timer_handle = getTimer(p_requester_id,
                                      p_timer_id);

   if (timer_handle != nullptr)
   {
      timer_handle->m_status = TimerStatusType::DISABLED;
      timer_handle->m_expiration_time = 0.0;

      m_active_timer_list.erase(timer_handle->m_id);

      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::INFO,
                                             "Disabled timer id (%d) for requester id (%d)",
                                             p_timer_id,
                                             p_requester_id);
   }
   else
   {
      throw TimerIdNotRegisteredException(__FILE__,
                                          __LINE__,
                                          p_timer_id);
   }
}

void TimerServiceImpl::enable(unsigned int p_requester_id,
                              unsigned int p_timer_id,
                              double p_timer_delay_secs)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   TimerData* timer_handle = getTimer(p_requester_id,
                                      p_timer_id);

   if (timer_handle != nullptr)
   {
      timer_handle->m_status = TimerStatusType::ENABLED;
      timer_handle->m_expiration_time = Service<TimeService>::getInstance().currentTimeSecs() + p_timer_delay_secs;

      m_active_timer_list[timer_handle->m_id] = timer_handle;

      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::INFO,
                                             "Enabled timer id (%d) for requester id (%d)",
                                             p_timer_id,
                                             p_requester_id);
   }
   else
   {
      throw TimerIdNotRegisteredException(__FILE__,
                                          __LINE__,
                                          p_timer_id);
   }
}

TimerServiceImpl::TimerData* TimerServiceImpl::getTimer(unsigned int p_requester_id,
                                                        unsigned int p_timer_id)
{
   TimerData* timer_handle = nullptr;

   MasterTimerListType::iterator it = m_master_timer_list.find(p_timer_id);

   if (it != m_master_timer_list.end())
   {
      timer_handle = &(it->second);
   }

   return timer_handle;
}

bool TimerServiceImpl::isTimerEnabled(unsigned int p_requester_id,
                                      unsigned int p_timer_id)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   TimerData* timer_handle = getTimer(p_requester_id,
                                      p_timer_id);

   if (timer_handle != nullptr)
   {
      return(timer_handle->m_status == TimerStatusType::ENABLED);
   }
   else
   {
      throw TimerIdNotRegisteredException(__FILE__,
                                          __LINE__,
                                          p_timer_id);
   }
}

bool TimerServiceImpl::isTimerRegistered(unsigned int p_requester_id,
                                         unsigned int p_timer_id)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   bool registered = false;

   for (auto timer : m_master_timer_list)
   {
      if (timer.second.m_requester_id == p_requester_id && timer.second.m_id == p_timer_id)
      {
         registered = true;
         break;
      }
   }

   return(registered);
}

void TimerServiceImpl::processExpiredEventTimer(TimerData const& p_timer)
{
   try
   {
      p_timer.m_callback_method(p_timer.m_id);
   }
   catch(std::exception const& e_std)
   {
      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::ERROR,
                                             "Timer service raised std::exception(%s)",
                                             e_std.what());
   }
}

unsigned int TimerServiceImpl::registerOneShotTimer(unsigned int p_requester_id,
                                                             MethodCallbackType p_callback_method)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   unsigned int timer_id = m_timer_id_generator.nextId();

   m_master_timer_list[timer_id] = TimerData(p_requester_id,
                                             timer_id,
                                             TimerServiceImpl::TimerType::ONE_SHOT_TIMER,
                                             TimerStatusType::DISABLED,
                                             0.0,
                                             p_callback_method);

   Service<LogService>::getInstance().log(serviceId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "Registered ONE_SHOT_TIMER id (%d) for requester id (%d)",
                                          timer_id,
                                          p_requester_id);

   return timer_id;
}

unsigned int TimerServiceImpl::registerPeriodicTimer(unsigned int p_requester_id,
                                                              double p_periodicity,
                                                              MethodCallbackType p_callback_method)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   unsigned int timer_id = m_timer_id_generator.nextId();

   m_master_timer_list[timer_id] = TimerData(p_requester_id,
                                             timer_id,
                                             TimerServiceImpl::TimerType::PERIODIC_TIMER,
                                             TimerStatusType::DISABLED,
                                             p_periodicity,
                                             p_callback_method);

   Service<LogService>::getInstance().log(serviceId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "Registered PERIODIC_TIMER id (%d) for requester id (%d)",
                                          timer_id,
                                          p_requester_id);

   return timer_id;
}

void TimerServiceImpl::removeTimer(unsigned int p_requester_id,
                                   unsigned int p_timer_id)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   if (isTimerRegistered(p_requester_id, p_timer_id))
   {
      m_remove_timer_list.emplace(p_timer_id);
   }
}

void TimerServiceImpl::run()
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   std::list<TimerData*> expired_timer_list;

   for (auto& map_item : m_active_timer_list)
   {
      auto& active_timer = map_item.second;

      if (active_timer != nullptr)
      {
         double current_time = Service<TimeService>::getInstance().currentTimeSecs();

         if (active_timer->m_status == TimerStatusType::ENABLED &&
             current_time >= active_timer->m_expiration_time)
         {
            expired_timer_list.push_back(active_timer);
         }
      }
   }

   for (auto& expired_timer : expired_timer_list)
   {
      processExpiredEventTimer(*expired_timer);

      if (expired_timer->m_type == TimerType::ONE_SHOT_TIMER)
      {
         disable(expired_timer->m_requester_id,
                 expired_timer->m_id);
      }

      if (expired_timer->m_type == TimerType::PERIODIC_TIMER &&
          expired_timer->m_status == TimerStatusType::ENABLED)
      {
         expired_timer->m_expiration_time = Service<TimeService>::getInstance().currentTimeSecs() + expired_timer->m_periodicity;

         m_active_timer_list[expired_timer->m_id] = expired_timer;
      }
   }

   if (m_remove_timer_list.empty() == false)
   {
      for (auto& timer_id : m_remove_timer_list)
      {
         m_master_timer_list.erase(timer_id);
         m_active_timer_list.erase(timer_id);
      }

      m_remove_timer_list.clear();
   }
}

void TimerServiceImpl::updatePeriodicity(unsigned int p_requester_id,
                                         unsigned int p_timer_id,
                                         double p_periodicity)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   TimerData* timer_handle = getTimer(p_requester_id,
                                      p_timer_id);

   if (timer_handle != nullptr)
   {
      if (timer_handle->m_type == TimerType::PERIODIC_TIMER)
      {
         timer_handle->m_periodicity = p_periodicity;
      }
   }
   else
   {
      throw TimerIdNotRegisteredException(__FILE__,
                                          __LINE__,
                                          p_timer_id);
   }
}
