#ifndef TimerServiceImpl_h
#define TimerServiceImpl_h

#include "IdGenerator.h"
#include "ServiceImpl.h"
#include "TimerService.h"
#include <assert.h>
#include <map>
#include <memory>
#include <mutex>
#include <set>

class TimerServiceImpl : public ServiceImpl<TimerService>
{
   public:

      enum class TimerType
      {
         ONE_SHOT_TIMER,
         PERIODIC_TIMER
      };

      TimerServiceImpl(unsigned int p_service_id);
      virtual ~TimerServiceImpl() = default;

      void disable(unsigned int p_requester_id,
                   unsigned int p_timer_id) override;
      void enable(unsigned int p_requester_id,
                  unsigned int p_timer_id,
                  double p_timer_delay_secs = 0.0) override;
      bool isTimerEnabled(unsigned int p_requester_id,
                          unsigned int p_timer_id) override;
      bool isTimerRegistered(unsigned int p_requester_id,
                             unsigned int p_timer_id) override;
      unsigned int registerOneShotTimer(unsigned int p_requester_id,
                                                 MethodCallbackType p_callback_method) override;
      unsigned int registerPeriodicTimer(unsigned int p_requester_id,
                                                  double p_periodicity,
                                                  MethodCallbackType p_callback_method) override;
      void removeTimer(unsigned int p_requester_id,
                       unsigned int p_timer_id) override;
      void run() override;
      void updatePeriodicity(unsigned int p_requester_id,
                             unsigned int p_timer_id,
                             double p_periodicity) override;

   protected:

      struct TimerData
      {
         unsigned int m_id;
         TimerType m_type;
         unsigned int m_requester_id;
         TimerStatusType m_status;
         double m_periodicity;
         double m_expiration_time;
         MethodCallbackType m_callback_method;

         TimerData()
         : m_id(0)
         , m_type(TimerType::ONE_SHOT_TIMER)
         , m_requester_id(0)
         , m_status(TimerStatusType::DISABLED)
         , m_periodicity(0.0)
         , m_expiration_time(0.0)
         , m_callback_method()
         {}

         TimerData(unsigned int p_requester_id,
                   unsigned int p_id,
                   TimerType p_type,
                   TimerStatusType p_status,
                   double p_periodicity,
                   MethodCallbackType p_callback_method)
         : m_id(p_id)
         , m_type(p_type)
         , m_requester_id(p_requester_id)
         , m_status(p_status)
         , m_periodicity(p_periodicity)
         , m_expiration_time(0.0)
         , m_callback_method(p_callback_method)
         {}
      };

      typedef std::map<unsigned int, TimerData*> ActiveTimerListType;
      typedef std::map<unsigned int, TimerData> MasterTimerListType;
      typedef std::set<unsigned int> RemoveTimerListType;

      TimerData* getTimer(unsigned int p_requester_id,
                          unsigned int p_timer_id);
      void processExpiredEventTimer(const TimerData& p_timer);

      std::recursive_mutex m_mutex;
      ActiveTimerListType m_active_timer_list;
      IdGenerator<unsigned int> m_timer_id_generator;
      MasterTimerListType m_master_timer_list;
      RemoveTimerListType m_remove_timer_list;
};

#endif
