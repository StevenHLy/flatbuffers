#ifndef TimerService_h
#define TimerService_h

#include <functional>

class TimerService
{
   public:

      static constexpr const char* SERVICE_NAME = "TimerService";

      enum class TimerStatusType
      {
         DISABLED,
         ENABLED
      };

      typedef std::function<void(const unsigned int)> MethodCallbackType;

      TimerService() = default;
      virtual ~TimerService() = default;

      virtual void disable(unsigned int p_requester_id,
                           unsigned int p_timer_id) = 0;
      virtual void enable(unsigned int p_requester_id,
                          unsigned int p_timer_id,
                          double p_timer_delay_secs = 0.0) = 0;
      virtual bool isTimerEnabled(unsigned int p_requester_id,
                                  unsigned int p_timer_id) = 0;
      virtual bool isTimerRegistered(unsigned int p_requester_id,
                                     unsigned int p_timer_id) = 0;
      virtual unsigned int registerOneShotTimer(unsigned int p_requester_id,
                                                         MethodCallbackType p_callback_method) = 0;
      virtual unsigned int registerPeriodicTimer(unsigned int p_requester_id,
                                                          double p_periodicity,
                                                          MethodCallbackType p_callback_method) = 0;
      virtual void removeTimer(unsigned int p_requester_id,
                               unsigned int p_timer_id) = 0;
      virtual void run() = 0;
      virtual void updatePeriodicity(unsigned int p_requester_id,
                                     unsigned int p_timer_id,
                                     double p_periodicity) = 0;
};

#endif
