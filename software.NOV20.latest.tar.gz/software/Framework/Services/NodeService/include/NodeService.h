#ifndef NodeService_h
#define NodeService_h

#include <string>
#include <vector>

class NodeService
{
   public:

      static constexpr const char* SERVICE_NAME = "NodeService";

      NodeService() = default;
      virtual ~NodeService() = default;

      virtual bool componentAllocatedToNode(unsigned int p_component_id,
                                            std::string p_node_name) = 0;
      virtual bool componentAllocatedToNode(std::string p_component_name,
                                            std::string p_node_name) = 0;
      virtual std::string componentIdToComponentName(unsigned int p_component_id) = 0;
      virtual std::string componentIdToNodeName(unsigned int p_component_id) = 0;
      virtual unsigned int componentNameToComponentId(std::string p_component_name) = 0;
      virtual std::string componentNameToNodeName(std::string p_component_name) = 0;
      virtual std::vector<std::string> configuredNodes() = 0;
      virtual std::string localNodeIpAddress() = 0;
      virtual std::string localNodeName() = 0;
      virtual unsigned int nodeNameToNodeId(std::string p_node_name) = 0;
      virtual std::string nodeNameToIpAddress(std::string p_node_name) = 0;
      virtual int nodeNameToPortNumber(std::string p_node_name) = 0;
};

#endif
