#ifndef NodeServiceImpl_h
#define NodeServiceImpl_h

#include "NodeService.h"
#include "ServiceImpl.h"
#include <map>
#include <string>
#include <vector>

class NodeServiceImpl : public ServiceImpl<NodeService>
{
   public:

      NodeServiceImpl(unsigned int p_service_id);
      virtual ~NodeServiceImpl() = default;

      bool componentAllocatedToNode(unsigned int p_component_id,
                                    std::string p_node_name) override;
      bool componentAllocatedToNode(std::string p_component_name,
                                    std::string p_node_name) override;
      std::string componentIdToComponentName(unsigned int p_component_id) override;
      std::string componentIdToNodeName(unsigned int p_component_id) override;
      unsigned int componentNameToComponentId(std::string p_component_name) override;
      std::string componentNameToNodeName(std::string p_component_name) override;
      std::vector<std::string> configuredNodes() override;
      std::string localNodeIpAddress() override;
      std::string localNodeName() override;
      unsigned int nodeNameToNodeId(std::string p_node_name) override;
      std::string nodeNameToIpAddress(std::string p_node_name) override;
      int nodeNameToPortNumber(std::string p_node_name) override;

   protected:

      struct ApplicationComponentData
      {
         unsigned int m_component_id;
         std::string m_component_name;

         ApplicationComponentData()
         : m_component_id(0)
         , m_component_name("")
         {}
      };

      struct FrameworkServiceData
      {
         unsigned int m_service_id;
         std::string m_service_name;

         FrameworkServiceData()
         : m_service_id(0)
         , m_service_name("")
         {}
      };

      struct ComputeNodeData
      {
         unsigned int m_node_id;
         std::string m_node_name;
         std::string m_ip_address;
         int m_comms_port;
         std::vector<FrameworkServiceData> m_framework_services;
         std::vector<ApplicationComponentData> m_application_components;

         ComputeNodeData()
         : m_node_id(0)
         , m_node_name("")
         , m_ip_address("")
         , m_comms_port(-1)
         , m_framework_services()
         , m_application_components()
         {}
      };

      void createComputeNodeMap();

      std::map<std::string, ComputeNodeData> m_compute_nodes;
      std::string m_local_node_ip_address;
      std::string m_local_node_name;
};

#endif
