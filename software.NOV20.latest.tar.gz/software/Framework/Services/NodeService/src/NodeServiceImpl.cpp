#include "NodeServiceImpl.h"
#include "ConfigParameters.h"
#include <limits.h>
#include <unistd.h>

NodeServiceImpl::NodeServiceImpl(unsigned int p_service_id)
: ServiceImpl<NodeService>(NodeService::SERVICE_NAME,
                           p_service_id)
, m_local_node_ip_address("")
, m_local_node_name("")
{
   createComputeNodeMap();

   char host[HOST_NAME_MAX] = {0};
   gethostname(host, HOST_NAME_MAX);
   std::string host_name_str = std::string(host);

   m_local_node_name = host_name_str.substr(0, host_name_str.find("."));
   m_local_node_ip_address = nodeNameToIpAddress(m_local_node_name);
}

bool NodeServiceImpl::componentAllocatedToNode(unsigned int p_component_id,
                                               std::string p_node_name)
{
   bool allocated = false;

   for (auto& current_node : m_compute_nodes)
   {
      if (current_node.second.m_node_name == p_node_name)
      {
         for (auto& current_component : current_node.second.m_application_components)
         {
            if (current_component.m_component_id == p_component_id)
            {
               allocated = true;
               break;
            }
         }
      }
   }

   return allocated;
}

bool NodeServiceImpl::componentAllocatedToNode(std::string p_component_name,
                                               std::string p_node_name)
{
   bool allocated = false;

   for (auto& current_node : m_compute_nodes)
   {
      if (current_node.second.m_node_name == p_node_name)
      {
         for (auto& current_component : current_node.second.m_application_components)
         {
            if (current_component.m_component_name == p_component_name)
            {
               allocated = true;
               break;
            }
         }
      }
   }

   return allocated;
}

std::string NodeServiceImpl::componentIdToComponentName(unsigned int p_component_id)
{
   std::string component_name;

   for (auto& current_node : m_compute_nodes)
   {
      for (auto& current_component : current_node.second.m_application_components)
      {
         if (current_component.m_component_id == p_component_id)
         {
            component_name = current_component.m_component_name;
            break;
         }
      }
   }

   return component_name;
}

std::string NodeServiceImpl::componentIdToNodeName(unsigned int p_component_id)
{
   std::string node_name = "";

   for (auto& current_node : m_compute_nodes)
   {
      for (auto& current_component : current_node.second.m_application_components)
      {
         if (current_component.m_component_id == p_component_id)
         {
            node_name = current_node.second.m_node_name;
            break;
         }
      }
   }

   return node_name;
}

unsigned int NodeServiceImpl::componentNameToComponentId(std::string p_component_name)
{
   unsigned int component_id = 0;

   for (auto& current_node : m_compute_nodes)
   {
      for (auto& current_component : current_node.second.m_application_components)
      {
         if (current_component.m_component_name == p_component_name)
         {
            component_id = current_component.m_component_id;
            break;
         }
      }
   }

   return component_id;
}

std::string NodeServiceImpl::componentNameToNodeName(std::string p_component_name)
{
   std::string node_name = "";

   for (auto& current_node : m_compute_nodes)
   {
      for (auto& current_component : current_node.second.m_application_components)
      {
         if (current_component.m_component_name == p_component_name)
         {
            node_name = current_node.second.m_node_name;
            break;
         }
      }
   }

   return node_name;
}

std::vector<std::string> NodeServiceImpl::configuredNodes()
{
   std::vector<std::string> configured_nodes;

   for (auto& node : m_compute_nodes)
   {
      configured_nodes.push_back(node.second.m_node_name);
   }

   return configured_nodes;
}

void NodeServiceImpl::createComputeNodeMap()
{
   ConfigParameters::iterator iter;

   for (iter = ConfigParameters::getInstance().getPropertyTree().get_child("SiteConfiguration.Building142.ComputeNodes").begin();
        iter != ConfigParameters::getInstance().getPropertyTree().get_child("SiteConfiguration.Building142.ComputeNodes").end();
        ++iter)
   {
      std::string node_name = iter->first;
      unsigned int node_id = ConfigParameters::getInstance().getRequiredParam<unsigned int>("SiteConfiguration.Building142.ComputeNodes." + iter->first + ".Node_Id");
      std::string ip_address = ConfigParameters::getInstance().getRequiredParam<std::string>("SiteConfiguration.Building142.ComputeNodes." + iter->first + ".IP_Address");
      int comms_port = ConfigParameters::getInstance().getRequiredParam<int>("SiteConfiguration.Building142.ComputeNodes." + iter->first + ".Comms_Port");
      std::vector<std::string> framework_services = ConfigParameters::getInstance().getArrayParam<std::string>("SiteConfiguration.Building142.ComputeNodes." + iter->first + ".Framework_Services");
      std::vector<std::string> application_components = ConfigParameters::getInstance().getArrayParam<std::string>("SiteConfiguration.Building142.ComputeNodes." + iter->first + ".Application_Components");

      ComputeNodeData new_node;
      new_node.m_node_id = node_id;
      new_node.m_node_name = node_name;
      new_node.m_ip_address = ip_address;
      new_node.m_comms_port = comms_port;

      for (auto& service_name : framework_services)
      {
         FrameworkServiceData new_framework_service;
         new_framework_service.m_service_name = service_name;
         new_framework_service.m_service_id = ConfigParameters::getInstance().getRequiredParam<unsigned int>("MasterModuleList." + service_name + ".Module_Id");

         new_node.m_framework_services.push_back(new_framework_service);
      }

      for (auto& component_name : application_components)
      {
         ApplicationComponentData new_application_component;
         new_application_component.m_component_name = component_name;
         new_application_component.m_component_id = ConfigParameters::getInstance().getRequiredParam<unsigned int>("MasterModuleList." + component_name + ".Module_Id");

         new_node.m_application_components.push_back(new_application_component);
      }

      m_compute_nodes[node_name] = new_node;
   }
}

std::string NodeServiceImpl::localNodeIpAddress()
{
   return m_local_node_ip_address;
}

std::string NodeServiceImpl::localNodeName()
{
   return m_local_node_name;
}

unsigned int NodeServiceImpl::nodeNameToNodeId(std::string p_node_name)
{
   unsigned int node_id = 0;

   std::map<std::string, ComputeNodeData>::iterator it;

   if ((it = m_compute_nodes.find(p_node_name)) != m_compute_nodes.end())
   {
      node_id = it->second.m_node_id;
   }

   return node_id;
}

std::string NodeServiceImpl::nodeNameToIpAddress(std::string p_node_name)
{
   std::string ip_address;

   std::map<std::string, ComputeNodeData>::iterator it;

   if ((it = m_compute_nodes.find(p_node_name)) != m_compute_nodes.end())
   {
      ip_address = it->second.m_ip_address;
   }

   return ip_address;
}

int NodeServiceImpl::nodeNameToPortNumber(std::string p_node_name)
{
   int port_number = -1;
   std::map<std::string, ComputeNodeData>::iterator it;

   if ((it = m_compute_nodes.find(p_node_name)) != m_compute_nodes.end())
   {
      port_number = it->second.m_comms_port;
   }

   return port_number;
}
