#ifndef Service_h
#define Service_h

#include "ServiceImpl.h"
#include <cassert>

template <typename ServiceType>
class Service
{
   public:

      template <typename ServiceImplType, typename... Args> static void create(unsigned int p_service_id,
                                                                               Args&&... p_args);

      static void disable();
      static void enable();
      static ServiceType& getInstance();
      static void initialize();
      static void shutdown();

   protected:

      struct ServiceControlData
      {
         bool m_created;
         bool m_initialized;
         bool m_enabled;
         ServiceImpl<ServiceType>* m_service_impl_instance;

         ServiceControlData()
         : m_created(false)
         , m_initialized(false)
         , m_enabled(false)
         , m_service_impl_instance(nullptr)
         {}
      };

      static ServiceControlData m_service_control_data;

      Service() = delete;
      virtual ~Service() = delete;
};

template <typename ServiceType> typename Service<ServiceType>::ServiceControlData Service<ServiceType>::m_service_control_data;

template <typename ServiceType>
template <typename ServiceImplType, typename... Args>
void Service<ServiceType>::create(unsigned int p_service_id,
                                  Args&&... p_args)
{
   assert(not m_service_control_data.m_created);

   m_service_control_data.m_service_impl_instance = new ServiceImplType(p_service_id,
                                                                        std::forward<Args>(p_args)...);
   m_service_control_data.m_created = true;
}

template <typename ServiceType>
void Service<ServiceType>::disable()
{
   assert(m_service_control_data.m_created &&
          m_service_control_data.m_initialized);

   m_service_control_data.m_service_impl_instance->disable();
   m_service_control_data.m_enabled = false;
}

template <typename ServiceType>
void Service<ServiceType>::enable()
{
   assert(m_service_control_data.m_created &&
          m_service_control_data.m_initialized);

   m_service_control_data.m_service_impl_instance->enable();
   m_service_control_data.m_enabled = true;
}

template <typename ServiceType>
ServiceType& Service<ServiceType>::getInstance()
{
   assert(m_service_control_data.m_created &&
          m_service_control_data.m_initialized);

   return *(m_service_control_data.m_service_impl_instance);
}

template <typename ServiceType>
void Service<ServiceType>::initialize()
{
   assert(m_service_control_data.m_created &&
          not m_service_control_data.m_initialized &&
          not m_service_control_data.m_enabled);

   m_service_control_data.m_service_impl_instance->initialize();
   m_service_control_data.m_initialized = true;
}

template <typename ServiceType>
void Service<ServiceType>::shutdown()
{
   assert(m_service_control_data.m_created);

   m_service_control_data.m_service_impl_instance->shutdown();
   delete m_service_control_data.m_service_impl_instance;

   m_service_control_data.m_created = false;
   m_service_control_data.m_enabled = false;
   m_service_control_data.m_initialized = false;
   m_service_control_data.m_service_impl_instance = nullptr;
}

#endif
