#ifndef ServiceImpl_h
#define ServiceImpl_h

#include <string>

template <typename ServiceType>class Service;

template <typename ServiceInterfaceType>
class ServiceImpl : public ServiceInterfaceType
{
   public:

      friend class Service<ServiceInterfaceType>;

      virtual ~ServiceImpl() = default;
      virtual void disable();
      virtual void enable();
      virtual void initialize();
      virtual void shutdown();

      unsigned int serviceId();
      std::string serviceName();

   protected:

      const unsigned int SERVICE_ID;
      const std::string SERVICE_NAME;

      ServiceImpl(std::string p_service_name,
                  unsigned int p_service_id);
};

template <typename ServiceInterfaceType>
ServiceImpl<ServiceInterfaceType>::ServiceImpl(std::string p_service_name,
                                               unsigned int p_service_id)
: ServiceInterfaceType()
, SERVICE_NAME(p_service_name)
, SERVICE_ID(p_service_id)
{
}

template <typename ServiceInterfaceType>
void ServiceImpl<ServiceInterfaceType>::disable()
{
}

template <typename ServiceInterfaceType>
void ServiceImpl<ServiceInterfaceType>::enable()
{
}

template <typename ServiceInterfaceType>
void ServiceImpl<ServiceInterfaceType>::initialize()
{
}

template <typename ServiceInterfaceType>
void ServiceImpl<ServiceInterfaceType>::shutdown()
{
}

template <typename ServiceInterfaceType>
unsigned int ServiceImpl<ServiceInterfaceType>::serviceId()
{
   return SERVICE_ID;
}

template <typename ServiceInterfaceType>
std::string ServiceImpl<ServiceInterfaceType>::serviceName()
{
   return SERVICE_NAME;
}

#endif
