#include "MsgServiceImpl.h"
#include "ConfigParameters.h"
#include "DscException.h"
#include "LogService.h"
#include "NodeService.h"
#include "ProtocolFamilyType.h"
#include "Service.h"
#include "TimeService.h"
#include <exception>
#include <string.h>
#include <vector>

MsgServiceImpl::MsgServiceImpl(unsigned int p_service_id)
: ServiceImpl<MsgService>(MsgService::SERVICE_NAME,
                          p_service_id)
, CONNECTION_ATTEMPT_INTERVAL(ConfigParameters::getInstance().getRequiredParam<double>("MsgService.Connection_Attempt_Interval_Secs"))
, m_time_of_last_inbound_connection_attempt(0.0)
, m_time_of_last_outbound_connection_attempt(0.0)
, m_polling_id(0)
, m_send_socket()
, m_receive_socket()
, m_msg_queue()
, m_incoming_msg_buffer(ConfigParameters::getInstance().getRequiredParam<int>("MsgService.Incoming_Msg_Buffer_Size_Bytes"))
, m_subscribers()
{
}

void MsgServiceImpl::closeInboundNetworkConnection()
{
   m_receive_socket->closeSocket();
}

void MsgServiceImpl::closeOutboundNetworkConnections()
{
   for (auto& outbound_socket : m_send_socket)
   {
      outbound_socket.second->closeSocket();
   }
}

void MsgServiceImpl::createReceiveSocket()
{
   std::string local_node = Service<NodeService>::getInstance().localNodeName();
   std::string local_ip_address = Service<NodeService>::getInstance().localNodeIpAddress();
   int port_number = Service<NodeService>::getInstance().nodeNameToPortNumber(local_node);

   m_receive_socket.reset(new UnicastSocketImpl(local_ip_address,
                                                port_number));
}

void MsgServiceImpl::createSendSockets()
{
   std::string local_node = Service<NodeService>::getInstance().localNodeName();
   std::vector<std::string> configured_nodes = Service<NodeService>::getInstance().configuredNodes();

   for (auto& current_node : configured_nodes)
   {
      if (local_node != current_node)
      {
         std::string remote_node_ip_address = Service<NodeService>::getInstance().nodeNameToIpAddress(current_node);
         int remote_node_port_number = Service<NodeService>::getInstance().nodeNameToPortNumber(current_node);

         m_send_socket[current_node].reset(new UnicastSocketImpl(remote_node_ip_address,
                                                                 remote_node_port_number));
      }
   }
}

void MsgServiceImpl::enable()
{
   createReceiveSocket();
   createSendSockets();

   m_polling_id = Service<PollingService>::getInstance().registerCallback(PollingService::MethodCallbackType([this]()
                                                                                                             {
                                                                                                                this->run();
                                                                                                             }));

   Service<PollingService>::getInstance().enableCallback(m_polling_id);
}

void MsgServiceImpl::establishInboundNetworkConnection()
{
   double current_time = Service<TimeService>::getInstance().currentTimeSecs();
   double connection_attempt_delta_time = current_time - m_time_of_last_inbound_connection_attempt;

   if (connection_attempt_delta_time >= CONNECTION_ATTEMPT_INTERVAL)
   {
      m_time_of_last_inbound_connection_attempt = current_time;

      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::INFO,
                                             "Msg service attempting to establish inbound network connection using %s:%d",
                                             m_receive_socket->ipAddress().c_str(),
                                             m_receive_socket->port());

      try
      {
         m_receive_socket->createSocket();
         m_receive_socket->setNonBlocking(true);
         m_receive_socket->setSocketOptReuseAddr(true);
         m_receive_socket->bindLocalPort();
      }
      catch(DscException const& e_dsc)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::ERROR,
                                                "Msg service DscException(%s) using %s:%d",
                                                e_dsc.what(),
                                                m_receive_socket->ipAddress().c_str(),
                                                m_receive_socket->port());

         m_receive_socket->closeSocket();
      }
      catch(std::exception const& e_std)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::ERROR,
                                                "Msg service std::exception(%s) using %s:%d",
                                                e_std.what(),
                                                m_receive_socket->ipAddress().c_str(),
                                                m_receive_socket->port());

         m_receive_socket->closeSocket();
      }

      if (m_receive_socket->isSocketConnected())
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::INFO,
                                                "Msg service established inbound network connection using %s:%d",
                                                m_receive_socket->ipAddress().c_str(),
                                                m_receive_socket->port());
      }
      else
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::WARNING,
                                                "Msg service unable to establish inbound network connection using %s:%d",
                                                m_receive_socket->ipAddress().c_str(),
                                                m_receive_socket->port());
      }
   }
}

void MsgServiceImpl::establishOutboundNetworkConnections()
{
   double current_time = Service<TimeService>::getInstance().currentTimeSecs();
   double connection_attempt_delta_time = current_time - m_time_of_last_outbound_connection_attempt;

   if (connection_attempt_delta_time >= CONNECTION_ATTEMPT_INTERVAL)
   {
      m_time_of_last_outbound_connection_attempt = current_time;

      for (auto& outbound_socket : m_send_socket)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::INFO,
                                                "Msg service attempting to establish outbound network connection to %s:%d",
                                                outbound_socket.second->ipAddress().c_str(),
                                                outbound_socket.second->port());

         try
         {
            outbound_socket.second->createSocket();
            outbound_socket.second->setNonBlocking(true);
            outbound_socket.second->setSocketOptReuseAddr(true);
         }
         catch(DscException const& e_dsc)
         {
            Service<LogService>::getInstance().log(serviceId(),
                                                   __FILE__,
                                                   __LINE__,
                                                   LogSeverityTypeEnum::ERROR,
                                                   "Msg service DscException(%s) using %s:%d",
                                                   e_dsc.what(),
                                                   outbound_socket.second->ipAddress().c_str(),
                                                   outbound_socket.second->port());

            outbound_socket.second->closeSocket();
         }
         catch(std::exception const& e_std)
         {
            Service<LogService>::getInstance().log(serviceId(),
                                                   __FILE__,
                                                   __LINE__,
                                                   LogSeverityTypeEnum::ERROR,
                                                   "Msg service std::exception(%s) using %s:%d",
                                                   e_std.what(),
                                                   outbound_socket.second->ipAddress().c_str(),
                                                   outbound_socket.second->port());

            outbound_socket.second->closeSocket();
         }

         if (outbound_socket.second->isSocketConnected())
         {
            Service<LogService>::getInstance().log(serviceId(),
                                                   __FILE__,
                                                   __LINE__,
                                                   LogSeverityTypeEnum::INFO,
                                                   "Msg service established outbound network connection to %s:%d",
                                                   outbound_socket.second->ipAddress().c_str(),
                                                   outbound_socket.second->port());
         }
         else
         {
            Service<LogService>::getInstance().log(serviceId(),
                                                   __FILE__,
                                                   __LINE__,
                                                   LogSeverityTypeEnum::WARNING,
                                                   "Msg service unable to establish outbound network connection to %s:%d",
                                                   outbound_socket.second->ipAddress().c_str(),
                                                   outbound_socket.second->port());
         }
      }
   }
}

void MsgServiceImpl::getPendingInboundMessages()
{
   bool recv_error = false;
   int byte_count = 0;

   m_incoming_msg_buffer.init();

   try
   {
      byte_count = m_receive_socket->recvMessage(m_incoming_msg_buffer.buffer(),
                                                 m_incoming_msg_buffer.bufferSize());
   }
   catch(DscException const& e_dsc)
   {
      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::ERROR,
                                             "Msg service DscException(%s) using %s:%d",
                                             e_dsc.what(),
                                             m_receive_socket->ipAddress().c_str(),
                                             m_receive_socket->port());

      recv_error = true;
   }
   catch(std::exception const& e_std)
   {
      Service<LogService>::getInstance().log(serviceId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::ERROR,
                                             "Msg service std::exception(%s) using %s:%d",
                                             e_std.what(),
                                             m_receive_socket->ipAddress().c_str(),
                                             m_receive_socket->port());

      recv_error = true;
   }

   if (not recv_error && byte_count > 0)
   {
      queueReceivedMsg((InternalMsg*)m_incoming_msg_buffer.buffer());
   }
   else
   {
      if (recv_error)
      {
         closeInboundNetworkConnection();
      }
   }

}

bool MsgServiceImpl::inboundNetworkConnectionEstablished()
{
   return m_receive_socket->isSocketConnected();
}

bool MsgServiceImpl::outboundNetworkConnectionEstablished()
{
   bool all_connections_established = true;

   for (auto& outbound_socket : m_send_socket)
   {
      if (not outbound_socket.second->isSocketConnected())
      {
         all_connections_established = false;
         break;
      }
   }

   return all_connections_established;
}

void MsgServiceImpl::processQueuedMsg()
{
   if (not m_msg_queue.empty())
   {
      InternalMsg* dsc_msg = (InternalMsg*)(*m_msg_queue.begin())->buffer();

      try
      {
         m_subscribers.at(dsc_msg->m_header.m_receiver_id).at(dsc_msg->m_header.m_msg_id)(dsc_msg);
      }
      catch(std::out_of_range const& e)
      {
         Service<LogService>::getInstance().log(serviceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::WARNING,
                                                "No registered handler for component %s (%d) and msg %s (%d)",
                                                Service<NodeService>::getInstance().componentIdToComponentName(dsc_msg->m_header.m_receiver_id).c_str(),
                                                dsc_msg->m_header.m_receiver_id,
                                                InternalMsgIdType::enumToString(dsc_msg->m_header.m_msg_id).c_str(),
                                                dsc_msg->m_header.m_msg_id);
      }

      delete(m_msg_queue.front());
      m_msg_queue.pop_front();
   }
}

void MsgServiceImpl::queueReceivedMsg(InternalMsg* p_msg)
{
   p_msg->m_header.m_receive_time = Service<TimeService>::getInstance().currentTimeSecs();

   GenericBuffer<unsigned char>* new_msg_buffer = new GenericBuffer<unsigned char>(p_msg->m_header.m_msg_size);

   memcpy(new_msg_buffer->buffer(),
          p_msg,
          new_msg_buffer->bufferSize());

   m_msg_queue.push_back(new_msg_buffer);
}

double last_send_time = 0.0;

void MsgServiceImpl::run()
{
   if (not outboundNetworkConnectionEstablished())
   {
      establishOutboundNetworkConnections();
   }

   if (not inboundNetworkConnectionEstablished())
   {
      establishInboundNetworkConnection();
   }
   else
   {
      getPendingInboundMessages();
      processQueuedMsg();
   }
}

void MsgServiceImpl::sendMsg(unsigned int p_sender_id,
                             unsigned int p_receiver_id,
                             InternalMsg* p_msg_buffer)
{
   std::string sender_node_name = Service<NodeService>::getInstance().componentIdToNodeName(p_sender_id);
   std::string receiver_node_name = Service<NodeService>::getInstance().componentIdToNodeName(p_receiver_id);

   p_msg_buffer->m_header.m_sender_id = p_sender_id;
   p_msg_buffer->m_header.m_receiver_id = p_receiver_id;
   p_msg_buffer->m_header.m_send_time = Service<TimeService>::getInstance().currentTimeSecs();

   if (sender_node_name == receiver_node_name)
   {
      queueReceivedMsg(p_msg_buffer);
   }
   else
   {
      std::string remote_node_name = Service<NodeService>::getInstance().componentIdToNodeName(p_receiver_id);

      m_send_socket.at(remote_node_name)->sendMessage(p_msg_buffer,
                                                      p_msg_buffer->m_header.m_msg_size);
   }
}

void MsgServiceImpl::shutdown()
{
   closeInboundNetworkConnection();
   closeOutboundNetworkConnections();
}

void MsgServiceImpl::subscribe(InternalMsgIdType::InternalMsgIdTypeEnum p_msg_id,
                               unsigned int p_component_id,
                               MethodCallbackType p_callback_method)
{
   m_subscribers[p_component_id][p_msg_id] = p_callback_method;

   Service<LogService>::getInstance().log(serviceId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "Registered internal msg handler for component %s (%d) and msg %s (%d)",
                                          Service<NodeService>::getInstance().componentIdToComponentName(p_component_id).c_str(),
                                          p_component_id,
                                          InternalMsgIdType::enumToString(p_msg_id).c_str(),
                                          p_msg_id);
}
