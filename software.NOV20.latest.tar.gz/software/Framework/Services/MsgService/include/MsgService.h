#ifndef MsgService_h
#define MsgService_h

#include "InternalMsg.h"
#include "InternalMsgIdType.h"
#include <functional>

class MsgService
{
   public:

      typedef std::function<void(const InternalMsg*)> MethodCallbackType;

      static constexpr const char* SERVICE_NAME = "MsgService";

      MsgService() = default;
      virtual ~MsgService() = default;

      virtual void sendMsg(unsigned int p_sender_id,
                           unsigned int p_receiver_id,
                           InternalMsg* p_msg_buffer) = 0;
      virtual void subscribe(InternalMsgIdType::InternalMsgIdTypeEnum p_msg_id,
                             unsigned int p_component_id,
                             MethodCallbackType p_callback_method) = 0;
};

#endif
