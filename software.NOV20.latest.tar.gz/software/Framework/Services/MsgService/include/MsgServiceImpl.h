#ifndef MsgServiceImpl_h
#define MsgServiceImpl_h

#include "InternalMsgHeader.h"
#include "GenericBuffer.h"
#include "MsgService.h"
#include "PollingService.h"
#include "ServiceImpl.h"
#include "UnicastSocketImpl.h"
#include <list>
#include <map>
#include <memory>
#include <string>

class MsgServiceImpl : public ServiceImpl<MsgService>
{
   public:

      MsgServiceImpl(unsigned int p_service_id);
      virtual ~MsgServiceImpl() = default;

      void enable() override;
      void sendMsg(unsigned int p_sender_id,
                   unsigned int p_receiver_id,
                   InternalMsg* p_msg_buffer) override;
      void shutdown() override;
      void subscribe(InternalMsgIdType::InternalMsgIdTypeEnum p_msg_id,
                     unsigned int p_component_id,
                     MethodCallbackType p_callback_method) override;

      void run();

   protected:

      typedef std::map<InternalMsgIdType::InternalMsgIdTypeEnum, MethodCallbackType> MsgCallbackType;
      typedef std::map<unsigned int, MsgCallbackType> SubscribersType;

      const double CONNECTION_ATTEMPT_INTERVAL;

      void closeInboundNetworkConnection();
      void closeOutboundNetworkConnections();
      void createReceiveSocket();
      void createSendSockets();
      void establishInboundNetworkConnection();
      void establishOutboundNetworkConnections();
      void getPendingInboundMessages();
      bool inboundNetworkConnectionEstablished();
      bool outboundNetworkConnectionEstablished();
      void processQueuedMsg();
      void queueReceivedMsg(InternalMsg* p_msg);

      double m_time_of_last_inbound_connection_attempt;
      double m_time_of_last_outbound_connection_attempt;
      unsigned int m_polling_id;
      std::map<std::string, std::unique_ptr<UnicastSocketImpl>> m_send_socket;
      std::unique_ptr<UnicastSocketImpl> m_receive_socket;
      std::list<GenericBuffer<unsigned char>*> m_msg_queue;
      GenericBuffer<unsigned char> m_incoming_msg_buffer;
      SubscribersType m_subscribers;

};

#endif
