#include "SignalType.h"
#include <map>
#include <stdexcept>

namespace SignalType
{
   std::string enumToString(SignalType::SignalTypeEnum p_enum)
   {
      static std::map<SignalTypeEnum, std::string> enum_to_string_map =
      {
         {SignalTypeEnum::UNKNOWN, "UNKNOWN"},
         {SignalTypeEnum::BUS_ERROR, "BUS_ERROR"},
         {SignalTypeEnum::CPU_TIME_LIMIT_EXCEEDED, "CPU_TIME_LIMIT_EXCEEDED"},
         {SignalTypeEnum::FLOATING_POINT_EXCEPTION, "FLOATING_POINT_EXCEPTION"},
         {SignalTypeEnum::ILLEGAL_INSTRUCTION, "ILLEGAL_INSTRUCTION"},
         {SignalTypeEnum::INTERRUPT, "INTERRUPT"},
         {SignalTypeEnum::SEGMENTATION_FAULT, "SEGMENTATION_FAULT"},
         {SignalTypeEnum::TERMINATED, "TERMINATED"}
      };

      try
      {
         return enum_to_string_map.at(p_enum);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("SignalType::enumToString() - invalid enum (" + std::to_string(static_cast<unsigned int>(p_enum)) + ")");
      }
   }

   SignalType::SignalTypeEnum stringToEnum(const std::string& p_enum_string)
   {
      static std::map<std::string, SignalTypeEnum> string_to_enum_map =
      {
         {"UNKNOWN", SignalTypeEnum::UNKNOWN},
         {"BUS_ERROR", SignalTypeEnum::BUS_ERROR},
         {"CPU_TIME_LIMIT_EXCEEDED", SignalTypeEnum::CPU_TIME_LIMIT_EXCEEDED},
         {"FLOATING_POINT_EXCEPTION", SignalTypeEnum::FLOATING_POINT_EXCEPTION},
         {"ILLEGAL_INSTRUCTION", SignalTypeEnum::ILLEGAL_INSTRUCTION},
         {"INTERRUPT", SignalTypeEnum::INTERRUPT},
         {"SEGMENTATION_FAULT", SignalTypeEnum::SEGMENTATION_FAULT},
         {"TERMINATED", SignalTypeEnum::TERMINATED}
      };

      try
      {
         return string_to_enum_map.at(p_enum_string);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("SignalType::stringToEnum() - invalid enum string (" + p_enum_string + ")");
      }
   }
}
