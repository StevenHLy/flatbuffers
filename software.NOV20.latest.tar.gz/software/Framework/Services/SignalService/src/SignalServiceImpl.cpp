#include "SignalServiceImpl.h"
#include "ErrorService.h"
#include "LogService.h"
#include "Service.h"
#include "SigIntException.h"
#include "SigTermException.h"
#include "SystemCallException.h"
#include <cstdlib>
#include <errno.h>

bool SignalServiceImpl::m_exit_program = false;
std::mutex SignalServiceImpl::m_mutex;

SignalServiceImpl::SignalServiceImpl(unsigned int p_service_id)
: ServiceImpl<SignalService>(SignalService::SERVICE_NAME,
                             p_service_id)
, m_handled_signals()
{
   m_handled_signals.push_back(SignalType::SignalTypeEnum::FLOATING_POINT_EXCEPTION);
   m_handled_signals.push_back(SignalType::SignalTypeEnum::ILLEGAL_INSTRUCTION);
   m_handled_signals.push_back(SignalType::SignalTypeEnum::INTERRUPT);
   m_handled_signals.push_back(SignalType::SignalTypeEnum::SEGMENTATION_FAULT);
   m_handled_signals.push_back(SignalType::SignalTypeEnum::TERMINATED);
}

void SignalServiceImpl::disable()
{
   for (auto sig : m_handled_signals)
   {
      unregisterSignalHandler(sig);
   }
}

void SignalServiceImpl::enable()
{
   for (auto sig : m_handled_signals)
   {
      registerSignalHandler(sig, SignalServiceImpl::processSignal);
   }
}

bool SignalServiceImpl::exitProgram()
{
   return m_exit_program;
}

unsigned int SignalServiceImpl::myServiceId()
{
  return dynamic_cast<SignalServiceImpl&>(Service<SignalService>::getInstance()).SERVICE_ID;
}

void SignalServiceImpl::processSignal(int p_signal)
{
   std::lock_guard<std::mutex> guard(m_mutex);

   switch((SignalType::SignalTypeEnum)p_signal)
   {
      case SignalType::SignalTypeEnum::BUS_ERROR:
      case SignalType::SignalTypeEnum::CPU_TIME_LIMIT_EXCEEDED:
      case SignalType::SignalTypeEnum::FLOATING_POINT_EXCEPTION:
      case SignalType::SignalTypeEnum::ILLEGAL_INSTRUCTION:
      case SignalType::SignalTypeEnum::SEGMENTATION_FAULT:
      {
         Service<LogService>::getInstance().log(SignalServiceImpl::myServiceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::FATAL,
                                                "caught signal %u (%s), aborting application",
                                                p_signal,
                                                SignalType::enumToString(static_cast<SignalType::SignalTypeEnum>(p_signal)).c_str());

         Service<ErrorService>::getInstance().abortProcess(__FILE__,
                                                           __LINE__);

        break;
      }

      case SignalType::SignalTypeEnum::INTERRUPT:
      case SignalType::SignalTypeEnum::TERMINATED:
      {
         Service<LogService>::getInstance().log(SignalServiceImpl::myServiceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::INFO,
                                               "caught signal %u (%s), shutting down application",
                                                p_signal,
                                                SignalType::enumToString(static_cast<SignalType::SignalTypeEnum>(p_signal)).c_str());

         m_exit_program = true;

         break;
      }

      default:
      {
         Service<LogService>::getInstance().log(SignalServiceImpl::myServiceId(),
                                                __FILE__,
                                                __LINE__,
                                                LogSeverityTypeEnum::WARNING,
                                                "unregistered signal (%u) processed by signal handler, no action taken",
                                                p_signal);

         break;
      }
   }
}

void SignalServiceImpl::registerSignalHandler(SignalType::SignalTypeEnum p_signal,
                                              SigHandlerType p_handler)
{
   struct sigaction signal_action;
   sigset_t signal_mask;

   if (sigemptyset(&signal_mask) == 0)
   {
      for (auto sig : m_handled_signals)
      {
         if (sigaddset(&signal_mask, (int)sig) != 0)
         {
            throw SystemCallException(__FILE__,
                                      __LINE__,
                                      "sigaddset()");
         }
      }

      signal_action.sa_handler = p_handler;
      signal_action.sa_mask = signal_mask;
      signal_action.sa_flags = 0;

      if (sigaction((int)p_signal, &signal_action, nullptr) != 0)
      {
         throw SystemCallException(__FILE__,
                                   __LINE__,
                                   "sigaction()", errno);
      }
   }
   else
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "sigemptyset()");
   }
}

void SignalServiceImpl::unregisterSignalHandler(SignalType::SignalTypeEnum p_signal)
{
   struct sigaction signal_action;
   sigset_t signal_mask;

   if (sigemptyset(&signal_mask) == 0)
   {
      signal_action.sa_handler = SIG_DFL;
      signal_action.sa_mask = signal_mask;
      signal_action.sa_flags = 0;

      if (sigaction((int)p_signal, &signal_action, nullptr) != 0)
      {
         throw SystemCallException(__FILE__,
                                   __LINE__,
                                   "sigaction()", errno);
      }
   }
   else
   {
      throw SystemCallException(__FILE__,
                                __LINE__,
                                "sigemptyset()");
   }
}
