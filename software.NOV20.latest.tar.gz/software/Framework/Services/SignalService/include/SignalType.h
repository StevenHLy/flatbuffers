#ifndef SignalType_h
#define SignalType_h

#include <signal.h>
#include <string>

namespace SignalType
{
   enum class SignalTypeEnum : unsigned int
   {
      UNKNOWN                  = 0,
      BUS_ERROR                = SIGBUS,
      CPU_TIME_LIMIT_EXCEEDED  = SIGXCPU,
      FLOATING_POINT_EXCEPTION = SIGFPE,
      ILLEGAL_INSTRUCTION      = SIGILL,
      INTERRUPT                = SIGINT,
      SEGMENTATION_FAULT       = SIGSEGV,
      TERMINATED               = SIGTERM
   };

   std::string enumToString(SignalType::SignalTypeEnum p_enum);
   SignalType::SignalTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
