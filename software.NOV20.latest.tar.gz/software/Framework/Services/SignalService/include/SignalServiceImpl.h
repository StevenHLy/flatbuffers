#ifndef SignalServiceImpl_h
#define SignalServiceImpl_h

#include "ServiceImpl.h"
#include "SignalService.h"
#include "SignalType.h"
#include <mutex>
#include <vector>

class SignalServiceImpl : public ServiceImpl<SignalService>
{
   public:

      SignalServiceImpl(unsigned int p_service_id);
      ~SignalServiceImpl() = default;

      void disable() override;
      void enable() override;
      bool exitProgram() override;
      void registerSignalHandler(SignalType::SignalTypeEnum p_signal,
                                 SigHandlerType p_handler) override;
      void unregisterSignalHandler(SignalType::SignalTypeEnum p_signal) override;

   protected:

      static unsigned int myServiceId();
      static void processSignal(int p_signal);

      static bool m_exit_program;
      static std::mutex m_mutex;

      std::vector<SignalType::SignalTypeEnum> m_handled_signals;
};

#endif
