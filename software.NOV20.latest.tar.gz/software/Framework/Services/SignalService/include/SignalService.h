#ifndef SignalService_h
#define SignalService_h

#include "SignalType.h"

class SignalService
{
   public:

      static constexpr const char* SERVICE_NAME = "SignalService";

      typedef void(*SigHandlerType)(int);

      SignalService() = default;
      virtual ~SignalService() = default;

      virtual bool exitProgram() = 0;
      virtual void registerSignalHandler(SignalType::SignalTypeEnum p_signal,
                                         SigHandlerType p_handler) = 0;
      virtual void unregisterSignalHandler(SignalType::SignalTypeEnum p_signal) = 0;
};

#endif
