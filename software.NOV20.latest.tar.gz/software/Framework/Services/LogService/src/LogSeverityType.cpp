#include "LogSeverityType.h"
#include <map>
#include <stdexcept>

namespace LogSeverityType
{
   std::string enumToString(LogSeverityTypeEnum p_enum)
   {
      static std::map<LogSeverityTypeEnum, std::string> enum_to_string_map =
      {
         {LogSeverityTypeEnum::TRACE_LOG, "TRACE_LOG"},
         {LogSeverityTypeEnum::DEBUG, "DEBUG"},
         {LogSeverityTypeEnum::INFO, "INFO"},
         {LogSeverityTypeEnum::WARNING, "WARNING"},
         {LogSeverityTypeEnum::ERROR, "ERROR"},
         {LogSeverityTypeEnum::FATAL, "FATAL"}
      };

      try
      {
         return enum_to_string_map.at(p_enum);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("LogSeverityType::enumToString() - invalid enum (" + std::to_string(static_cast<unsigned int>(p_enum)) + ")");
      }
   }

   LogSeverityTypeEnum stringToEnum(const std::string& p_enum_string)
   {
      static std::map<std::string, LogSeverityTypeEnum> string_to_enum_map =
      {
         {"TRACE_LOG", LogSeverityTypeEnum::TRACE_LOG},
         {"DEBUG", LogSeverityTypeEnum::DEBUG},
         {"INFO", LogSeverityTypeEnum::INFO},
         {"WARNING", LogSeverityTypeEnum::WARNING},
         {"ERROR", LogSeverityTypeEnum::ERROR},
         {"FATAL", LogSeverityTypeEnum::FATAL}
      };

      try
      {
         return string_to_enum_map.at(p_enum_string);
      }
      catch (std::out_of_range const& error)
      {
         throw std::runtime_error("LogSeverityType::stringToEnum() - invalid enum string (" + p_enum_string + ")");
      }
   }
}
