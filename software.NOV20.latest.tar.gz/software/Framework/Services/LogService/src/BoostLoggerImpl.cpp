#include "BoostLoggerImpl.h"
#include "Service.h"
#include "TimeService.h"
#include <boost/filesystem.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/log/attributes.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/support/date_time.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/utility/setup/console.hpp>
#include <boost/core/null_deleter.hpp>
#include <fstream>
#include <iomanip>
#include <sstream>

BOOST_LOG_ATTRIBUTE_KEYWORD(severity, "Severity", LogSeverityTypeEnum)
BOOST_LOG_ATTRIBUTE_KEYWORD(timestamp, "TimeStamp", boost::posix_time::ptime)

BoostLoggerImpl::SeverityLogger BoostLoggerImpl::m_severity_logger;

std::ostream& operator<<(std::ostream& p_stream,
                         LogSeverityTypeEnum p_severity)
{
   static const char* strings[] = {"<TRACE>  ",
                                   "<DEBUG>  ",
                                   "<INFO>   ",
                                   "<WARNING>",
                                   "<ERROR>  ",
                                   "<FATAL>  "};

   if (static_cast<std::size_t>(p_severity) < sizeof(strings) / sizeof(*strings))
   {
      p_stream << strings[static_cast<unsigned int>(p_severity)];
   }
   else
   {
      p_stream << static_cast<unsigned int>(p_severity);
   }

   return p_stream;
}

BoostLoggerImpl::BoostLoggerImpl()
: m_text_sink_initialized(false)
{
   m_console_stream = boost::shared_ptr<std::ostream>(&std::clog, boost::null_deleter());
   m_core = boost::log::core::get();

   initializeCoreLogger();
   initializeTextFormatter();
}

BoostLoggerImpl::~BoostLoggerImpl()
{
   m_core->remove_sink(m_text_sink);
}

void BoostLoggerImpl::enableConsoleOutput(bool p_enable)
{
   if (p_enable)
   {
      m_text_sink->locked_backend()->add_stream(m_console_stream);
   }
   else
   {
      m_text_sink->locked_backend()->remove_stream(m_console_stream);
   }
}

void BoostLoggerImpl::enableFileOutput(bool p_enable)
{
}

void BoostLoggerImpl::flush()
{
   if (m_text_sink_initialized)
   {
      m_text_sink->flush();
   }
}

std::string BoostLoggerImpl::generateLogFileName(std::string p_directory,
                                                 std::string p_filename_prefix,
                                                 std::string p_filename_extension)
{
   std::ostringstream filename_buffer;
   std::stringstream date_time;
   std::time_t time_t_time_stamp(Service<TimeService>::getInstance().currentTimeSecs());
   std::tm* local_time;

   local_time = localtime(&time_t_time_stamp);

   date_time << std::setw(4) << std::setfill('0') << std::to_string(local_time->tm_year + 1900)
             << std::setw(2) << std::setfill('0') << std::to_string(local_time->tm_mon + 1)
             << std::setw(2) << std::setfill('0') << std::to_string(local_time->tm_mday)
             << "_"
             << std::setw(2) << std::setfill('0') << std::to_string(local_time->tm_hour)
             << ":"
             << std::setw(2) << std::setfill('0') << std::to_string(local_time->tm_min)
             << ":"
             << std::setw(2) << std::setfill('0') << std::to_string(local_time->tm_sec);

   filename_buffer << p_directory
                   << "/"
                   << p_filename_prefix
                   << "_"
                   << date_time.str()
                   << p_filename_extension;

   return filename_buffer.str();
}

void BoostLoggerImpl::initializeCoreLogger()
{
   boost::log::add_common_attributes();
   m_severity_logger.add_attribute("TimeStamp", boost::log::attributes::local_clock());
}

void BoostLoggerImpl::initializeTextFormatter()
{
   boost::log::formatter fmt =
      boost::log::expressions::stream << "["
                                      << boost::log::expressions::format_date_time(timestamp, "%Y-%m-%d %H:%M:%S.%f")
                                      << "] "
                                      << severity
                                      << " "
                                      << boost::log::expressions::smessage;

   m_text_sink = boost::make_shared<TextSink>();
   m_text_sink->set_formatter(fmt);
   boost::log::core::get()->add_sink(m_text_sink);

   m_text_sink_initialized = true;
}

void BoostLoggerImpl::log(const char* p_filename,
                          int p_line_number,
                          LogSeverityTypeEnum p_severity,
                          const char* p_text,
                          va_list p_args)
{
   char va_list_string[1024] = {0};
   char final_log_text[2048] = {0};
   boost::filesystem::path file_path(p_filename);

   vsnprintf(va_list_string, sizeof(va_list_string) - 1, p_text, p_args);

   sprintf(final_log_text,
           "[%s:%u] : %s",
           file_path.filename().string().c_str(),
           p_line_number,
           va_list_string);

   BOOST_LOG_SEV(m_severity_logger, p_severity) << final_log_text;
}

void BoostLoggerImpl::setFilterLevel(LogSeverityTypeEnum p_log_severity)
{
   boost::log::core::get()->set_filter(severity >= p_log_severity);
}

void BoostLoggerImpl::setOutputFile(std::string p_directory,
                                    std::string p_filename_prefix,
                                    std::string p_filename_extension)
{
   std::string full_file_name = generateLogFileName(p_directory,
                                                    p_filename_prefix,
                                                    p_filename_extension);

   boost::filesystem::path boost_dir(p_directory);
   boost::filesystem::create_directory(boost_dir);

   boost::shared_ptr<std::ofstream> file_stream = boost::make_shared<std::ofstream>(full_file_name.c_str());
   m_text_sink->locked_backend()->add_stream(file_stream);
   m_text_sink->locked_backend()->auto_flush(true);
}
