#include "LogServiceImpl.h"
#include "BoostLoggerImpl.h"
#include "ConfigParameters.h"
#include <iostream>
#include <stdarg.h>
#include <string.h>

LogServiceImpl::LogServiceImpl(unsigned int p_service_id)
: ServiceImpl<LogService>(LogService::SERVICE_NAME,
                          p_service_id)
, m_logging_enabled(ConfigParameters::getInstance().getParam<bool>("LogService.Logging_Enabled"))
, m_console_output_enabled(ConfigParameters::getInstance().getParam<bool>("LogService.Console_Output_Enabled"))
, m_file_output_enabled(ConfigParameters::getInstance().getParam<bool>("LogService.File_Output_Enabled"))
, m_logging_filter()
, m_logger(new BoostLoggerImpl())
, m_log_file_directory(ConfigParameters::getInstance().getParam<std::string>("LogService.Log_File_Directory"))
, m_log_file_name_extension(ConfigParameters::getInstance().getParam<std::string>("LogService.Log_File_Name_Extension"))
, m_log_file_name_prefix(ConfigParameters::getInstance().getParam<std::string>("LogService.Log_File_Name_Prefix"))
{
}

LogServiceImpl::~LogServiceImpl()
{
   flush();
}

void LogServiceImpl::enable()
{
   m_logger->enableConsoleOutput(m_console_output_enabled);
   m_logger->enableFileOutput(m_file_output_enabled);
   m_logger->setOutputFile(m_log_file_directory,
                           m_log_file_name_prefix,
                           m_log_file_name_extension);
   m_logger->setFilterLevel(LogSeverityTypeEnum::TRACE_LOG);
}

void LogServiceImpl::flush()
{
   std::lock_guard<std::mutex> guard(m_mutex);

   m_logger->flush();
}

bool LogServiceImpl::isConsoleOutputEnabled()
{
   return m_console_output_enabled;
}

bool LogServiceImpl::isFileOutputEnabled()
{
   return m_file_output_enabled;
}

bool LogServiceImpl::isLoggingEnabled()
{
   return m_logging_enabled;
}

bool LogServiceImpl::isLoggingEnabled(unsigned int p_requester_id,
                                      LogSeverityTypeEnum p_severity)
{
   bool severity_logging_enabled = false;
   LogFilterData const& logging_filter_item = m_logging_filter[p_requester_id];

   switch (p_severity)
   {
      case LogSeverityTypeEnum::TRACE_LOG :
      {
         if (logging_filter_item.m_trace_enabled)
         {
            severity_logging_enabled = true;
         }

         break;
      }

      case LogSeverityTypeEnum::DEBUG :
      {
         if (logging_filter_item.m_debug_enabled)
         {
            severity_logging_enabled = true;
         }

         break;
      }

      case LogSeverityTypeEnum::INFO :
      {
         if (logging_filter_item.m_info_enabled)
         {
            severity_logging_enabled = true;
         }

         break;
      }

      case LogSeverityTypeEnum::WARNING :
      {
         if (logging_filter_item.m_warning_enabled)
         {
            severity_logging_enabled = true;
         }

         break;
      }

      case LogSeverityTypeEnum::ERROR :
      {
         if (logging_filter_item.m_error_enabled)
         {
            severity_logging_enabled = true;
         }

         break;
      }

      case LogSeverityTypeEnum::FATAL :
      {
         if (logging_filter_item.m_fatal_enabled)
         {
            severity_logging_enabled = true;
         }

         break;
      }

      default:
      {
         break;
      }
   }

   return(isLoggingEnabled() && severity_logging_enabled);
}

void LogServiceImpl::log(unsigned int p_requester_id,
                         const char* p_filename,
                         int p_line_number,
                         LogSeverityTypeEnum p_severity,
                         const char* p_text,
                         ...)
{
   std::lock_guard<std::mutex> guard(m_mutex);

   if (isLoggingEnabled(p_requester_id, p_severity))
   {
      va_list args;
      va_start(args, p_text);

      m_logger->log(p_filename,
                    p_line_number,
                    p_severity,
                    p_text,
                    args);

      va_end(args);
   }
}

void LogServiceImpl::registerRequester(std::string p_requester_name,
                                       unsigned int p_requester_id)
{
   LogFilterData& logging_filter_item = m_logging_filter[p_requester_id];

   logging_filter_item.m_requester_id = p_requester_id;
   logging_filter_item.m_requester_name = p_requester_name;
   logging_filter_item.m_trace_enabled = ConfigParameters::getInstance().getParam<bool>(p_requester_name + ".LoggingFilter.Trace_Enabled", false);
   logging_filter_item.m_debug_enabled = ConfigParameters::getInstance().getParam<bool>(p_requester_name + ".LoggingFilter.Debug_Enabled", false);
   logging_filter_item.m_info_enabled = ConfigParameters::getInstance().getParam<bool>(p_requester_name + ".LoggingFilter.Info_Enabled", false);
   logging_filter_item.m_warning_enabled = ConfigParameters::getInstance().getParam<bool>(p_requester_name + ".LoggingFilter.Warning_Enabled", false);
   logging_filter_item.m_error_enabled = ConfigParameters::getInstance().getParam<bool>(p_requester_name + ".LoggingFilter.Error_Enabled", false);
   logging_filter_item.m_fatal_enabled = ConfigParameters::getInstance().getParam<bool>(p_requester_name + ".LoggingFilter.Fatal_Enabled", false);
}
