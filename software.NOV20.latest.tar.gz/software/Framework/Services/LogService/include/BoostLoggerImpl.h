#ifndef BoostLoggerImpl_h
#define BoostLoggerImpl_h

#include "Logger.h"
#include "LogSeverityType.h"
#include <boost/format.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/log/sinks/sync_frontend.hpp>
#include <boost/log/sinks/text_ostream_backend.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <string>

std::ostream& operator<<(std::ostream& p_stream,
                         LogSeverityTypeEnum p_severity);

class BoostLoggerImpl : public Logger
{
   public:

      BoostLoggerImpl();
      virtual ~BoostLoggerImpl();

      void enableConsoleOutput(bool p_enable) override;
      void enableFileOutput(bool p_enable) override;
      void flush() override;
      void log(const char* p_filename,
               int p_line_number,
               LogSeverityTypeEnum p_severity,
               const char* p_text,
               va_list p_args) override;
      void setFilterLevel(LogSeverityTypeEnum p_severity) override;
      void setOutputFile(std::string p_directory,
                         std::string p_filename_prefix,
                         std::string p_filename_extension) override;

   private:

      typedef boost::log::sources::severity_logger<LogSeverityTypeEnum> SeverityLogger;
      typedef boost::log::sinks::synchronous_sink<boost::log::sinks::text_ostream_backend> TextSink;

      static SeverityLogger m_severity_logger;

      std::string generateLogFileName(std::string p_directory,
                                      std::string p_filename_prefix,
                                      std::string p_filename_extension);
      void initializeCoreLogger();
      void initializeTextFormatter();

      bool m_text_sink_initialized;
      boost::shared_ptr<std::ostream> m_console_stream;
      boost::shared_ptr<boost::log::core> m_core;
      boost::shared_ptr<TextSink> m_text_sink;
};

#endif
