#ifndef LogSeverityType_h
#define LogSeverityType_h

#include <string>

// ********************************************************************
// this enum class cannot be in a namespace in order to work with BOOST
// ********************************************************************
enum class LogSeverityTypeEnum : unsigned int
{
   TRACE_LOG = 0,
   DEBUG     = 1,
   INFO      = 2,
   WARNING   = 3,
   ERROR     = 4,
   FATAL     = 5
};

namespace LogSeverityType
{
   std::string enumToString(LogSeverityTypeEnum p_enum);
   LogSeverityTypeEnum stringToEnum(const std::string& p_enum_string);
}

#endif
