#ifndef LogServiceImpl_h
#define LogServiceImpl_h

#include "Logger.h"
#include "LogService.h"
#include "LogSeverityType.h"
#include "ServiceImpl.h"
#include <map>
#include <memory>
#include <mutex>
#include <string>

class LogServiceImpl : public ServiceImpl<LogService>
{
    public:

       LogServiceImpl(unsigned int p_service_id);
       ~LogServiceImpl();

       void enable() override;
       void flush() override;
       bool isConsoleOutputEnabled() override;
       bool isFileOutputEnabled() override;
       bool isLoggingEnabled() override;
       bool isLoggingEnabled(unsigned int p_requester_id,
                             LogSeverityTypeEnum p_severity) override;
       void log(unsigned int p_requester_id,
                const char* p_filename,
                int p_line_number,
                LogSeverityTypeEnum p_severity,
                const char* p_text,
                ...) override;
       void registerRequester(std::string p_requester_name,
                              unsigned int p_requester_id) override;

    protected:

       static const int TEXT_BUFFER_LENGTH_BYTES = 1024;

       struct LogFilterData
       {
          bool m_trace_enabled;
          bool m_debug_enabled;
          bool m_info_enabled;
          bool m_warning_enabled;
          bool m_error_enabled;
          bool m_fatal_enabled;
          std::string m_requester_name;
          unsigned int m_requester_id;

          LogFilterData()
          : m_trace_enabled(false)
          , m_debug_enabled(false)
          , m_info_enabled(false)
          , m_warning_enabled(false)
          , m_error_enabled(false)
          , m_fatal_enabled(false)
          , m_requester_name("")
          , m_requester_id(0)
          {}
       };

       bool m_logging_enabled;
       bool m_console_output_enabled;
       bool m_file_output_enabled;
       char m_text_buffer[TEXT_BUFFER_LENGTH_BYTES];
       std::map<unsigned int, LogFilterData> m_logging_filter;
       std::mutex m_mutex;
       std::string m_log_file_directory;
       std::string m_log_file_name_extension;
       std::string m_log_file_name_prefix;
       std::unique_ptr<Logger> m_logger;
};

#endif
