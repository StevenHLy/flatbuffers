#ifndef LogService_h
#define LogService_h

#include "LogSeverityType.h"
#include <string>

class LogService
{
   public:

      static constexpr const char* SERVICE_NAME = "LogService";

      LogService() = default;
      virtual ~LogService() = default;

      virtual void flush() = 0;
      virtual bool isConsoleOutputEnabled() = 0;
      virtual bool isFileOutputEnabled() = 0;
      virtual bool isLoggingEnabled() = 0;
      virtual bool isLoggingEnabled(unsigned int p_requester_id,
                                    LogSeverityTypeEnum p_severity) = 0;
      virtual void log(unsigned int p_requester_id,
                       const char* p_filename,
                       int p_line_number,
                       LogSeverityTypeEnum p_severity,
                       const char* p_text,
                       ...) = 0;
      virtual void registerRequester(std::string p_requester_name,
                                     unsigned int p_requester_id) = 0;
};

#endif
