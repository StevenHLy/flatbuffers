#ifndef Logger_h
#define Logger_h

#include "LogSeverityType.h"
#include <stdio.h>
#include <string>

class Logger
{
   public:

      Logger() = default;
      virtual ~Logger() = default;

      virtual void enableConsoleOutput(bool p_enable) = 0;
      virtual void enableFileOutput(bool p_enable) = 0;
      virtual void flush() = 0;
      virtual void log(const char* p_filename,
                       int p_line_number,
                       LogSeverityTypeEnum p_severity,
                       const char* p_text,
                       va_list p_args) = 0;
      virtual void setOutputFile(std::string p_directory,
                                 std::string p_filename_prefix,
                                 std::string p_filename_extension) = 0;
      virtual void setFilterLevel(LogSeverityTypeEnum p_severity) = 0;
};

#endif
