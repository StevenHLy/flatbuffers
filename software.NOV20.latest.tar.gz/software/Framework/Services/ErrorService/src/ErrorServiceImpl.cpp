#include "ErrorServiceImpl.h"
#include "ConfigParameters.h"
#include "AbortProcessException.h"
#include "LogService.h"
#include "Service.h"
#include <cstdio>
#include <cstdlib>
#include <cxxabi.h>
#include <execinfo.h>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <unistd.h>

ErrorServiceImpl::ErrorServiceImpl(unsigned int p_service_id)
: ServiceImpl<ErrorService>(ErrorService::SERVICE_NAME,
                            p_service_id)
, m_abort_on_fatal(ConfigParameters::getInstance().getParam<bool>("ErrorService.Abort_On_Fatal"))
, m_mutex()
{
}

void ErrorServiceImpl::abortProcess(const char* p_filename,
                                    int p_line_number)
{
   std::lock_guard<std::mutex> guard(m_mutex);

   recordBacktrace(__FILE__,
                   __LINE__,
                   "*** Begin recording backtrace ***");

   recordBacktrace(p_filename,
                   p_line_number);

   recordBacktrace(__FILE__,
                   __LINE__,
                   "*** End recording backtrace ***");

   Service<LogService>::getInstance().flush();

   if (m_abort_on_fatal)
   {
      abort();
   }
   else
   {
      throw AbortProcessException(__FILE__,
                                  __LINE__);
   }
}

void ErrorServiceImpl::backtraceViaAbi(const char* filename,
                                       int line,
                                       int addr_len,
                                       void* addrlist[BACKTRACE_MAX_DEPTH])
{
   char** symbollist;
   if ((symbollist = backtrace_symbols(addrlist, addr_len)) != NULL)
   {
      for (int i = 0; i < addr_len; i++)
      {
         size_t funcnamesize = 256;
         char* funcname = static_cast<char*>(malloc(funcnamesize));
         char *begin_name = 0, *begin_offset = 0, *end_offset = 0;

         for (char* j = symbollist[i]; *j; ++j)
         {
            if (*j == '(')
            {
               begin_name = j;
            }
            else if (*j == '+')
            {
               begin_offset = j;
            }
            else if (*j == ')' && begin_offset)
            {
               end_offset = j;
               break;
            }
         }

         char final_string[512];
         if (begin_name && begin_offset && end_offset && begin_name < begin_offset)
         {
            *begin_name++ = '\0';
            *begin_offset++ = '\0';
            *end_offset++ = '\0';

            int status;
            char* ret = abi::__cxa_demangle(begin_name, funcname, &funcnamesize, &status);
            if (status == 0)
            {
               funcname = ret;
               sprintf(final_string, "%s : %s+%s", symbollist[i], funcname, begin_offset);
            }
            else
            {
               sprintf(final_string, "%s : %s()+%s", symbollist[i], begin_name, begin_offset);
            }
         }
         else
         {
            sprintf(final_string, "%s", symbollist[i]);
         }

         recordBacktrace(filename,
                         line,
                         final_string);

         free(funcname);
      }

      free(symbollist);
   }
   else
   {
      recordBacktrace(__FILE__, __LINE__, "*** Error converting backtrace addresses to strings ***");
   }
}

const char* ErrorServiceImpl::buildCommandLine(int addr_len,
                                               void *addr_list[BACKTRACE_MAX_DEPTH])
{
   snprintf(m_backtrace_cmd_line_buf, 14, "addr2line -e ");
   size_t buf_offset = strlen(m_backtrace_cmd_line_buf);
   size_t remaining_buffer = BACKTRACE_CMD_MAX_LEN - buf_offset;

   ssize_t exe_name_length = readlink("/proc/self/exe", m_backtrace_cmd_line_buf + buf_offset, remaining_buffer);
   if (exe_name_length != -1 && exe_name_length < static_cast<ssize_t>(remaining_buffer))
   {
      buf_offset += exe_name_length;
      remaining_buffer = BACKTRACE_CMD_MAX_LEN - buf_offset;

      for (int i = 0; i < addr_len; ++i)
      {
         int addr_size = snprintf(m_backtrace_cmd_line_buf + buf_offset, remaining_buffer, " %p", addr_list[i]);
         if (addr_size > static_cast<int>(remaining_buffer))
         {
           break;
         }

         buf_offset += addr_size;
         remaining_buffer = BACKTRACE_CMD_MAX_LEN - buf_offset;
      }

      m_backtrace_cmd_line_buf[buf_offset] = 0;
   }
   else
   {
      return nullptr;
   }

   return m_backtrace_cmd_line_buf;
}

void ErrorServiceImpl::recordBacktrace(const char* p_filename,
                                       int p_line_number)
{
   void *addrlist[BACKTRACE_MAX_DEPTH];

   int addrlen = 0;
   if ((addrlen = backtrace(addrlist, BACKTRACE_MAX_DEPTH)) > 0)
   {
      backtraceViaAbi(p_filename, p_line_number, addrlen, addrlist);

      const char *command_line = buildCommandLine(addrlen, addrlist);
      if (command_line != nullptr)
      {
         recordBacktrace(p_filename,
                         p_line_number,
                         "A potentially more readable backtrace may be available by running: ");

         recordBacktrace(p_filename,
                         p_line_number,
                         command_line);
      }
   }
   else
   {
      recordBacktrace(__FILE__,
                      __LINE__,
                      "*** No backtrace entries found ***");
   }
}

void ErrorServiceImpl::recordBacktrace(const char* p_filename,
                                       int p_line_number,
                                       const char* p_text)
{
   Service<LogService>::getInstance().log(serviceId(),
                                          p_filename,
                                          p_line_number,
                                          LogSeverityTypeEnum::FATAL,
                                          p_text);
}
