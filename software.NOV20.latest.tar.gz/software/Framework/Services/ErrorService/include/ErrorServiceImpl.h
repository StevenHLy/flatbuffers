#ifndef ErrorServiceImpl_h
#define ErrorServiceImpl_h

#include "ErrorService.h"
#include "ServiceImpl.h"
#include <mutex>

class ErrorServiceImpl : public ServiceImpl<ErrorService>
{
   public:

      ErrorServiceImpl(unsigned int p_service_id);
      virtual ~ErrorServiceImpl() = default;

      void abortProcess(const char* p_filename,
                        int p_line_number) override;

   protected:

      static const int BACKTRACE_CMD_MAX_LEN = 2048;
      static const int BACKTRACE_MAX_DEPTH = 100;

      void backtraceViaAbi(const char* filename,
                           int line,
                           int addr_len,
                           void* addrlist[BACKTRACE_MAX_DEPTH]);
      const char* buildCommandLine(int addr_len,
                                   void *addr_list[BACKTRACE_MAX_DEPTH]);
      void recordBacktrace(const char* p_filename,
                           int p_line_number);
      void recordBacktrace(const char* p_filename,
                           int p_line_number,
                           const char* p_text);


      bool m_abort_on_fatal;
      char m_backtrace_cmd_line_buf[BACKTRACE_CMD_MAX_LEN];
      std::mutex m_mutex;
};

#endif
