#ifndef ErrorService_h
#define ErrorService_h

class ErrorService
{
   public:

      static constexpr const char* SERVICE_NAME = "ErrorService";

      ErrorService() = default;
      virtual ~ErrorService() = default;

      virtual void abortProcess(const char* p_filename,
                                int p_line_number) = 0;
};

#endif
