#include "PollingServiceImpl.h"
#include "LogService.h"
#include "PollingIdNotRegisteredException.h"
#include "Service.h"

PollingServiceImpl::PollingServiceImpl(unsigned int p_service_id)
: ServiceImpl<PollingService>(PollingService::SERVICE_NAME,
                              p_service_id)
, m_mutex()
, m_polling_id_generator()
, m_callbacks()
{
}

void PollingServiceImpl::disableCallback(unsigned int p_polling_id)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   if (p_polling_id < m_callbacks.size())
   {
      m_callbacks[p_polling_id].m_enabled = false;
   }
   else
   {
      throw PollingIdNotRegisteredException(__FILE__,
                                            __LINE__,
                                            p_polling_id);
   }
}

void PollingServiceImpl::enableCallback(unsigned int p_polling_id)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   if (p_polling_id < m_callbacks.size())
   {
      m_callbacks[p_polling_id].m_enabled = true;
   }
   else
   {
      throw PollingIdNotRegisteredException(__FILE__,
                                            __LINE__,
                                            p_polling_id);
   }
}

bool PollingServiceImpl::isCallbackEnabled(unsigned int p_polling_id)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   if (not(p_polling_id < m_callbacks.size()))
   {
      throw PollingIdNotRegisteredException(__FILE__,
                                            __LINE__,
                                            p_polling_id);
   }
   else
   {
      return (m_callbacks[p_polling_id].m_enabled);
   }
}

bool PollingServiceImpl::isCallbackRegistered(unsigned int p_polling_id)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   if (not(p_polling_id < m_callbacks.size()))
   {
      throw PollingIdNotRegisteredException(__FILE__,
                                            __LINE__,
                                            p_polling_id);
   }
   else
   {
      return(true);
   }
}

unsigned int PollingServiceImpl::registerCallback(MethodCallbackType p_callback_method)
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   unsigned int next_id = m_callbacks.size();

   m_callbacks.push_back(PollingCallbackData(next_id, p_callback_method));

   Service<LogService>::getInstance().log(serviceId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "registered polling callback id (%d)",
                                          next_id);

   return next_id;
}

void PollingServiceImpl::run()
{
   std::lock_guard<std::recursive_mutex> guard(m_mutex);

   for (auto& callback : m_callbacks)
   {
      if (callback.m_enabled)
      {
         callback.m_callback_method();
      }
   }
}
