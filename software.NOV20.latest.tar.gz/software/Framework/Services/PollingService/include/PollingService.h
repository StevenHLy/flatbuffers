#ifndef PollingService_h
#define PollingService_h

#include <functional>

class PollingService
{
   public:

      static constexpr const char* SERVICE_NAME = "PollingService";

      typedef std::function<void()> MethodCallbackType;

      PollingService() = default;
      virtual ~PollingService() = default;

      virtual void disableCallback(unsigned int p_polling_id) = 0;
      virtual void enableCallback(unsigned int p_polling_id) = 0;
      virtual bool isCallbackEnabled(unsigned int p_polling_id) = 0;
      virtual bool isCallbackRegistered(unsigned int p_polling_id) = 0;
      virtual unsigned int registerCallback(MethodCallbackType p_callback_method) = 0;
      virtual void run() = 0;
};

#endif
