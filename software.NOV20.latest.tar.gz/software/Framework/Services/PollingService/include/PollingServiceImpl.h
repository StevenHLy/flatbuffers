#ifndef PollingServiceImpl_h
#define PollingServiceImpl_h

#include "IdGenerator.h"
#include "PollingService.h"
#include "ServiceImpl.h"
#include <mutex>
#include <vector>

class PollingServiceImpl : public ServiceImpl<PollingService>
{
   public:

      PollingServiceImpl(unsigned int p_service_id);
      virtual ~PollingServiceImpl() = default;

      void disableCallback(unsigned int p_polling_id) override;
      void enableCallback(unsigned int p_polling_id) override;
      bool isCallbackEnabled(unsigned int p_polling_id) override;
      bool isCallbackRegistered(unsigned int p_polling_id) override;
      unsigned int registerCallback(MethodCallbackType p_callback_method) override;
      void run() override;

   protected:

      struct PollingCallbackData
      {
         unsigned int m_polling_id;
         bool m_enabled;
         MethodCallbackType m_callback_method;

         PollingCallbackData(unsigned int p_polling_id,
                             MethodCallbackType p_callback_method)
         : m_polling_id(p_polling_id)
         , m_enabled(false)
         , m_callback_method(p_callback_method)
         {
         }
      };

      typedef std::vector<PollingCallbackData> PollingCallbacksType;

      std::recursive_mutex m_mutex;
      IdGenerator<unsigned int> m_polling_id_generator;
      PollingCallbacksType m_callbacks;
};

#endif
