#include "ApplicationServiceImpl.h"
#include <limits.h>
#include <string>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <unistd.h>

ApplicationServiceImpl::ApplicationServiceImpl(unsigned int p_service_id)
: ServiceImpl<ApplicationService>(ApplicationService::SERVICE_NAME,
                                  p_service_id)
, m_executable("")
{
   char executable[PATH_MAX] = {0};

   readlink("/proc/self/exe", executable, PATH_MAX);
   m_executable = std::string(executable);
}

std::string ApplicationServiceImpl::executable()
{
   return m_executable;
}

int ApplicationServiceImpl::pid()
{
   return getpid();
}

int ApplicationServiceImpl::threadId()
{
   return syscall(SYS_gettid);
}
