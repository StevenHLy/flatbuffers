#ifndef ApplicationService_h
#define ApplicationService_h

#include <string>

class ApplicationService
{
   public:

      static constexpr const char* SERVICE_NAME = "ApplicationService";

      ApplicationService() = default;
      virtual ~ApplicationService() = default;

      virtual std::string executable() = 0;
      virtual int pid() = 0;
      virtual int threadId() = 0;
};

#endif
