#ifndef ApplicationServiceImpl_h
#define ApplicationServiceImpl_h

#include "ApplicationService.h"
#include "ServiceImpl.h"

class ApplicationServiceImpl : public ServiceImpl<ApplicationService>
{
   public:

      ApplicationServiceImpl(unsigned int p_service_id);
      virtual ~ApplicationServiceImpl() = default;

      virtual std::string executable() override;
      virtual int pid() override;
      virtual int threadId() override;

   protected:

      std::string m_executable;
};

#endif
