#include "DscServiceManager.h"
#include "ApplicationService.h"
#include "ApplicationServiceImpl.h"
#include "DscFramework.h"
#include "ErrorService.h"
#include "ErrorServiceImpl.h"
#include "HeartbeatService.h"
#include "HeartbeatServiceImpl.h"
#include "LogService.h"
#include "LogServiceImpl.h"
#include "MsgService.h"
#include "MsgServiceImpl.h"
#include "NodeService.h"
#include "NodeServiceImpl.h"
#include "PollingService.h"
#include "PollingServiceImpl.h"
#include "SignalService.h"
#include "SignalServiceImpl.h"
#include "TimerService.h"
#include "TimerServiceImpl.h"
#include "TimeService.h"
#include "TimeServiceImpl.h"

DscServiceManager::ServiceWrapper::ServiceWrapper(std::string p_service_name,
                                                  unsigned int p_service_id)
: m_service_name(p_service_name)
, m_service_id(p_service_id)
{
}

DscServiceManager::DscServiceManager(DscFramework& p_component_handle)
: m_service_pool()
, m_component_handle(p_component_handle)
{
}

void DscServiceManager::createServices()
{
   for (auto& item : m_service_pool)
   {
      item.second->createService();
   }
}

void DscServiceManager::disableServices()
{
   for (auto& item : m_service_pool)
   {
      item.second->disableService();
   }
}

void DscServiceManager::enableServices()
{
   for (auto& item : m_service_pool)
   {
      item.second->enableService();
   }
}

void DscServiceManager::initializeServices()
{
   for (auto& item : m_service_pool)
   {
      item.second->initializeService();
   }

   for (auto& item : m_service_pool)
   {
      Service<LogService>::getInstance().registerRequester(item.second->m_service_name,
                                                           item.second->m_service_id);
   }
}

void DscServiceManager::registerServices()
{
   addServiceItem<ApplicationService, ApplicationServiceImpl>();
   addServiceItem<ErrorService, ErrorServiceImpl>();
   addServiceItem<HeartbeatService, HeartbeatServiceImpl>();
   addServiceItem<LogService, LogServiceImpl>();
   addServiceItem<MsgService, MsgServiceImpl>();
   addServiceItem<NodeService, NodeServiceImpl>();
   addServiceItem<PollingService, PollingServiceImpl>();
   addServiceItem<SignalService, SignalServiceImpl>();
   addServiceItem<TimerService, TimerServiceImpl>();
   addServiceItem<TimeService, TimeServiceImpl>();
}

void DscServiceManager::shutdownServices()
{
   for (auto& item : m_service_pool)
   {
      item.second->shutdownService();
   }
}
