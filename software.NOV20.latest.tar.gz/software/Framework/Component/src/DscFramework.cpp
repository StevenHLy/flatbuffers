#include "DscFramework.h"
#include "ApplicationService.h"
#include "ConfigParameters.h"
#include "DscException.h"
#include "LogService.h"
#include "NodeService.h"
#include "PollingService.h"
#include "Service.h"
#include "SignalService.h"
#include "TimerService.h"

DscFramework::DscFramework()
: FRAMEWORK_ID(ConfigParameters::getInstance().getRequiredParam<unsigned int>("MasterModuleList.Framework.Module_Id"))
, m_component_mgr(nullptr)
, m_service_mgr(nullptr)
{
}

std::unique_ptr<DscComponentManager>& DscFramework::componentManager()
{
   return m_component_mgr;
}

void DscFramework::createComponents()
{
   componentManager()->createComponents();
}

void DscFramework::createServices()
{
   serviceManager()->createServices();
}

void DscFramework::disableServices()
{
   serviceManager()->disableServices();
}

void DscFramework::enableServices()
{
   serviceManager()->enableServices();
}

unsigned int DscFramework::frameworkId()
{
   return FRAMEWORK_ID;
}

std::string DscFramework::frameworkName()
{
   return FRAMEWORK_NAME;
}

void DscFramework::initialize()
{
   createServiceManager<DscServiceManager>();
   createComponentManager<DscComponentManager>();
   registerServices();
   createServices();
   initializeServices();
   enableServices();
   Service<LogService>::getInstance().registerRequester(frameworkName(),
                                                        frameworkId());
   logProgramInfo();
   registerComponents();
   createComponents();
   initializeComponents();
}

void DscFramework::initializeComponents()
{
   componentManager()->initializeComponents();
}

void DscFramework::initializeServices()
{
   serviceManager()->initializeServices();
}

void DscFramework::logProgramInfo()
{
   std::ostringstream program_info;

   program_info << std::endl
                << "=====================================================" << std::endl
                << "DSC program info" << std::endl
                << "=====================================================" << std::endl
                << "executable      = " << Service<ApplicationService>::getInstance().executable() << std::endl
                << "host name       = " << Service<NodeService>::getInstance().localNodeName() << std::endl
                << "process id      = " << Service<ApplicationService>::getInstance().pid() << std::endl
                << "main thread id  = " << Service<ApplicationService>::getInstance().threadId() << std::endl
                << "====================================================" << std::endl;

   Service<LogService>::getInstance().log(frameworkId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "%s",
                                          program_info.str().c_str());
}

void DscFramework::registerComponents()
{
   componentManager()->registerComponents();
}

void DscFramework::registerServices()
{
   serviceManager()->registerServices();
}

void DscFramework::run()
{
   try
   {
      Service<LogService>::getInstance().log(frameworkId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::INFO,
                                             "starting DSC polling loop");

      while (not Service<SignalService>::getInstance().exitProgram())
      {
         Service<TimerService>::getInstance().run();
         Service<PollingService>::getInstance().run();
         sched_yield();
      }

      Service<LogService>::getInstance().log(frameworkId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::INFO,
                                             "exiting DSC polling loop");
   }
   catch(DscException const& e_ssrsim)
   {
      Service<LogService>::getInstance().log(frameworkId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::FATAL,
                                             "caught a DscException (%s), exiting polling loop",
                                             e_ssrsim.what());
   }
   catch(std::exception const& e_std)
   {
      Service<LogService>::getInstance().log(frameworkId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::FATAL,
                                             "caught a std::exception (%s), exiting polling loop",
                                             e_std.what());
   }

   Service<LogService>::getInstance().log(frameworkId(),
                                          __FILE__,
                                          __LINE__,
                                          LogSeverityTypeEnum::INFO,
                                          "shutting down application");
}

std::unique_ptr<DscServiceManager>& DscFramework::serviceManager()
{
   return m_service_mgr;
}

void DscFramework::shutdown()
{
   shutdownComponents();
   disableServices();
   shutdownServices();
}

void DscFramework::shutdownComponents()
{
   componentManager()->shutdownComponents();
}

void DscFramework::shutdownServices()
{
   serviceManager()->shutdownServices();
}
