#include "DscComponentManager.h"
#include "DiscoGuiBoundaryComponent.h"
#include "Blding142PlatformSimulatorComponent.h"
#include "Blding142PlatformTranslatorComponent.h"
#include "ConfigParameters.h"
#include "DistributedCoordinatorComponent.h"
#include "DscFramework.h"
#include "LogService.h"
#include "PlatformServicesComponent.h"
#include "TrackerBoundaryComponent.h"

DscComponentManager::ComponentCreator::ComponentCreator(std::string p_component_name,
                                                        unsigned int p_component_id)
: m_component_name(p_component_name)
, m_component_id(p_component_id)
{
}

DscComponentManager::DscComponentManager(DscFramework& p_component_handle)
: m_component_creator_map()
, m_allocated_component_map()
, m_component_handle(p_component_handle)
{
}

void DscComponentManager::createComponents()
{
   for (auto& component : m_component_creator_map)
   {
      m_allocated_component_map[component.first] = m_component_creator_map.at(component.first)->createComponent();

      Service<LogService>::getInstance().log(m_component_handle.frameworkId(),
                                             __FILE__,
                                             __LINE__,
                                             LogSeverityTypeEnum::INFO,
                                             "Creating component %s (%d)",
                                             component.second->m_component_name.c_str(),
                                             component.second->m_component_id);
   }
}

void DscComponentManager::initializeComponents()
{
   for (auto& component : m_allocated_component_map)
   {
      component.second->initializeComponent();
   }
}

void DscComponentManager::registerComponents()
{
   addComponentItem<DistributedCoordinatorComponent>();
   addComponentItem<PlatformServicesComponent>();
   addComponentItem<Blding142PlatformTranslatorComponent>();
   addComponentItem<Blding142PlatformSimulatorComponent>();
   addComponentItem<TrackerBoundaryComponent>();
   addComponentItem<DiscoGuiBoundaryComponent>();
}

void DscComponentManager::shutdownComponents()
{
   for (auto& component : m_allocated_component_map)
   {
      component.second->shutdownComponent();
   }

   m_allocated_component_map.clear();
}
