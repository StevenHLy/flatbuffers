#ifndef DscComponentManager_h
#define DscComponentManager_h

#include "ConfigParameters.h"
#include "DscApplicationComponent.h"
#include "NodeService.h"
#include "Service.h"
#include <functional>
#include <map>
#include <memory>
#include <string>

class DscFramework;

class DscComponentManager
{
   public:

      DscComponentManager(DscFramework& p_component_handle);
      ~DscComponentManager() = default;

      void createComponents();
      void initializeComponents();
      void registerComponents();
      void shutdownComponents();

   protected:

      class ComponentCreator
      {
         public:

            ComponentCreator(std::string p_component_name,
                             unsigned int p_component_id);
            virtual ~ComponentCreator() = default;

            virtual std::shared_ptr<DscApplicationComponent> createComponent() = 0;

            unsigned int m_component_id;
            std::string m_component_name;
      };

      template<typename ComponentType>
      class ComponentCreatorImpl : public ComponentCreator
      {
         public:

            template<typename... Args> ComponentCreatorImpl(std::string p_component_name,
                                                            unsigned int p_component_id,
                                                            Args&&... p_args);
            virtual ~ComponentCreatorImpl() = default;

            std::shared_ptr<DscApplicationComponent> createComponent() override;

         protected:

            std::function<std::shared_ptr<DscApplicationComponent>()> m_create_component_callback;
      };

      template<typename ComponentType, typename... Args> void addComponent(std::string p_component_name,
                                                                           unsigned int p_component_id,
                                                                           Args&&... p_args);
      template<typename ComponentType> void addComponentItem();
      template<typename ComponentType, typename... Args> void addComponentItem(Args&&... p_args);

      std::map<unsigned int, std::shared_ptr<DscApplicationComponent>> m_allocated_component_map;
      std::map<unsigned int, std::unique_ptr<ComponentCreator>> m_component_creator_map;
      DscFramework& m_component_handle;
};

template<typename ComponentType, typename... Args>
void DscComponentManager::addComponent(std::string p_component_name,
                                       unsigned int p_component_id,
                                       Args&&... p_args)
{
   std::string local_node_name = Service<NodeService>::getInstance().localNodeName();

   if (Service<NodeService>::getInstance().componentAllocatedToNode(p_component_name, local_node_name))
   {
      m_component_creator_map[p_component_id].reset(new ComponentCreatorImpl<ComponentType>(p_component_name,
                                                                                            p_component_id,
                                                                                            std::forward<Args>(p_args)...));
   }
}

template<typename ComponentType>
void DscComponentManager::addComponentItem()
{
   unsigned int component_id = ConfigParameters::getInstance().getRequiredParam<unsigned int>("MasterModuleList." + std::string(ComponentType::COMPONENT_NAME) + ".Module_Id");

   addComponent<ComponentType>(std::string(ComponentType::COMPONENT_NAME),
                               component_id);
}

template<typename ComponentType, typename... Args>
void DscComponentManager::addComponentItem(Args&&... p_args)
{
   unsigned int component_id = ConfigParameters::getInstance().getRequiredParam<unsigned int>("MasterModuleList." + std::string(ComponentType::COMPONENT_NAME) + ".Module_Id");

   addComponent<ComponentType>(std::string(ComponentType::COMPONENT_NAME),
                               component_id,
                               std::forward<Args>(p_args)...);
}

template<typename ComponentType>
template<typename... Args>
DscComponentManager::ComponentCreatorImpl<ComponentType>::ComponentCreatorImpl(std::string p_component_name,
                                                                               unsigned int p_component_id,
                                                                               Args&&... p_args)
: ComponentCreator(p_component_name, p_component_id)
{
   m_create_component_callback = ([this, p_component_id, p_args...]()
   {
      std::shared_ptr<DscApplicationComponent> component(new ComponentType(p_component_id,
                                                                           p_args...));

      return component;
   });
}

template<typename ComponentType>
std::shared_ptr<DscApplicationComponent> DscComponentManager::ComponentCreatorImpl<ComponentType>::createComponent()
{
   return m_create_component_callback();
}

#endif
