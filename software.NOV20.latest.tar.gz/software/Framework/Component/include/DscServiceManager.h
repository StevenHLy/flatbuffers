#ifndef DscServiceManager_h
#define DscServiceManager_h

#include "ConfigParameters.h"
#include "Service.h"
#include <map>
#include <memory>
#include <string>
#include <typeinfo>

class DscFramework;

class DscServiceManager
{
   public:

      DscServiceManager(DscFramework& p_component_handle);
      ~DscServiceManager() = default;

      void createServices();
      void disableServices();
      void enableServices();
      void initializeServices();
      void registerServices();
      void shutdownServices();

   protected:

      class ServiceWrapper
      {
         public:

            ServiceWrapper(std::string p_service_name,
                           unsigned int p_service_id);
            virtual ~ServiceWrapper() = default;

            virtual void createService() = 0;
            virtual void disableService() = 0;
            virtual void enableService() = 0;
            virtual void initializeService() = 0;
            virtual void shutdownService() = 0;

            unsigned int m_service_id;
            std::string m_service_name;
      };

      template<typename ServiceType, typename ServiceImplType>
      class ServiceWrapperImpl : public ServiceWrapper
      {
         public:

            ServiceWrapperImpl(std::string p_service_name,
                               unsigned int p_service_id);
            ~ServiceWrapperImpl() = default;

            void createService();
            void disableService();
            void enableService();
            void initializeService();
            void shutdownService();
      };

      template<typename ServiceType, typename ServiceImplType> void addService(std::string p_service_name,
                                                                               unsigned int p_service_id);
      template<typename ServiceType, typename ServiceImplType> void addServiceItem();

      std::map<std::size_t, std::shared_ptr<ServiceWrapper>> m_service_pool;
      DscFramework& m_component_handle;
};

template<typename ServiceType, typename ServiceImplType>
void DscServiceManager::addService(std::string p_service_name,
                                   unsigned int p_service_id)
{
   std::size_t hash = typeid(ServiceImplType).hash_code();

   m_service_pool[hash].reset(new ServiceWrapperImpl<ServiceType, ServiceImplType>(p_service_name, p_service_id));
}

template<typename ServiceType, typename ServiceImplType>
void DscServiceManager::addServiceItem()
{
   addService<ServiceType, ServiceImplType>(std::string(ServiceType::SERVICE_NAME),
                                            ConfigParameters::getInstance().getRequiredParam<unsigned int>("MasterModuleList." + std::string(ServiceType::SERVICE_NAME) + ".Module_Id"));
}

template<typename ServiceType, typename ServiceImplType>
DscServiceManager::ServiceWrapperImpl<ServiceType, ServiceImplType>::ServiceWrapperImpl(std::string p_service_name,
                                                                                        unsigned int p_service_id)
: ServiceWrapper(p_service_name, p_service_id)
{
}

template<typename ServiceType, typename ServiceImplType>
void DscServiceManager::ServiceWrapperImpl<ServiceType, ServiceImplType>::createService()
{
   Service<ServiceType>::template create<ServiceImplType>(m_service_id);
}

template<typename ServiceType, typename ServiceImplType>
void DscServiceManager::ServiceWrapperImpl<ServiceType, ServiceImplType>::disableService()
{
   Service<ServiceType>::disable();
}

template<typename ServiceType, typename ServiceImplType>
void DscServiceManager::ServiceWrapperImpl<ServiceType, ServiceImplType>::enableService()
{
   Service<ServiceType>::enable();
}

template<typename ServiceType, typename ServiceImplType>
void DscServiceManager::ServiceWrapperImpl<ServiceType, ServiceImplType>::initializeService()
{
   Service<ServiceType>::initialize();
}

template<typename ServiceType, typename ServiceImplType>
void DscServiceManager::ServiceWrapperImpl<ServiceType, ServiceImplType>::shutdownService()
{
   Service<ServiceType>::shutdown();
}

#endif
