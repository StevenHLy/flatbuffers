#ifndef DscFramework_h
#define DscFramework_h

#include "DscComponentManager.h"
#include "DscServiceManager.h"
#include <memory>
#include <string>

class DscFramework
{
   public:

      static constexpr const char* FRAMEWORK_NAME = "Framework";

      DscFramework();
      virtual ~DscFramework() = default;

      void initialize();
      void run();
      void shutdown();

      std::unique_ptr<DscComponentManager>& componentManager();
      std::unique_ptr<DscServiceManager>& serviceManager();

      unsigned int frameworkId();
      std::string frameworkName();

   protected:

      const unsigned int FRAMEWORK_ID;

      void createComponents();
      void createServices();
      void disableServices();
      void enableServices();
      void initializeComponents();
      void initializeServices();
      void logProgramInfo();
      void registerComponents();
      void registerServices();
      void shutdownComponents();
      void shutdownServices();

      template<typename MgrType> void createComponentManager();
      template<typename MgrType> void createServiceManager();

      std::unique_ptr<DscComponentManager> m_component_mgr;
      std::unique_ptr<DscServiceManager> m_service_mgr;
};

template<typename MgrType>
void DscFramework::createComponentManager()
{
   m_component_mgr.reset(new MgrType(*this));
}

template<typename MgrType>
void DscFramework::createServiceManager()
{
   m_service_mgr.reset(new MgrType(*this));
}

#endif
