#include "flatbuffers/flatbuffers.h"
#include "RadarActionControlMsgBody.h"
#include "Channel_Plan_Type_generated.h"
#include "Rx_Command_Type_generated.h"
#include <iostream>

// Helper function to print ChannelPlanType fields
void PrintChannelPlan(const RadarActionControlMsgBody& radarAction) {
    std::cout << "Deserialized ChannelPlanType ID: " << radarAction.id << std::endl;
    std::cout << "Deserialized Channel IDs: ";
    for (const auto& channel_id : radarAction.channel_ids) {
        std::cout << channel_id << " ";
    }
    std::cout << std::endl;

    std::cout << "Deserialized Aggregation Weights: ";
    for (const auto& weight : radarAction.aggregation_weights) {
        std::cout << "(" << weight.first << ", " << weight.second << ") ";
    }
    std::cout << std::endl;
}

// Helper function to print RxCommandType fields
void PrintRxCommand(const RadarActionControlMsgBody& radarAction) {
    std::cout << "Deserialized RxCommand ID: " << radarAction.rx_command_id << std::endl;
    std::cout << "Channel Plan ID: " << radarAction.channel_plan_id << std::endl;
    std::cout << "Rx Window Plan IDs: ";
    for (const auto& id : radarAction.rx_window_plan_ids) {
        std::cout << id << " ";
    }
    std::cout << std::endl;

    std::cout << "Processing Module ID: " << radarAction.processing_module_id << std::endl;
}

// Serialize and deserialize ChannelPlanType
void ProcessChannelPlan(RadarActionControlMsgBody& radarAction, flatbuffers::FlatBufferBuilder& builder) {
    // Serialize ChannelPlanType
    auto channelPlanOffset = radarAction.serializeChannelPlan(builder);
    builder.Finish(channelPlanOffset);

    // Deserialize ChannelPlanType
    const ChannelPlanType* channelPlan = flatbuffers::GetRoot<ChannelPlanType>(builder.GetBufferPointer());
    radarAction.deserializeChannelPlan(channelPlan);

    // Print ChannelPlanType fields
    PrintChannelPlan(radarAction);
}

// Serialize and deserialize RxCommandType
void ProcessRxCommand(RadarActionControlMsgBody& radarAction, flatbuffers::FlatBufferBuilder& builder) {
    // Clear the builder to avoid buffer overlap //avoid crash
    builder.Clear();

    // Serialize RxCommandType
    auto rxCommandOffset = radarAction.serializeRxCommand(builder);
    builder.Finish(rxCommandOffset);

    // Deserialize RxCommandType
    const RxCommandType* rxCommand = flatbuffers::GetRoot<RxCommandType>(builder.GetBufferPointer());
    radarAction.deserializeRxCommand(rxCommand);

    // Print RxCommandType fields
    PrintRxCommand(radarAction);
}

int main() {
    flatbuffers::FlatBufferBuilder builder(1024);

    // Create an instance of RadarActionControlMsgBody and populate ChannelPlanType fields
    RadarActionControlMsgBody radarAction;
    radarAction.id = 123;
    radarAction.channel_ids = { 101, 102, 103 };
    radarAction.aggregation_weights = { {1.0, 0.5}, {0.8, 0.6} };

    std::cout << "Processing ChannelPlanType..." << std::endl;
    ProcessChannelPlan(radarAction, builder);

    // Populate RxCommandType fields
    radarAction.rx_command_id = 456;
    radarAction.channel_plan_id = 555;
    radarAction.rx_window_plan_ids = { 201, 202, 203 };
    radarAction.processing_module_id = 777;

    std::cout << "Processing RxCommandType..." << std::endl;
    ProcessRxCommand(radarAction, builder);

    return 0;
}
