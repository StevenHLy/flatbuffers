// RadarActionControlMsgBody.h

#ifndef RADAR_ACTION_CONTROL_MSG_BODY_H
#define RADAR_ACTION_CONTROL_MSG_BODY_H

#include "flatbuffers/flatbuffers.h"
#include "Channel_Plan_Type_generated.h"  // Generated from ChannelPlanType.fbs
#include "Rx_Command_Type_generated.h"
#include <vector>

class RadarActionControlMsgBody {
public:
    // Constructor and Destructor
    RadarActionControlMsgBody();
    ~RadarActionControlMsgBody();

    // Serialize the object to a FlatBuffer
    flatbuffers::Offset<ChannelPlanType> serializeChannelPlan(flatbuffers::FlatBufferBuilder& builder) const;
    flatbuffers::Offset<RxCommandType> serializeRxCommand(flatbuffers::FlatBufferBuilder& builder) const;


    // Deserialize the object from a FlatBuffer
    void deserializeChannelPlan(const ChannelPlanType* channelPlan);
    void deserializeRxCommand(const RxCommandType* rxCommand);

   //channel plan
    uint32_t id;
    std::vector<uint32_t> channel_ids;
    std::vector<std::pair<double, double>> aggregation_weights;

   //rx command
    uint32_t rx_command_id;  // <-- Adding the missing RxCommandType id field
    uint32_t channel_plan_id;
    std::vector<uint32_t> rx_window_plan_ids;
    uint32_t processing_module_id;


};

#endif // RADAR_ACTION_CONTROL_MSG_BODY_H
