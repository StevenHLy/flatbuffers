// RadarActionControlMsgBody.cpp

#include "RadarActionControlMsgBody.h"
#include "common_generated.h"


// Constructor: Initialize the id to 0
RadarActionControlMsgBody::RadarActionControlMsgBody() : 
id(0),
rx_command_id(0), 
channel_plan_id(0),
processing_module_id(0) {} 

// Destructor
RadarActionControlMsgBody::~RadarActionControlMsgBody() {}

// Serialize the ChannelPlanType into a FlatBuffer
flatbuffers::Offset<ChannelPlanType> RadarActionControlMsgBody::serializeChannelPlan(flatbuffers::FlatBufferBuilder& builder) const {
    // Serialize the id
    auto id_offset = common::CreateUint(builder, id);

    // Serialize the channel_ids array
    std::vector<flatbuffers::Offset<common::Uint>> channel_ids_vector;
    for (const auto& channel_id : channel_ids) {
        channel_ids_vector.push_back(common::CreateUint(builder, channel_id));
    }
    auto channel_ids_offset = builder.CreateVector(channel_ids_vector);

    // Serialize the aggregation_weights array
    std::vector<flatbuffers::Offset<common::ComplexDoubleType>> weights_vector;
    for (const auto& weight : aggregation_weights) {
        weights_vector.push_back(common::CreateComplexDoubleType(builder, weight.first, weight.second));
    }
    auto weights_offset = builder.CreateVector(weights_vector);

    // Build and return the ChannelPlanType offset
    return CreateChannelPlanType(builder, id_offset, channel_ids_offset, weights_offset);
}

flatbuffers::Offset<RxCommandType> RadarActionControlMsgBody::serializeRxCommand(flatbuffers::FlatBufferBuilder& builder) const {
    // Serialize the rx_command_id (RxCommandType id)
    auto rx_command_id_offset = common::CreateUint(builder, rx_command_id);

    // Serialize the channel_plan_id
    auto channel_plan_id_offset = common::CreateUint(builder, channel_plan_id);

    // Serialize the rx_window_plan_ids array
    std::vector<flatbuffers::Offset<common::Uint>> rx_window_plan_ids_vector;
    for (const auto& rx_window_plan_id : rx_window_plan_ids) {
        rx_window_plan_ids_vector.push_back(common::CreateUint(builder, rx_window_plan_id));
    }
    auto rx_window_plan_ids_offset = builder.CreateVector(rx_window_plan_ids_vector);

    // Serialize the processing_module_id if it's set
    flatbuffers::Offset<common::Uint> processing_module_id_offset = 0;
    if (processing_module_id != 0) {
        processing_module_id_offset = common::CreateUint(builder, processing_module_id);
    }

    // Build and return the RxCommandType offset
    return CreateRxCommandType(builder, rx_command_id_offset, channel_plan_id_offset, rx_window_plan_ids_offset, processing_module_id_offset);
}

// Deserialize the ChannelPlanType from a FlatBuffer
void RadarActionControlMsgBody::deserializeChannelPlan(const ChannelPlanType* channelPlan) {
    // Deserialize the id
    id = channelPlan->id()->value();

    // Deserialize the channel_ids
    channel_ids.clear();
    for (auto channel_id : *channelPlan->channel_id()) {
        channel_ids.push_back(channel_id->value());
    }

    // Deserialize the aggregation_weights
    aggregation_weights.clear();
    for (auto weight : *channelPlan->aggregation_weights()) {
        aggregation_weights.emplace_back(weight->real(), weight->imag());
    }

}

void RadarActionControlMsgBody::deserializeRxCommand(const RxCommandType* rxCommand) {
    // Deserialize the rx_command_id (RxCommandType id)
    rx_command_id = rxCommand->id()->value();

    // Deserialize the channel_plan_id
    channel_plan_id = rxCommand->channel_plan_id()->value();

    // Deserialize the rx_window_plan_ids
    rx_window_plan_ids.clear();
    for (auto rx_window_plan_id : *rxCommand->rx_window_plan_id()) {
        rx_window_plan_ids.push_back(rx_window_plan_id->value());
    }

    // Deserialize the processing_module_id if it exists
    if (rxCommand->processing_module_id()) {
        processing_module_id = rxCommand->processing_module_id()->value();
    } else {
        processing_module_id = 0; // Set to 0 if not present
    }
}


