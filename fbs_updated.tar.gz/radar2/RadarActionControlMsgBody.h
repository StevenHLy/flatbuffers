// RadarActionControlMsgBody.h

#ifndef RADAR_ACTION_CONTROL_MSG_BODY_H
#define RADAR_ACTION_CONTROL_MSG_BODY_H

#include "flatbuffers/flatbuffers.h"
#include "Channel_Plan_Type_generated.h"  // Generated from ChannelPlanType.fbs
#include "Rx_Command_Type_generated.h"
#include "Beam_Plan_Type_generated.h"
#include <vector>

//demo config


enum class CommandType {
    SLEW,
    TRANSMIT
};

// Enum for Waveform Types
enum class WaveformType {
    WAVEFORM_A,
    WAVEFORM_B,
    WAVEFORM_C,
    UNKNOWN  // Fallback for unsupported waveforms
};

// Struct for Waveform details
struct Waveform {
    double pulsewidth_sec;
    double amp;
    double bandwidth_mhz;
    double phase_offset_psec;
    double offsets_mhz;
    int sample_per_chip;
    int gold_code_index;
};

// Struct for Penzias parameters (Az, El for SlewCommand or Waveform details for TransmitCommand)
struct Penzias {
    double az;  // For SlewCommand
    double el;  // For SlewCommand
    WaveformType waveform_type;  // For TransmitCommand
    int num_pulses;  // For TransmitCommand
    int repetition_count;  // For TransmitCommand
    Waveform waveform;  // Details for the waveform being used
};

// Struct for Command, using enum to specify the command type
struct Command {
    CommandType type;
    Penzias penzias;
};

// Struct for a Step in the Scenario
struct Step {
    double time_offset_secs;
    Command command;
};

// Struct for Scenario
struct Scenario {
    double start_time_delay_secs;
    std::vector<Step> steps;
};

class RadarActionControlMsgBody {
public:
    // Constructor and Destructor
    RadarActionControlMsgBody();
    ~RadarActionControlMsgBody();

    // Serialize the object to a FlatBuffer
    flatbuffers::Offset<ChannelPlanType> serializeChannelPlan(flatbuffers::FlatBufferBuilder& builder) const;
    flatbuffers::Offset<RxCommandType> serializeRxCommand(flatbuffers::FlatBufferBuilder& builder) const;
    flatbuffers::Offset<BeamPlanType> serializeBeamPlanType(flatbuffers::FlatBufferBuilder& builder) const;


    // Deserialize the object from a FlatBuffer
    void deserializeChannelPlan(const ChannelPlanType* channelPlan);
    void deserializeRxCommand(const RxCommandType* rxCommand);
    void deserializeBeamPlanType(const BeamPlanType* beam_plan);

   //channel plan
    uint32_t id;
    std::vector<uint32_t> channel_ids;
    std::vector<std::pair<double, double>> aggregation_weights;

   //rx command
    uint32_t rx_command_id;  // <-- Adding the missing RxCommandType id field
    uint32_t channel_plan_id;
    std::vector<uint32_t> rx_window_plan_ids;
    uint32_t processing_module_id;

    //beam plan type
     // Fields for BeamPlanType
    uint32_t beam_plan_id;  // ID of the BeamPlanType
    std::vector<const AngleCommandType*> beams;  // List of beam steering commands
    std::vector<const AngleCommandType*> nulls;  // List of null steering commands
    std::vector<const ElementCommandType*> element_commands;  // List of element commands using delay and amplitude


    // Add Scenario object for storing radar scenario
    Scenario scenario;
    std::vector<Step> steps;
        // Method to add a step to the scenario
    void addStep(const Step& step);

    // Method to print the Scenario
    void printScenario() const;

};





#endif // RADAR_ACTION_CONTROL_MSG_BODY_H
