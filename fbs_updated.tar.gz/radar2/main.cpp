#include "flatbuffers/flatbuffers.h"
#include "RadarActionControlMsgBody.h"
#include "Channel_Plan_Type_generated.h"
#include "Rx_Command_Type_generated.h"
#include "Beam_Plan_Type_generated.h"
#include <iostream>

// Helper function to print ChannelPlanType fields
void PrintChannelPlan(const RadarActionControlMsgBody& radarAction) {
    std::cout << "Deserialized ChannelPlanType ID: " << radarAction.id << std::endl;
    std::cout << "Deserialized Channel IDs: ";
    for (const auto& channel_id : radarAction.channel_ids) {
        std::cout << channel_id << " ";
    }
    std::cout << std::endl;

    std::cout << "Deserialized Aggregation Weights: ";
    for (const auto& weight : radarAction.aggregation_weights) {
        std::cout << "(" << weight.first << ", " << weight.second << ") \n";
    }
    std::cout << std::endl;
}

// Helper function to print RxCommandType fields
void PrintRxCommand(const RadarActionControlMsgBody& radarAction) {
    std::cout << "Deserialized RxCommand ID: " << radarAction.rx_command_id << std::endl;
    std::cout << "Channel Plan ID: " << radarAction.channel_plan_id << std::endl;
    std::cout << "Rx Window Plan IDs: ";
    for (const auto& id : radarAction.rx_window_plan_ids) {
        std::cout << id << " ";
    }
    std::cout << std::endl;

    std::cout << "Processing Module ID: " << radarAction.processing_module_id << std::endl;
}

void PrintBeamPlan(const RadarActionControlMsgBody& radarAction) {
    std::cout << "Deserialized BeamPlanType ID: " << radarAction.beam_plan_id << std::endl;

    // Print Beams (AngleCommandType)
    std::cout << "Beams: " << std::endl;
    for (const auto* beam : radarAction.beams) {
        std::cout << "  Channel Plan ID: " << beam->channel_plan_id()->value() << std::endl;
        std::cout << "  Azimuth: " << beam->azimuth()->value() << " radians" << std::endl;
        std::cout << "  Elevation: " << beam->elevation()->value() << " radians" << std::endl;
        std::cout << "  Azimuth Spoil Factor: " << beam->azimuth_spoil_factor()->value() << std::endl;
        std::cout << "  Elevation Spoil Factor: " << beam->elevation_spoil_factor()->value() << std::endl;
    }
    std::cout << std::endl;

    // Print Nulls (AngleCommandType)
    std::cout << "Nulls: " << std::endl;
    for (const auto* null : radarAction.nulls) {
        std::cout << "  Channel Plan ID: " << null->channel_plan_id()->value() << std::endl;
        std::cout << "  Azimuth: " << null->azimuth()->value() << " radians" << std::endl;
        std::cout << "  Elevation: " << null->elevation()->value() << " radians" << std::endl;
        std::cout << "  Azimuth Spoil Factor: " << null->azimuth_spoil_factor()->value() << std::endl;
        std::cout << "  Elevation Spoil Factor: " << null->elevation_spoil_factor()->value() << std::endl;
    }
    std::cout << std::endl;

    // Print Element Commands (ElementCommandType)
    std::cout << "Element Commands: " << std::endl;
    for (const auto* element_command : radarAction.element_commands) {
        std::cout << "  Element ID: " << element_command->element_id()->value() << std::endl;
        std::cout << "  Delay: " << element_command->delay()->value() << " seconds" << std::endl;
        std::cout << "  Amplitude: " << element_command->amplitude()->value() << std::endl;
    }
    std::cout << std::endl;
}


void ProcessBeamPlan(RadarActionControlMsgBody& radarAction, flatbuffers::FlatBufferBuilder& builder) {
    // Clear the builder to avoid buffer overlap
    builder.Clear();

    // Create data for BeamPlanType serialization
    std::vector<flatbuffers::Offset<AngleCommandType>> beam_offsets;
    std::vector<flatbuffers::Offset<AngleCommandType>> null_offsets;
    std::vector<flatbuffers::Offset<ElementCommandType>> element_command_offsets;

    // Create a beam (example)
    auto channel_plan_id_offset = common::CreateUint(builder, 5678);
    auto azimuth_offset = common::CreateDouble(builder, 0.785398);  // 45 degrees in radians
    auto elevation_offset = common::CreateDouble(builder, 0.523599);  // 30 degrees in radians
    auto azimuth_spoil_factor_offset = common::CreateDouble(builder, 1.5);
    auto elevation_spoil_factor_offset = common::CreateDouble(builder, 1.2);

    // Create PolarizationType (required fields)
    auto vertical_offset = common::CreateComplexDoubleType(builder, 1.0, 0.0);
    auto horizontal_offset = common::CreateComplexDoubleType(builder, 0.0, 1.0);
    auto jones_vector_offset = CreateJonesVectorType(builder, vertical_offset, horizontal_offset);
    auto polarization_offset = CreatePolarizationType(builder, jones_vector_offset, 0);  // No polarization reference vector

    // Create the beam using the offsets
    auto beam_offset = CreateAngleCommandType(
        builder, 
        channel_plan_id_offset, 
        azimuth_offset, 
        elevation_offset, 
        azimuth_spoil_factor_offset, 
        elevation_spoil_factor_offset, 
        polarization_offset
    );

    beam_offsets.push_back(beam_offset);

    // Similar process for nulls and element commands
    auto element_id_offset = common::CreateUint(builder, 12);
    auto delay_offset = common::CreateDouble(builder, 0.000005);
    auto amplitude_offset = common::CreateDouble(builder, 0.75);
    auto element_command_offset = CreateElementCommandType(builder, element_id_offset, delay_offset, amplitude_offset);
    element_command_offsets.push_back(element_command_offset);

    // Create vectors for beams, nulls, and element commands
    auto beams_vector = builder.CreateVector(beam_offsets);
    auto nulls_vector = builder.CreateVector(null_offsets);  // Empty for now
    auto element_commands_vector = builder.CreateVector(element_command_offsets);

    // Serialize the BeamPlanType
    auto beam_plan_id_offset = common::CreateUint(builder, radarAction.beam_plan_id);
    auto beam_plan_offset = CreateBeamPlanType(builder, beam_plan_id_offset, beams_vector, nulls_vector, element_commands_vector);
    
    // Finish the buffer
    builder.Finish(beam_plan_offset);

    // Deserialize BeamPlanType
    const BeamPlanType* beamPlan = flatbuffers::GetRoot<BeamPlanType>(builder.GetBufferPointer());
    radarAction.deserializeBeamPlanType(beamPlan);

    // Print BeamPlanType fields
    PrintBeamPlan(radarAction);
}
// Serialize and deserialize ChannelPlanType
void ProcessChannelPlan(RadarActionControlMsgBody& radarAction, flatbuffers::FlatBufferBuilder& builder) {
    // Serialize ChannelPlanType
    auto channelPlanOffset = radarAction.serializeChannelPlan(builder);
    builder.Finish(channelPlanOffset);

    // Deserialize ChannelPlanType
    const ChannelPlanType* channelPlan = flatbuffers::GetRoot<ChannelPlanType>(builder.GetBufferPointer());
    radarAction.deserializeChannelPlan(channelPlan);

    // Print ChannelPlanType fields
    PrintChannelPlan(radarAction);
}



// Serialize and deserialize RxCommandType
void ProcessRxCommand(RadarActionControlMsgBody& radarAction, flatbuffers::FlatBufferBuilder& builder) {
    // Clear the builder to avoid buffer overlap
    builder.Clear();

    // Serialize RxCommandType
    auto rxCommandOffset = radarAction.serializeRxCommand(builder);
    builder.Finish(rxCommandOffset);

    // Deserialize RxCommandType
    const RxCommandType* rxCommand = flatbuffers::GetRoot<RxCommandType>(builder.GetBufferPointer());
    radarAction.deserializeRxCommand(rxCommand);

    // Print RxCommandType fields
    PrintRxCommand(radarAction);
}

int main() {
    flatbuffers::FlatBufferBuilder builder(1024);

    // Create an instance of RadarActionControlMsgBody and populate ChannelPlanType fields
    RadarActionControlMsgBody radarAction;
    radarAction.id = 123;
    radarAction.channel_ids = { 101, 102, 103 };
    radarAction.aggregation_weights = { {1.0, 0.5}, {0.8, 0.6} };

    std::cout << "Processing ChannelPlanType..." << std::endl;
    ProcessChannelPlan(radarAction, builder);

    // Populate RxCommandType fields
    radarAction.rx_command_id = 456;
    radarAction.channel_plan_id = 555;
    radarAction.rx_window_plan_ids = { 201, 202, 203 };
    radarAction.processing_module_id = 777;

    std::cout << "Processing RxCommandType..." << std::endl;
    ProcessRxCommand(radarAction, builder);

      // Populate and process BeamPlanType fields
    radarAction.beam_plan_id = 789;

    std::cout << "\nProcessing BeamPlanType..." << std::endl;
    ProcessBeamPlan(radarAction, builder);


    //demo
    // Array to hold the steps
    std::vector<Step> steps;

    // Step 1: SLEW Command
    Step step_1;
    step_1.time_offset_secs = 0.0;
    step_1.command.type = CommandType::SLEW;
    step_1.command.penzias.az = 205;
    step_1.command.penzias.el = 1.5;

    // Step 2: TRANSMIT Command with Waveform_A
    Step step_2;
    step_2.time_offset_secs = 14.5;
    step_2.command.type = CommandType::TRANSMIT;
    step_2.command.penzias.waveform_type = WaveformType::WAVEFORM_A;
    step_2.command.penzias.num_pulses = 1;
    step_2.command.penzias.repetition_count = 250;

    // Step 3: TRANSMIT Command with Waveform_B
    Step step_3;
    step_3.time_offset_secs = 54.5;
    step_3.command.type = CommandType::TRANSMIT;
    step_3.command.penzias.waveform_type = WaveformType::WAVEFORM_B;
    step_3.command.penzias.num_pulses = 1;
    step_3.command.penzias.repetition_count = 250;

    // Add the steps to the vector
    steps.push_back(step_1);
    steps.push_back(step_2);
    steps.push_back(step_3);

    // Loop through the steps and add them to the scenario
    for (const auto& step : steps) {
        radarAction.addStep(step);
    }

    // Print the Scenario
    radarAction.printScenario();

    return 0;
}
