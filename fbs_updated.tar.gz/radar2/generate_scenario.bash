#!/bin/bash

# Input structured text file
SCENARIO_FILE="scenario.txt"

# Function to parse and print the start time delay
print_start_time_delay() {
  start_delay=$(grep -oP '"Start_Time_Delay_Secs" "\K[\d.]+' "$SCENARIO_FILE")
  echo "Scenario Start Time Delay: $start_delay seconds"
}

# Function to parse and print the steps dynamically
print_steps() {
  echo "Steps:"
  step_index=0
  grep -P 'Step_\d+' "$SCENARIO_FILE" | while read -r step; do
    time_offset=$(grep -A1 "$step" "$SCENARIO_FILE" | grep -oP '"Time_Offset_Secs" "\K[\d.]+' )
    echo "  Step $((step_index + 1)) Time Offset: $time_offset seconds"

    if grep -A3 "$step" "$SCENARIO_FILE" | grep -q "SlewCommand"; then
      az=$(grep -A6 "$step" "$SCENARIO_FILE" | grep -oP '"Az" "\K[\d.]+' )
      el=$(grep -A6 "$step" "$SCENARIO_FILE" | grep -oP '"El" "\K[\d.]+' )
      echo "    Command: SLEW"
      echo "    Azimuth: $az"
      echo "    Elevation: $el"
    elif grep -A3 "$step" "$SCENARIO_FILE" | grep -q "TransmitCommand"; then
      # Ensure the script only captures valid waveform names
      waveform=$(grep -A6 "$step" "$SCENARIO_FILE" | grep -oP '"Waveform" "(Waveform_[A-Z]+)"' | cut -d'"' -f2)
      num_pulses=$(grep -A6 "$step" "$SCENARIO_FILE" | grep -oP '"Num_Pulses" "\K[\d.]+' )
      repetition_count=$(grep -A6 "$step" "$SCENARIO_FILE" | grep -oP '"Repetition_Count" "\K[\d.]+' )
      if [[ -n "$waveform" ]]; then
        echo "    Command: TRANSMIT"
        echo "    Waveform: $waveform"
        echo "    Num Pulses: $num_pulses"
        echo "    Repetition Count: $repetition_count"
      else
        echo "    Error: Invalid waveform detected!"
      fi
    fi

    step_index=$((step_index + 1))
  done
}

# Function to parse and print waveforms dynamically
print_waveforms() {
  echo "Waveforms:"
  grep -P 'Waveform_\w+' "$SCENARIO_FILE" | while read -r waveform; do
    pulsewidth_sec=$(grep -A6 "$waveform" "$SCENARIO_FILE" | grep -oP '"Pulsewidth_sec" "\K[\d.]+' )
    amp=$(grep -A6 "$waveform" "$SCENARIO_FILE" | grep -oP '"Amp" "\K[\d.]+' )
    bandwidth_mhz=$(grep -A6 "$waveform" "$SCENARIO_FILE" | grep -oP '"Bandwidth_MHz" "\K[\d.]+' )
    phase_offset_psec=$(grep -A6 "$waveform" "$SCENARIO_FILE" | grep -oP '"Phase_Offset_psec" "\K[\d.]+' )
    offsets_mhz=$(grep -A6 "$waveform" "$SCENARIO_FILE" | grep -oP '"Offsets_Mhz" "\K[\d.]+' )
    sample_per_chip=$(grep -A6 "$waveform" "$SCENARIO_FILE" | grep -oP '"Sample_Per_Chip" "\K\d+' )
    gold_code_index=$(grep -A6 "$waveform" "$SCENARIO_FILE" | grep -oP '"Gold_Code_Index" "\K\d+' )

    echo "  $waveform:"
    echo "    Pulsewidth: $pulsewidth_sec sec"
    echo "    Amp: $amp"
    echo "    Bandwidth: $bandwidth_mhz MHz"
    echo "    Phase Offset: $phase_offset_psec psec"
    echo "    Offsets: $offsets_mhz MHz"
    echo "    Sample Per Chip: $sample_per_chip"
    echo "    Gold Code Index: $gold_code_index"
  done
}

# Main function to parse and print the scenario details
print_scenario() {
  print_start_time_delay
  print_steps
  print_waveforms
}

# Run the script
print_scenario
