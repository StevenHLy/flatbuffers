#include "PackedData.hpp"
#include <iostream>

int main() {
    // Create an instance of PackedData
    PackedData data;

    // Generate and send data for 250 iterations
    for (int a = 1; a <= 250; ++a) {
        // Generate data for each iteration
        data.generateData(a);

        // Convert c1 to string and print
        std::cout << "c1: " << data.vectorToString(data.getC1()) << std::endl;

        
       //data.printSampleData();
    }

    return 0;
}
