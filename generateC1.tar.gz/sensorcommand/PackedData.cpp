#include "PackedData.hpp"
#include <iostream>
#include <random>
#include <sstream>
#include <iomanip>

// Default constructor
PackedData::PackedData() : azimuth(0), elevation(0) {
    c1 = std::vector<double>(4, 0.0);
    c2 = std::vector<double>(4, 0.0);
    c3 = std::vector<double>(4, 0.0);
}

// Method to generate data for c1, c2, c3, azimuth, and elevation
void PackedData::generateData(int a) {
    azimuth = generateRandomDouble(0, 360);  // Example range 0 to 360 degrees
    elevation = generateRandomDouble(0, 90); // Example range 0 to 90 degrees
    c1 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(a), 6950.0};
    c2 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(a), 6950.0};
    c3 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(a), 6950.0};
}

// Helper function to generate a random double within a specified range
double PackedData::generateRandomDouble(double min, double max) const {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(min, max);
    return dis(gen);
}

// Method to serialize the data into a string
std::string PackedData::serialize() const {
    std::ostringstream oss;
   // oss << std::fixed << std::setprecision(4) << azimuth << " " << elevation << " ";
    for (double val : c1) oss << val << " ";
    //for (double val : c2) oss << val << " ";
    //for (double val : c3) oss << val << " ";
    return oss.str();
}

// Method to simulate sending packed data to a simulator
void PackedData::printSampleData() const {
    std::string serializedData = serialize();
    std::cout << "Sample Data: " << serializedData << std::endl;
}

// Getter for c1
const std::vector<double>& PackedData::getC1() const {
    return c1;
}

const std::vector<double>& PackedData::getC2() const {
    return c2;
}
const std::vector<double>& PackedData::getC3() const {
    return c3;
}

// Method to convert vector to string
std::string PackedData::vectorToString(const std::vector<double>& vec) const {
    std::ostringstream oss;
    for (const auto& val : vec) {
        oss << val << " ";
    }
    return oss.str();
}
