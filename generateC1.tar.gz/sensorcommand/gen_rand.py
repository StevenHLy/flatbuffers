import numpy as np
import time

# Define constants
br = 6950
a = 1

# Open the output text file in append mode
with open("output_data.txt", "w") as file:
    while a < 251:
        # Generate random values and round them
        b1 = round(21 + 1 * ((2 * (np.random.rand())) - 1), 4)
        b2 = round(6950 + 30 * ((2 * (np.random.rand())) - 1), 4)
        b3 = a

        b4 = round(21 + 1 * ((2 * (np.random.rand())) - 1), 4)
        b5 = round(6950 + 30 * ((2 * (np.random.rand())) - 1), 4)
        b6 = a

        b7 = round(21 + 1 * ((2 * (np.random.rand())) - 1), 4)
        b8 = round(6950 + 30 * ((2 * (np.random.rand())) - 1), 4)
        b9 = a

        # Combine values into lists c1, c2, c3
        c1 = [b1, b2, b3, br]
        c2 = [b4, b5, b6, br]
        c3 = [b7, b8, b9, br]

        # Concatenate the lists into a single array for output
        cagg = c1 + c2 + c3

        # Format the output and write to the text file
        file.write(f"Iteration {a}:\n")
        file.write(f"  c1: {c1}\n")
        file.write(f"  c2: {c2}\n")
        file.write(f"  c3: {c3}\n")
        file.write("-" * 40 + "\n")

        # Optional pause to simulate delay
        time.sleep(0.2)
        a += 1

print("Data has been written to output_data.txt")
