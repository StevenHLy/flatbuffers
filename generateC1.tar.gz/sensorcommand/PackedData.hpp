// PackedData.hpp
#ifndef PACKEDDATA_HPP
#define PACKEDDATA_HPP

#include <vector>
#include <string>

class PackedData {
public:
    // Default constructor
    PackedData();

    // Method to generate data based on an iteration value
    void generateData(int a);
    
    // Method to serialize and send data
    std::string serialize() const;
    void printSampleData() const;

    // Getter for c1 (returns a const reference to avoid copying)
    const std::vector<double>& getC1() const;
    const std::vector<double>& getC2() const;
    const std::vector<double>& getC3() const;

    // Convert vector to string
    std::string vectorToString(const std::vector<double>& vec) const;

private:
    // Data fields
    double azimuth;
    double elevation;
    std::vector<double> c1;
    std::vector<double> c2;
    std::vector<double> c3;

    // Helper function to generate random double
    double generateRandomDouble(double min, double max) const;
};

#endif // PACKEDDATA_HPP
