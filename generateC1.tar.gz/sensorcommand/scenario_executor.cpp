#include <iostream>
#include <vector>
#include <thread>
#include <chrono>
#include <iomanip>
#include <ctime>
#include <random>

struct IterationData {
    std::vector<double> c1;
    std::vector<double> c2;
    std::vector<double> c3;
    //double azimuth;
    //double elevation;
};

double generateRandomDouble(double min, double max) {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(min, max);
    return dis(gen);
}

IterationData generateIterationData(int a) {
    IterationData data;

    // Generate values for c1, c2, and c3
    data.c1 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(a), 6950.0};
    data.c2 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(a), 6950.0};
    data.c3 = {generateRandomDouble(20.0, 22.0), generateRandomDouble(6920.0, 6980.0), static_cast<double>(a), 6950.0};

    // Generate azimuth and elevation values
   // data.azimuth = generateRandomDouble(0, 360);  // Example range 0 to 360 degrees
   // data.elevation = generateRandomDouble(0, 90); // Example range 0 to 90 degrees

    return data;
}
// Enum for command types
enum class CommandType {
    SLEW,
    TRANSMIT
};

// Structs for different commands
struct SlewCommand {
    double azimuth;
    double elevation;
};

struct TransmitCommand {
    std::string waveform;
    int num_pulses;
    int repetition_count;
};

// Struct for scenario steps
struct ScenarioStep {
    CommandType type;
    double time_offset_secs;
    std::string antenna; // e.g., Penzias, Wilson, Dickie
    SlewCommand slew;
    TransmitCommand transmit;
};

// Function to get the current time in HH:MM:SS format
std::string getCurrentTime() {
    auto now = std::chrono::system_clock::now();
    std::time_t current_time = std::chrono::system_clock::to_time_t(now);
    std::tm* local_time = std::localtime(&current_time);

    std::ostringstream time_stream;
    time_stream << std::put_time(local_time, "%H:%M:%S");
    return time_stream.str();
}

// Function to execute sensor commands
void executeSensorCommands(const std::vector<ScenarioStep>& steps) {

    double previous_time_offset = 0.0;  // Start at 0 for initial step

    for (const auto& step : steps) {

         // Calculate the time delay from the previous step
        double delay = step.time_offset_secs - previous_time_offset;

        // Apply the delay (sleep for the difference in time)
        std::this_thread::sleep_for(std::chrono::duration<double>(delay));

        // Update previous_time_offset to the current step's time_offset_secs
        previous_time_offset = step.time_offset_secs;
        

        // Simulate delay for each step
       // std::this_thread::sleep_for(std::chrono::duration<double>(step.time_offset_secs));

        // Print current time before executing the command
        std::string current_time = getCurrentTime();
        std::cout << "[" << current_time << "] ";

        if (step.type == CommandType::SLEW) {
            std::cout << "Executing SlewCommand on " << step.antenna << ": Set Azimuth = " << step.slew.azimuth
                      << "°, Elevation = " << step.slew.elevation << "°" << std::endl;
        } 
        else if (step.type == CommandType::TRANSMIT) 
        {
            std::cout << "Executing TransmitCommand on " << step.antenna << ": Waveform = " << step.transmit.waveform
                      << ", Num_Pulses = " << step.transmit.num_pulses
                      << ", Repetition_Count = " << step.transmit.repetition_count << std::endl;

            // Simulate the transmission being repeated according to repetition_count
            for (int i = 0; i < step.transmit.repetition_count; ++i)
            {
                std::cout << "  Transmission " << (i + 1) << "/" << step.transmit.repetition_count << std::endl;

                IterationData data = generateIterationData(step.transmit.repetition_count);

                        std::cout << "Executing Transmit Command - Iteration " << (i + 1) << ":\n";
        
                std::cout << "  c1: ";
                for (double val : data.c1) std::cout << std::fixed << std::setprecision(4) << val << " ";

                //std::cout << "  1st column of c1: " << std::fixed << std::setprecision(4) << data.c1[0] << "\n";
               // std::cout << "  2st column of c1 " << std::fixed << std::setprecision(4) << data.c1[0] << "\n";

                
                std::cout << "\n  c2: ";
                for (double val : data.c2) std::cout << std::fixed << std::setprecision(4) << val << " ";
                
                std::cout << "\n  c3: ";
                for (double val : data.c3) std::cout << std::fixed << std::setprecision(4) << val << " ";
                
              //  std::cout << "\n  Azimuth: " << std::fixed << std::setprecision(4) << data.azimuth << "°";
               // std::cout << "\n  Elevation: " << std::fixed << std::setprecision(4) << data.elevation << "°";
                
                std::cout << "\n----------------------------------------\n";


            }
        }
    }
}

int main() {
    // Manually creating 18 scenario steps based on scenario.txt
    std::vector<ScenarioStep> steps;

    // Step 1: SlewCommand for Penzias
    ScenarioStep step1;
    step1.type = CommandType::SLEW;
    step1.time_offset_secs = 0.0;
    step1.antenna = "Penzias";
    step1.slew.azimuth = 205.0;
    step1.slew.elevation = 1.5;
    steps.push_back(step1);

    // Step 2: TransmitCommand for Penzias
    ScenarioStep step2;
    step2.type = CommandType::TRANSMIT;
    step2.time_offset_secs = 14.75;
    step2.antenna = "Penzias";
    step2.transmit.waveform = "Waveform_A";
    step2.transmit.num_pulses = 1;
    step2.transmit.repetition_count = 250;
    steps.push_back(step2);

    // Step 3: TransmitCommand for Penzias
    ScenarioStep step3;
    step3.type = CommandType::SLEW;
    step3.time_offset_secs = 15.75;
    step3.antenna = "Penzias";
    step3.slew.azimuth = 210.0;
    step3.slew.elevation = 3.0;
    steps.push_back(step3);

    // Step 4: SlewCommand for Wilson
    ScenarioStep step4;
    step4.type = CommandType::SLEW;
    step4.time_offset_secs = 17.25;
    step4.antenna = "Penzias";
    step4.slew.azimuth = 205.0;
    step4.slew.elevation = 1.5;
    steps.push_back(step4);
/*
    // Step 5: TransmitCommand for Wilson
    ScenarioStep step5;
    step5.type = CommandType::TRANSMIT;
    step5.time_offset_secs = 64.5;
    step5.antenna = "Wilson";
    step5.transmit.waveform = "Waveform_B";
    step5.transmit.num_pulses = 1;
    step5.transmit.repetition_count = 250;
    steps.push_back(step5);

    // Step 6: SlewCommand for Wilson
    ScenarioStep step6;
    step6.type = CommandType::SLEW;
    step6.time_offset_secs = 70.0;
    step6.antenna = "Wilson";
    step6.slew.azimuth = 215.0;
    step6.slew.elevation = 2.5;
    steps.push_back(step6);

    // Step 7: TransmitCommand for Wilson
    ScenarioStep step7;
    step7.type = CommandType::TRANSMIT;
    step7.time_offset_secs = 74.5;
    step7.antenna = "Wilson";
    step7.transmit.waveform = "Waveform_C";
    step7.transmit.num_pulses = 2;
    step7.transmit.repetition_count = 250;
    steps.push_back(step7);

    // Step 8: SlewCommand for Dickie
    ScenarioStep step8;
    step8.type = CommandType::SLEW;
    step8.time_offset_secs = 80.0;
    step8.antenna = "Dickie";
    step8.slew.azimuth = 220.0;
    step8.slew.elevation = 3.0;
    steps.push_back(step8);

    // Step 9: TransmitCommand for Dickie
    ScenarioStep step9;
    step9.type = CommandType::TRANSMIT;
    step9.time_offset_secs = 84.5;
    step9.antenna = "Dickie";
    step9.transmit.waveform = "Waveform_A";
    step9.transmit.num_pulses = 3;
    step9.transmit.repetition_count = 250;
    steps.push_back(step9);

    // Step 10: SlewCommand for Penzias
    ScenarioStep step10;
    step10.type = CommandType::SLEW;
    step10.time_offset_secs = 90.0;
    step10.antenna = "Penzias";
    step10.slew.azimuth = 225.0;
    step10.slew.elevation = 3.5;
    steps.push_back(step10);

    // Step 11: TransmitCommand for Penzias
    ScenarioStep step11;
    step11.type = CommandType::TRANSMIT;
    step11.time_offset_secs = 94.5;
    step11.antenna = "Penzias";
    step11.transmit.waveform = "Waveform_B";
    step11.transmit.num_pulses = 4;
    step11.transmit.repetition_count = 250;
    steps.push_back(step11);

    // Step 12: SlewCommand for Wilson
    ScenarioStep step12;
    step12.type = CommandType::SLEW;
    step12.time_offset_secs = 100.0;
    step12.antenna = "Wilson";
    step12.slew.azimuth = 230.0;
    step12.slew.elevation = 4.0;
    steps.push_back(step12);

    // Step 13: TransmitCommand for Wilson
    ScenarioStep step13;
    step13.type = CommandType::TRANSMIT;
    step13.time_offset_secs = 104.5;
    step13.antenna = "Wilson";
    step13.transmit.waveform = "Waveform_C";
    step13.transmit.num_pulses = 5;
    step13.transmit.repetition_count = 250;
    steps.push_back(step13);

    // Step 14: TransmitCommand for Dickie (3 commands)
    ScenarioStep step14_1;
    step14_1.type = CommandType::TRANSMIT;
    step14_1.time_offset_secs = 110.0;
    step14_1.antenna = "Dickie";
    step14_1.transmit.waveform = "Waveform_A";
    step14_1.transmit.num_pulses = 6;
    step14_1.transmit.repetition_count = 250;
    steps.push_back(step14_1);

    ScenarioStep step14_2;
    step14_2.type = CommandType::TRANSMIT;
    step14_2.time_offset_secs = 110.0; // Same time offset for the second command
    step14_2.antenna = "Dickie";
    step14_2.transmit.waveform = "Waveform_B";
    step14_2.transmit.num_pulses = 7;
    step14_2.transmit.repetition_count = 250;
    steps.push_back(step14_2);

    ScenarioStep step14_3;
    step14_3.type = CommandType::TRANSMIT;
    step14_3.time_offset_secs = 110.0; // Same time offset for the third command
    step14_3.antenna = "Dickie";
    step14_3.transmit.waveform = "Waveform_C";
    step14_3.transmit.num_pulses = 8;
    step14_3.transmit.repetition_count = 250;
    steps.push_back(step14_3);

    // Step 15: SlewCommand for Penzias
    ScenarioStep step15;
    step15.type = CommandType::SLEW;
    step15.time_offset_secs = 75.25;
    step15.antenna = "Penzias";
    step15.slew.azimuth = 210.0;
    step15.slew.elevation = 3.0;
    steps.push_back(step15);

    // Step 16: TransmitCommand for Dickie
    ScenarioStep step16;
    step16.type = CommandType::TRANSMIT;
    step16.time_offset_secs = 120.0;
    step16.antenna = "Dickie";
    step16.transmit.waveform = "Waveform_A";
    step16.transmit.num_pulses = 8;
    step16.transmit.repetition_count = 250;
    steps.push_back(step16);

    // Step 17: SlewCommand for Dickie
    ScenarioStep step17;
    step17.type = CommandType::SLEW;
    step17.time_offset_secs = 1.0;
    step17.antenna = "Dickie";
    step17.slew.azimuth = 245.0;
    step17.slew.elevation = 5.5;
    steps.push_back(step17);

    // Step 18: TransmitCommand for Dickie
    ScenarioStep step18;
    step18.type = CommandType::TRANSMIT;
    step18.time_offset_secs = 2.0;
    step18.antenna = "Dickie";
    step18.transmit.waveform = "Waveform_C";
    step18.transmit.num_pulses = 9;
    step18.transmit.repetition_count = 250;
    steps.push_back(step18);
*/
    // Execute each step as a sensor command
    executeSensorCommands(steps);

    return 0;
}
