import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import time

# Define the number of steps
num_steps = 18

# Pre-define arrays for azimuth, elevation, and true range
azimuth = [205, 0, 0, 210, 0, 215, 0, 220, 0, 225, 0, 230, 0, 0, 210, 0, 0, 0]  # example values
elevation = [1.5, 0, 0, 2.0, 0, 2.5, 0, 3.0, 0, 3.5, 0, 4.0, 0, 0, 3.0, 0, 0, 0]  # example values
true_range = [100, 0, 0, 120, 0, 140, 0, 160, 0, 180, 0, 200, 0, 0, 120, 0, 0, 0]  # example range
commands = ['TRANSMIT', 'SLEW', 'SLEW', 'TRANSMIT', 'SLEW', 'TRANSMIT', 'SLEW', 'TRANSMIT', 'SLEW',
            'TRANSMIT', 'SLEW', 'TRANSMIT', 'SLEW', 'SLEW', 'TRANSMIT', 'SLEW', 'SLEW', 'SLEW']  # example command types

# Create a 3D plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')
ax.set_title('Azimuth, Elevation, and True Range Simulation')

# Lists to store the line points for TRANSMIT commands
x_values = []
y_values = []
z_values = []

# Loop through each step
for i in range(num_steps):
    if azimuth[i] != 0 and elevation[i] != 0:  # Only plot for non-zero values
        # Convert spherical to cartesian coordinates
        x = true_range[i] * np.cos(np.radians(elevation[i])) * np.cos(np.radians(azimuth[i]))
        y = true_range[i] * np.cos(np.radians(elevation[i])) * np.sin(np.radians(azimuth[i]))
        z = true_range[i] * np.sin(np.radians(elevation[i]))

        # Plot TRANSMIT points in red and SLEW in blue
        if commands[i] == 'TRANSMIT':
            ax.scatter(x, y, z, color='r', s=50, label='Transmit' if i == 0 else "")  # Red for TRANSMIT
            # Append the point to line plot data
            x_values.append(x)
            y_values.append(y)
            z_values.append(z)
        else:
            ax.scatter(x, y, z, color='b', s=50, label='Slew' if i == 0 else "")  # Blue for SLEW

        # Annotate the point with az, el, and range
        ax.text(x, y, z, f'Az: {azimuth[i]}, El: {elevation[i]}, Range: {true_range[i]}', fontsize=10)

        # Pause to simulate time steps
        plt.draw()
        plt.pause(1)

# Plot the line connecting TRANSMIT points
if len(x_values) > 1:
    ax.plot(x_values, y_values, z_values, color='g', label='True Range Path')  # Green line for True Range path

# Show the plot with legend
ax.legend()
plt.show()
