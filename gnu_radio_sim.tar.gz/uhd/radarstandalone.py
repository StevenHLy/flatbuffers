#!/usr/bin/env python3
from gnuradio import gr
from gnuradio import analog
from gnuradio import blocks
import time  # Import time to add sleep functionality

# Enum for Waveform Types
class WaveformType:
    WAVEFORM_A = "Waveform_A"
    WAVEFORM_B = "Waveform_B"

# Simulated Fake Device Class
class FakeDevice(gr.top_block):
    def __init__(self):
        gr.top_block.__init__(self)

        # Create a null sink to consume output data (simulated device output)
        self.null_sink = blocks.null_sink(gr.sizeof_gr_complex)

        # Create an add block to combine multiple signals
        self.adder = blocks.add_cc()  # Add complex numbers (gr_complex)

        # Connect the output of the adder to the null sink
        self.connect(self.adder, self.null_sink)

        # Keep track of how many input ports are used
        self.current_port = 0

    # Simulate transmitting a signal based on a waveform type
    def transmit_waveform(self, waveform_type, frequency, amplitude):
        print(f"Transmitting: {waveform_type} at {frequency} Hz with amplitude {amplitude}")
        
        # Create a signal source based on the waveform type
        signal_source = analog.sig_source_c(1e6, analog.GR_SIN_WAVE, frequency, amplitude, 0)
        throttle = blocks.throttle(gr.sizeof_gr_complex, 1e6, True)  # Control sample rate

        # Connect the signal to the next available port of the adder
        self.connect(signal_source, throttle, (self.adder, self.current_port))
        self.current_port += 1  # Increment for the next signal

    # Simulate SlewCommand with azimuth and elevation values
    def add_slew_command(self, az, el):
        # Print azimuth and elevation values
        print(f"Executing SlewCommand with Azimuth: {az}, Elevation: {el}")

        # Generate a frequency based on the azimuth (simplified mapping)
        freq = az * 10  # Simplified azimuth to frequency conversion
        signal_source = analog.sig_source_c(1e6, analog.GR_SIN_WAVE, freq, 1, 0)
        throttle = blocks.throttle(gr.sizeof_gr_complex, 1e6, True)

        # Connect the signal to the next available port of the adder
        self.connect(signal_source, throttle, (self.adder, self.current_port))
        self.current_port += 1  # Increment for the next signal

    # Simulate receiving data from the fake device
    def receive_data(self):
        # In a real device, this would pull data from hardware. Here, it's simulated.
        print("Receiving data from simulated fake device...")
        # Data is processed internally and "received" via the connected flowgraph blocks.

    def start_simulation(self):
        # Start the flowgraph simulation
        print("Starting fake device simulation...")
        self.start()
        time.sleep(5)  # Simulate for 5 seconds
        self.stop()
        self.wait()

# Function to process a scenario with the fake device
def process_scenario(fake_device):
    # Step 1: SlewCommand
    print("Simulating Step 1: SlewCommand")
    fake_device.add_slew_command(az=205, el=1.5)  # Example azimuth and elevation

    # Step 2: TransmitCommand with Waveform_A
    print("Simulating Step 2: TransmitCommand (Waveform_A)")
    fake_device.transmit_waveform(WaveformType.WAVEFORM_A, frequency=1e3, amplitude=1.0)  # 1 kHz

    # Step 3: TransmitCommand with Waveform_B
    print("Simulating Step 3: TransmitCommand (Waveform_B)")
    fake_device.transmit_waveform(WaveformType.WAVEFORM_B, frequency=2e3, amplitude=0.8)  # 2 kHz

    # Simulate receiving data from the fake device
    fake_device.receive_data()

if __name__ == '__main__':
    # Create a fake device (simulated device)
    fake_device = FakeDevice()

    # Process the scenario using the fake device
    process_scenario(fake_device)

    # Start the simulation
    fake_device.start_simulation()
