#include <uhd/usrp/multi_usrp.hpp>
#include <uhd/utils/thread.hpp>
#include <boost/thread.hpp>
#include <iostream>
#include <fstream>
#include <string>
#include <thread>
#include <chrono>
#include <map>

// Flag for simulation mode (no hardware interactions)
const bool simulate = true;

// Enum to represent different command types
enum class CommandType {
    SLEW,
    TRANSMIT,
    UNKNOWN
};

// Struct to store waveform parameters
struct Waveform {
    double pulsewidth_sec;
    double amp;
    double bandwidth_mhz;
    double phase_offset_psec;
    double offsets_mhz;
    int sample_per_chip;
    int gold_code_index;
};

// Struct for command information (SlewCommand or TransmitCommand)
struct Command {
    CommandType type;
    double az;                  // For SlewCommand
    double el;                  // For SlewCommand
    std::string waveform;       // For TransmitCommand
    int num_pulses;             // For TransmitCommand
    int repetition_count;       // For TransmitCommand
    double time_offset_secs;    // Time offset for executing the command
};

// Function to parse waveforms from the scenario file
std::map<std::string, Waveform> parseWaveforms() {
    std::map<std::string, Waveform> waveforms;

    // Adding Waveform_A
    waveforms["Waveform_A"] = {2, 1, 10, 0, 0, 1, 0};
    // Adding Waveform_B
    waveforms["Waveform_B"] = {2, 1, 10, 0, 0, 1, 0};

    return waveforms;
}

// Function to parse commands (SlewCommand, TransmitCommand) from the scenario
std::vector<Command> parseScenario() {
    std::vector<Command> commands;

    // Step 1 - SlewCommand
    commands.push_back({CommandType::SLEW, 205.0, 1.5, "", 0, 0, 0.0});

    // Step 2 - TransmitCommand (Waveform_A)
    commands.push_back({CommandType::TRANSMIT, 0, 0, "Waveform_A", 1, 250, 14.5});

    // Step 3 - TransmitCommand (Waveform_B)
    commands.push_back({CommandType::TRANSMIT, 0, 0, "Waveform_B", 1, 250, 54.5});

    return commands;
}

// Function to execute SlewCommand
void executeSlewCommand(double azimuth, double elevation) {
    std::cout << "Slewing to Azimuth: " << azimuth << " degrees, Elevation: " << elevation << " degrees." << std::endl;
    // Simulate slewing (no actual hardware operations)
}

// Function to simulate or execute TransmitCommand with UHD using tx_streamer
void executeTransmitCommand(uhd::usrp::multi_usrp::sptr usrp, const Waveform& waveform, int num_pulses, int repetition_count) {
    std::cout << "Transmitting waveform with " << num_pulses << " pulses, " << repetition_count << " repetitions." << std::endl;

    if (simulate) {
        // Simulate transmission (nothing is actually transmitted)
        std::cout << "Simulated waveform parameters: Pulsewidth = " << waveform.pulsewidth_sec 
                  << " seconds, Amplitude = " << waveform.amp << std::endl;
    } else {
        // Configure the USRP for transmission
        usrp->set_tx_freq(2.4e9);   // Set frequency to 2.4 GHz
        usrp->set_tx_rate(1e6);     // Set sample rate to 1 MSps
        usrp->set_tx_gain(10);      // Set transmit gain to 10 dB

        // Create a tx_streamer to send the data
        uhd::stream_args_t stream_args("fc32", "sc16"); // Stream with complex float32 samples
        uhd::tx_streamer::sptr tx_stream = usrp->get_tx_stream(stream_args);

        // Transmission buffer
        std::vector<std::complex<float>> tx_buffer(tx_stream->get_max_num_samps(), std::complex<float>(waveform.amp, 0));

        // Metadata for transmission
        uhd::tx_metadata_t metadata;
        metadata.start_of_burst = true;  // Start of burst
        metadata.end_of_burst = false;   // End of burst will be marked later
        metadata.has_time_spec = false;  // No timed transmission in this example

        // Transmit the waveform in a loop for repetition_count times
        for (int i = 0; i < repetition_count; ++i) {
            tx_stream->send(&tx_buffer.front(), tx_buffer.size(), metadata);
            metadata.start_of_burst = false; // Only true for the first packet
        }

        // Finalize the burst
        metadata.end_of_burst = true;
        tx_stream->send(&tx_buffer.front(), tx_buffer.size(), metadata);
    }
}

// Main function
int main() {
    uhd::usrp::multi_usrp::sptr usrp;

    // If not simulating, try to initialize the USRP
    if (!simulate) {
        uhd::device_addr_t dev_addr("type=b200");
        try {
            usrp = uhd::usrp::multi_usrp::make(dev_addr);
            usrp->set_tx_antenna("TX/RX");  // Set antenna port
        } catch (const uhd::key_error& e) {
            std::cerr << "USRP device not found: " << e.what() << std::endl;
            return -1;
        }
    }

    // Parse the waveforms and commands from the scenario
    std::map<std::string, Waveform> waveforms = parseWaveforms();
    std::vector<Command> commands = parseScenario();

    // Iterate over the commands in the scenario
    for (const auto& cmd : commands) {
        // Simulate the time delay for each command
        std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<int>(cmd.time_offset_secs * 1000)));

        // Use a switch statement to handle different command types
        switch (cmd.type) {
            case CommandType::SLEW:
                // Simulate SlewCommand
                executeSlewCommand(cmd.az, cmd.el);
                break;

            case CommandType::TRANSMIT: {
                // Simulate or execute TransmitCommand
                if (waveforms.find(cmd.waveform) != waveforms.end()) {
                    executeTransmitCommand(usrp, waveforms[cmd.waveform], cmd.num_pulses, cmd.repetition_count);
                } else {
                    std::cerr << "Unknown waveform: " << cmd.waveform << std::endl;
                }
                break;
            }

            default:
                std::cerr << "Unknown command type." << std::endl;
                break;
        }
    }

    return 0;
}
