import re

# Speed of light in meters per second
SPEED_OF_LIGHT = 299_792_458  # meters/second

# Define regex patterns to extract data from the scenario file
time_offset_pattern = r'"Time_Offset_Secs"\s+"([\d.]+)"'
transmit_command_pattern = r'TransmitCommand\s*\{'
slew_command_pattern = r'SlewCommand\s*\{'
azimuth_pattern = r'"Azimuth_Degrees"\s+"([\d.]+)"'
elevation_pattern = r'"Elevation_Degrees"\s+"([\d.]+)"'
repetition_count_pattern = r'"Repetition_Count"\s+"(\d+)"'

# Parse the scenario file and calculate true ranges for TRANSMIT commands
def calculate_true_ranges(filename):
    true_ranges = []
    current_command = None
    azimuth = None
    elevation = None
    time_offset = None
    repetition_count = None
    command_found = False

    with open(filename, 'r') as file:
        for line in file:
            # Detect the TransmitCommand block
            if re.search(transmit_command_pattern, line):
                current_command = "TransmitCommand"
                print(f"DEBUG: Detected Transmit Command")  # Debugging output
                command_found = True  # Mark that we're inside a TransmitCommand block

            # Detect the SlewCommand block (for completeness)
            if re.search(slew_command_pattern, line):
                current_command = "SlewCommand"
                print(f"DEBUG: Detected Slew Command")  # Debugging output
                command_found = False  # No true range for SlewCommand

            # Extract time offset
            time_offset_match = re.search(time_offset_pattern, line)
            if time_offset_match:
                time_offset = float(time_offset_match.group(1))
                print(f"DEBUG: Found Time Offset: {time_offset}")  # Debugging output

            # Extract azimuth and elevation if they exist
            azimuth_match = re.search(azimuth_pattern, line)
            if azimuth_match:
                azimuth = float(azimuth_match.group(1))
                print(f"DEBUG: Found Azimuth: {azimuth}")  # Debugging output

            elevation_match = re.search(elevation_pattern, line)
            if elevation_match:
                elevation = float(elevation_match.group(1))
                print(f"DEBUG: Found Elevation: {elevation}")  # Debugging output

            # Extract repetition count
            repetition_count_match = re.search(repetition_count_pattern, line)
            if repetition_count_match:
                repetition_count = int(repetition_count_match.group(1))
                print(f"DEBUG: Found Repetition Count: {repetition_count}")  # Debugging output

            # Calculate true range for TRANSMIT commands when all data is present
            if current_command == "TransmitCommand" and command_found and time_offset is not None and repetition_count is not None:
                # Calculate the true range based on the time offset
                true_range = (SPEED_OF_LIGHT * time_offset) / 2
                print(f"DEBUG: Calculated True Range: {true_range} meters")  # Debugging output

                true_ranges.append({
                    'command': current_command,
                    'azimuth': azimuth,
                    'elevation': elevation,
                    'true_range': true_range,
                    'repetition_count': repetition_count,
                    'time_offset': time_offset
                })

                # Reset values for the next command
                current_command = None
                time_offset = None
                azimuth = None
                elevation = None
                repetition_count = None
                command_found = False

    return true_ranges

# Print the calculated true ranges
filename = 'scenario.txt'
true_ranges = calculate_true_ranges(filename)
for i, data in enumerate(true_ranges, 1):
    print(f"Step {i}:")
    print(f"  Command: {data['command']}")
    print(f"  Azimuth: {data['azimuth']}°")
    print(f"  Elevation: {data['elevation']}°")
    print(f"  True Range: {data['true_range']:.2f} meters")
    print(f"  Repetition Count: {data['repetition_count']}")
    print(f"  Time Offset: {data['time_offset']} seconds")
    print("-" * 30)
