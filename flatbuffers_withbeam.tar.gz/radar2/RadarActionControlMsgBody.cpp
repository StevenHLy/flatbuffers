// RadarActionControlMsgBody.cpp

#include "RadarActionControlMsgBody.h"
#include "common_generated.h"


// Constructor: Initialize the id to 0
RadarActionControlMsgBody::RadarActionControlMsgBody() : 
id(0),
rx_command_id(0), 
channel_plan_id(0),
processing_module_id(0),     
beam_plan_id(0) 
 {} 

// Destructor
RadarActionControlMsgBody::~RadarActionControlMsgBody() {}

// Serialize the ChannelPlanType into a FlatBuffer
flatbuffers::Offset<ChannelPlanType> RadarActionControlMsgBody::serializeChannelPlan(flatbuffers::FlatBufferBuilder& builder) const {
    // Serialize the id
    auto id_offset = common::CreateUint(builder, id);

    // Serialize the channel_ids array
    std::vector<flatbuffers::Offset<common::Uint>> channel_ids_vector;
    for (const auto& channel_id : channel_ids) {
        channel_ids_vector.push_back(common::CreateUint(builder, channel_id));
    }
    auto channel_ids_offset = builder.CreateVector(channel_ids_vector);

    // Serialize the aggregation_weights array
    std::vector<flatbuffers::Offset<common::ComplexDoubleType>> weights_vector;
    for (const auto& weight : aggregation_weights) {
        weights_vector.push_back(common::CreateComplexDoubleType(builder, weight.first, weight.second));
    }
    auto weights_offset = builder.CreateVector(weights_vector);

    // Build and return the ChannelPlanType offset
    return CreateChannelPlanType(builder, id_offset, channel_ids_offset, weights_offset);
}

flatbuffers::Offset<RxCommandType> RadarActionControlMsgBody::serializeRxCommand(flatbuffers::FlatBufferBuilder& builder) const {
    // Serialize the rx_command_id (RxCommandType id)
    auto rx_command_id_offset = common::CreateUint(builder, rx_command_id);

    // Serialize the channel_plan_id
    auto channel_plan_id_offset = common::CreateUint(builder, channel_plan_id);

    // Serialize the rx_window_plan_ids array
    std::vector<flatbuffers::Offset<common::Uint>> rx_window_plan_ids_vector;
    for (const auto& rx_window_plan_id : rx_window_plan_ids) {
        rx_window_plan_ids_vector.push_back(common::CreateUint(builder, rx_window_plan_id));
    }
    auto rx_window_plan_ids_offset = builder.CreateVector(rx_window_plan_ids_vector);

    // Serialize the processing_module_id if it's set
    flatbuffers::Offset<common::Uint> processing_module_id_offset = 0;
    if (processing_module_id != 0) {
        processing_module_id_offset = common::CreateUint(builder, processing_module_id);
    }

    // Build and return the RxCommandType offset
    return CreateRxCommandType(builder, rx_command_id_offset, channel_plan_id_offset, rx_window_plan_ids_offset, processing_module_id_offset);
}

flatbuffers::Offset<BeamPlanType> RadarActionControlMsgBody::serializeBeamPlanType(flatbuffers::FlatBufferBuilder& builder) const
{
   // Serialize the ID of the beam plan
    auto id_offset = common::CreateUint(builder, beam_plan_id);

    // Serialize the beams (list of AngleCommandType)
    std::vector<flatbuffers::Offset<AngleCommandType>> beam_offsets;
    for (const auto* beam : beams) {
        // Serialize each field of the AngleCommandType before adding it to the vector
        auto channel_plan_id_offset = common::CreateUint(builder, beam->channel_plan_id()->value());
        auto azimuth_offset = common::CreateDouble(builder, beam->azimuth()->value());
        auto elevation_offset = common::CreateDouble(builder, beam->elevation()->value());
        auto azimuth_spoil_factor_offset = common::CreateDouble(builder, beam->azimuth_spoil_factor()->value());
        auto elevation_spoil_factor_offset = common::CreateDouble(builder, beam->elevation_spoil_factor()->value());

        // Serialize the PolarizationType
        const PolarizationType* polarization = beam->polarization();
        auto vertical_offset = common::CreateComplexDoubleType(builder, polarization->jones_vector()->vertical()->real(), polarization->jones_vector()->vertical()->imag());
        auto horizontal_offset = common::CreateComplexDoubleType(builder, polarization->jones_vector()->horizontal()->real(), polarization->jones_vector()->horizontal()->imag());
        auto jones_vector_offset = CreateJonesVectorType(builder, vertical_offset, horizontal_offset);

        flatbuffers::Offset<XyzPositionType> polarization_reference_vector_offset = 0;
        if (polarization->polarization_reference_vector()) {
            polarization_reference_vector_offset = CreateXyzPositionType(
                builder,
                polarization->polarization_reference_vector()->x()->value(),
                polarization->polarization_reference_vector()->y()->value(),
                polarization->polarization_reference_vector()->z()->value()
            );
        }

        // Create PolarizationType
        auto polarization_offset = CreatePolarizationType(builder, jones_vector_offset, polarization_reference_vector_offset);

        // Serialize the beam and add it to the vector
        auto beam_offset = CreateAngleCommandType(
            builder, 
            channel_plan_id_offset, 
            azimuth_offset, 
            elevation_offset, 
            azimuth_spoil_factor_offset, 
            elevation_spoil_factor_offset, 
            polarization_offset
        );
        beam_offsets.push_back(beam_offset);
    }
    auto beams_offset = builder.CreateVector(beam_offsets);

    // Serialize the nulls (list of AngleCommandType)
    std::vector<flatbuffers::Offset<AngleCommandType>> null_offsets;
    for (const auto* null : nulls) {
        // Serialize each field of the AngleCommandType before adding it to the vector
        auto channel_plan_id_offset = common::CreateUint(builder, null->channel_plan_id()->value());
        auto azimuth_offset = common::CreateDouble(builder, null->azimuth()->value());
        auto elevation_offset = common::CreateDouble(builder, null->elevation()->value());
        auto azimuth_spoil_factor_offset = common::CreateDouble(builder, null->azimuth_spoil_factor()->value());
        auto elevation_spoil_factor_offset = common::CreateDouble(builder, null->elevation_spoil_factor()->value());

        // Serialize the PolarizationType
        const PolarizationType* polarization = null->polarization();
        auto vertical_offset = common::CreateComplexDoubleType(builder, polarization->jones_vector()->vertical()->real(), polarization->jones_vector()->vertical()->imag());
        auto horizontal_offset = common::CreateComplexDoubleType(builder, polarization->jones_vector()->horizontal()->real(), polarization->jones_vector()->horizontal()->imag());
        auto jones_vector_offset = CreateJonesVectorType(builder, vertical_offset, horizontal_offset);

        flatbuffers::Offset<XyzPositionType> polarization_reference_vector_offset = 0;
        if (polarization->polarization_reference_vector()) {
            polarization_reference_vector_offset = CreateXyzPositionType(
                builder,
                polarization->polarization_reference_vector()->x()->value(),
                polarization->polarization_reference_vector()->y()->value(),
                polarization->polarization_reference_vector()->z()->value()
            );
        }

        // Create PolarizationType
        auto polarization_offset = CreatePolarizationType(builder, jones_vector_offset, polarization_reference_vector_offset);

        // Serialize the null and add it to the vector
        auto null_offset = CreateAngleCommandType(
            builder, 
            channel_plan_id_offset, 
            azimuth_offset, 
            elevation_offset, 
            azimuth_spoil_factor_offset, 
            elevation_spoil_factor_offset, 
            polarization_offset
        );
        null_offsets.push_back(null_offset);
    }
    auto nulls_offset = builder.CreateVector(null_offsets);

    // Serialize the element commands (list of ElementCommandType)
    std::vector<flatbuffers::Offset<ElementCommandType>> element_command_offsets;
    for (const auto* element_command : element_commands) {
        // Serialize each field of the ElementCommandType before adding it to the vector
        auto element_id_offset = common::CreateUint(builder, element_command->element_id()->value());
        auto delay_offset = common::CreateDouble(builder, element_command->delay()->value());
        auto amplitude_offset = common::CreateDouble(builder, element_command->amplitude()->value());

        // Serialize the element command and add it to the vector
        auto element_command_offset = CreateElementCommandType(
            builder, 
            element_id_offset, 
            delay_offset, 
            amplitude_offset
        );
        element_command_offsets.push_back(element_command_offset);
    }
    auto element_commands_offset = builder.CreateVector(element_command_offsets);

    // Return the serialized BeamPlanType
    return CreateBeamPlanType(builder, id_offset, beams_offset, nulls_offset, element_commands_offset);

 

}

void RadarActionControlMsgBody::deserializeBeamPlanType(const BeamPlanType* beam_plan)
{
 // Deserialize the beam plan ID
    if (beam_plan->id()) {
        beam_plan_id = beam_plan->id()->value();
    }

    // Deserialize the beams (list of AngleCommandType)
    beams.clear();
    if (beam_plan->beams()) {
        for (const auto* beam : *beam_plan->beams()) {
            beams.push_back(beam);  // Store the pointer to the deserialized object
        }
    }

    // Deserialize the nulls (list of AngleCommandType)
    nulls.clear();
    if (beam_plan->nulls()) {
        for (const auto* null : *beam_plan->nulls()) {
            nulls.push_back(null);  // Store the pointer to the deserialized object
        }
    }

    // Deserialize the element commands (list of ElementCommandType)
    element_commands.clear();
    if (beam_plan->element_commands()) {
        for (const auto* element_command : *beam_plan->element_commands()) {
            element_commands.push_back(element_command);  // Store the pointer to the deserialized object
        }
    }
}

// Deserialize the ChannelPlanType from a FlatBuffer
void RadarActionControlMsgBody::deserializeChannelPlan(const ChannelPlanType* channelPlan) {
    // Deserialize the id
    id = channelPlan->id()->value();

    // Deserialize the channel_ids
    channel_ids.clear();
    for (auto channel_id : *channelPlan->channel_id()) {
        channel_ids.push_back(channel_id->value());
    }

    // Deserialize the aggregation_weights
    aggregation_weights.clear();
    for (auto weight : *channelPlan->aggregation_weights()) {
        aggregation_weights.emplace_back(weight->real(), weight->imag());
    }

}

void RadarActionControlMsgBody::deserializeRxCommand(const RxCommandType* rxCommand) {
    // Deserialize the rx_command_id (RxCommandType id)
    rx_command_id = rxCommand->id()->value();

    // Deserialize the channel_plan_id
    channel_plan_id = rxCommand->channel_plan_id()->value();

    // Deserialize the rx_window_plan_ids
    rx_window_plan_ids.clear();
    for (auto rx_window_plan_id : *rxCommand->rx_window_plan_id()) {
        rx_window_plan_ids.push_back(rx_window_plan_id->value());
    }

    // Deserialize the processing_module_id if it exists
    if (rxCommand->processing_module_id()) {
        processing_module_id = rxCommand->processing_module_id()->value();
    } else {
        processing_module_id = 0; // Set to 0 if not present
    }
}


